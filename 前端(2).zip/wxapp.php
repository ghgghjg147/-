<?php
/**
 * 本破解程序由 猫 咪 源码提供
 * maomi源码商 城maomiyuanma.com 免费下载QQ:1931864511
 *  承接PHP 二次开发 指定模块破解
 */

defined('IN_IA') or exit('Access Denied');
define('FCPATH', dirname(__FILE__)."/");
include "lib/function.php";
class Yf_chengyujiekongModuleWxapp extends WeModuleWxapp {
    private $gpc;
    private $w;
    public $miniapp;
    public $openid;
    public $appid;
    public $appsecret;
	public function __construct() 
	{
        global $_W;
        global $_GPC;
        $this->gpc = $_GPC;
        $this->w = $_W;

		pdo_delete("yf_chengyu_platform", ["appid"=>""]);
		$this->miniapp = $this->w["uniacid"];
		$this->platform_row = pdo_get("yf_chengyu_platform", ["miniapp"=>$this->miniapp]);
		// $this->platform_row = pdo_get("yf_chengyu_platform");
		if( ! $this->platform_row && $this->w['uniaccount']['key'])
		{
			$params = [
				"miniapp" => $this->miniapp,
				"title" => $this->w['uniaccount']['name'],
				"original_id" => $this->w['uniaccount']['original'],
				"appid" => $this->w['uniaccount']['key'],
				"appsecret" => $this->w['uniaccount']['secret'],
			];
			pdo_insert("yf_chengyu_platform", $params);
			$this->platform_row = pdo_get("yf_chengyu_platform", ["miniapp"=>$this->miniapp]);
		}
		if( ! $this->platform_row) 
		{
			$this->platform_row = pdo_get("yf_chengyu_platform");
			$this->miniapp = $this->platform_row["miniapp"];
		}
		

		$this->appid = $this->w['uniaccount']['key'];
		$this->appsecret = $this->w['uniaccount']['secret'];

		//权限判断
		if(in_array($_GET["do"], ["unionLogin", "login", "autoPass", "LevelChengyu", "change", "send", "sendMessage","myGameLevel"]))
		{
			return ;
		}

		$this->openid = $_SERVER["HTTP_X_WX_ID"];
		$this->user_row = pdo_get("yf_chengyu_user", ["openid"=>$this->openid]);
		if( ! $this->user_row)
		{
			$this->fail("用户不存在");
		}
	}

	//登录
	public function doPageLogin()
	{
		$this->doPageUnionLogin();
	}

	//登录
	public function doPageUnionLogin()
	{
		$code = $_SERVER["HTTP_X_WX_CODE"];
		$options = trim($_SERVER["HTTP_OPTIONS"]);
		$options = json_decode($options, true);
		$options_str = json_encode($options["query"], JSON_UNESCAPED_UNICODE);

		//获取openid
		$url = "https://api.weixin.qq.com/sns/jscode2session?appid={$this->platform_row["appid"]}&secret={$this->platform_row["appsecret"]}&js_code={$code}&grant_type=authorization_code";
		$data = json_decode(file_get_contents($url), true);//session_key openid
		if(empty($data["openid"]))
		{
			$this->fail("获取用户信息失败");
		}
		
		$user_row = pdo_get("yf_chengyu_user", ["openid"=>$data["openid"]]);
		if( ! $user_row)
		{
			$params = array(
				"miniapp" => $this->miniapp,
				"openid" => $data["openid"],
				"session_key" => $data["session_key"],
				"register_time" => time(),
				"isauthorize" => 0,
				"authorizetime" => 0,
				"remote_addr" => $_SERVER["REMOTE_ADDR"],
				"options" => $options_str,
				"energy" => 5,
				"energyTime" => time(),
			);
			pdo_insert("yf_chengyu_user", $params);
			$user_row = pdo_get("yf_chengyu_user", ["openid"=>$data["openid"]]);
		}

		$data = [
			"code" => 0,
			"session" => [
				"openId" => "{$user_row["openid"]}",
				"skey" => "{$user_row["session_key"]}",
				"id" => "{$user_row["openid"]}",
				"userId" => "{$user_row["id"]}",
				"nickname" => "{$user_row["nickname"]}",
			],
			"F2C224D4-2BCE-4C64-AF9F-A6D872000D1A" => "1"
		];
		$this->output($data);
	}


	//阿拉丁配置
	public function doPageAldConfig()
	{
		$data = [
			"gameLoadDone" => [25775],
			"clickOneWord" => [27168,27375,27743,27749,27762],
			"enterOne" => [25775,26989],
			"oneFinish" => [26360,26814,27355,28015],
			"clickTwoWord" => [25775],
			"enterTwo" => [25775],
			"twoFinish" => [25775],
		];
		$this->output($data);
	}

	//统计
	public function doPageTrace()
	{
		$input = file_get_contents('php://input');
		$post = json_decode($input, true);

		$action = $post["traces"][0]["action"];
		$event = $post["traces"][0]["event"];
		if($event == "auth_user_info")
		{
			$userInfo = $post["traces"][0]["userInfo"];
			if($userInfo && $userInfo["nickName"])
			{
				$params = [
					"nickname" => $userInfo["nickName"],
					"avatar_url" => $userInfo["avatarUrl"],
					"gender" => $userInfo["gender"],
					"province" => $userInfo["province"],
					"city" => $userInfo["city"],
					"country" => $userInfo["country"],
					"language" => $userInfo["language"],
				];
				pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);
			}
		}

		if($action == "login" && $event == "page_load")
		{
			//更新能量
			$leftEnergy = intval($post["traces"][0]["leftEnergy"]);

			if(($post["traces"][0]["leftEnergy"]===0 || $post["traces"][0]["leftEnergy"]>0) && $this->user_row["energy"] != $leftEnergy)
			{
				$params = ["energy"=>$leftEnergy, "nextUnlock"=>1];
				// if($leftEnergy < 5 && $this->user_row["energyTime"]+1200 < time())
				// {
				// 	$leftEnergy += 1;
				// 	if($leftEnergy > 50) $leftEnergy = 50;
				// 	$params["energy"] = $leftEnergy;
				// 	$params["energyTime"] = time();
				// }
				if($leftEnergy >= 5)
				{
					$params["energyTime"] = time();
				}
				pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);
			}

			$extraData = json_decode($post["traces"][0]["extraData"], true);
			if($extraData && $extraData["rid"])
			{
				$uid = intval($extraData["rid"]);
				
				$user_row = pdo_get("yf_chengyu_user", ["id"=>$uid]);
				//不能自己给自己分享
				if($user_row && $user_row["id"] != $this->user_row["id"] && $this->user_row["helpTime"]+600 < time())
				{
					//帮助的人(自己)添加1点能量
					$energy = min(50, $this->user_row["energy"]+1);
					$params = ["energy"=>$energy, "helpTime"=>time()];
					pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);

					//被帮助的人添加2点能量
					$energy = min(50, $user_row["energy"]+2);
					$params = ["energy"=>$energy];
					pdo_update("yf_chengyu_user", $params, ["id"=>$user_row["id"]]);
				}
			}
		}

		if($event == "ad_banner_show")
		{
			$leftEnergy = intval($post["traces"][0]["leftEnergy"]);
			if($leftEnergy > 50) $leftEnergy = 50;
			$params = ["energy"=>$leftEnergy];
			pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);
		}

		$data = [
			"level" => $this->user_row["level"],
			"oid" => $this->user_row["openid"],
			"rid" => -1,
			"source" => "",
		];
		$this->output($data);
	}

	//获取能量
	public function doPageGetEnergy()
	{
		//给用户回复能量
		$lefttime = time() - $this->user_row["energyTime"];//更新能量的时间过去几秒
		if($lefttime-1200 > 0 && $this->user_row["energy"] < 5)
		{
			$energy = intval($lefttime/1200) + $this->user_row["energy"];
			if($energy >= 5) 
			{
				$energy = 5;
				$energyTime = time();
			}else{
				$energyTime = time()-$lefttime%1200;
			}
			$params = ["energy"=>$energy, "energyTime"=>$energyTime];
			pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);

			$this->user_row = pdo_get("yf_chengyu_user", ["openid"=>$this->openid]);
		}

		//计算剩下的时间可以获取能量
		$energyTotal = intval($this->user_row["energy"]);
		$energyCountDown = $energyAllCountDown = 0;
		if($energyTotal < 5)
		{
			$energyCountDown = 1200 - (time()-$this->user_row["energyTime"]);
			$energyAllCountDown = (5-$energyTotal)*1200+$energyCountDown;
		}

		$data = [
			"recoverTime" => 1200,//恢复时间 秒
			"energyMaxValue" => 5,//能量最大值
			"energyTotal" => $energyTotal,//能量总数
			"energyExtraValue" => 0,//额外的能量值
			"energyCountDown" => $energyCountDown,//能量下降的总数
			"energyValue" => $energyTotal,//能量值
			"energyAllCountDown" => $energyAllCountDown,//总下降的能量数
		];
		$this->output($data);
	}

	//获取热词
	public function doPageHotWord()
	{
		$list = pdo_getslice("yf_chengyu_idiom", [], [0, 9]);
		$idioms = [];
		foreach($list as $val)
		{
			$idioms[] = [
				"id" => intval($val["id"]),
				"word" => $val["word"],
				"pinyin" => $val["pinyin"],
				"collect" => intval($val["collect"]),
				"derivation" => $val["derivation"],
				"explanation" => $val["explanation"],
			];
		}

		$data = [
			"idioms" => $idioms,
			"isBeta" => false,
		];
		$this->output($data);
	}

	//人物配置
	public function doPageFigureConfig()
	{
		$kv_list = pdo_getall("yf_chengyu_kv", ["key"=>["allList", "houseList", "carList", "jobList"]]);
		$tmp = [];
		foreach($kv_list as $val)
		{
			$tmp[$val["key"]] = json_decode($val["value"], true);
		}
		$kv_list = $tmp;

		$data = [
			"baseUrl" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/figure-v2/",
			"allList" => $kv_list["allList"],
			"carList" => $kv_list["carList"],
			"houseList" => $kv_list["houseList"],
			"jobList" => $kv_list["jobList"],
		];
		$this->output($data);
	}

	//好友列表能量配置
	public function doPageInviteFriendListV2()
	{
		$data = [
			"totalValue" => 0,//当前邀请的好友数
			"inviteRecords" => [
				[
					"energyValue" => 2,
					"inviteIndex" => 1,
				],
				[
					"energyValue" => 2,
					"inviteIndex" => 2,
				],
				[
					"energyValue" => 2,
					"inviteIndex" => 3,
				],
				[
					"energyValue" => 2,
					"inviteIndex" => 4,
				],
				[
					"energyValue" => 2,
					"inviteIndex" => 5,
				],
			],
		];
		$this->output($data);
	}

	//分享得能量策略
	public function doPageShareAddEnergyStrategy()
	{
		$data = [
			"addValue" => 2,
			"canSuccessShare" => 1,
			"failRate" => "0.0",
			"isFirst" => 1,
			"leftTimes" => 99,
			"successRate" => "1.0",
			"timeInterVal" => 3000,
			"textList" => ["分享失败，请分享到群聊", "请勿重复分享，换一个群试试吧", "今天这个群分享过了，换一个群试试吧"],
		];
		$this->output($data);
	}

	public function doPageGuideList()
	{
		$data = [
			"microInput" => 1,
			"noEnergy" => 1,
			"addIdiom" => 1,
		];
		$this->output($data);
	}

	//活动
	public function doPageDetail()
	{
		$data = [
			"detail" => [
				"achieveNum" => 5129,
				"finishTime" => 1565539200000,
				"id" => "100002",
				"lotteryTime" => 1565600400000,
				"startTime" => 1564329600000,
				"totalReward" => 1000000,
				"passLevel" => 11,
				"percent" => 0,
				"word" => [
					[
						"filePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_1_on.png",
						"level" => 1,
						"lockFilePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_1_off.png",
						"word" => "学",
					],
					[
						"filePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_2_on.png",
						"level" => 8,
						"lockFilePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_2_off.png",
						"word" => "海",
					],
					[
						"filePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_3_on.png",
						"level" => 30,
						"lockFilePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_3_off.png",
						"word" => "无",
					],
					[
						"filePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_4_on.png",
						"level" => 60,
						"lockFilePath" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/config/activity/a1_4_off.png",
						"word" => "涯",
					],
				],
			],
			"rules" => [
				[
					"title" => "一、活动时间",
					"content" => ["游戏时间:2019-07-29 到 2019-08-12 00:00", "开奖时间：2019-08-12 17:00"],
				],
				[
					"title" => "二、参与活动",
					"content" => ["1.活动期间通过60关即可分批开启四个宝箱，集齐字块（学海无涯）参与瓜分奖学金","2.超过60关后通关数越多，瓜分到的奖学金将越高", "3.在活动开始前已经达到60关的用户，可直接进入活动页面开宝箱获得瓜分名额"],
				],
				[
					"title" => "三、申请提现",
					"content" => ["提现时间：2019-08-12 17:00 到 2019-08-18", "活动奖金支持提现到微信钱包，可根据活动页面引导完成提现", "到账时间：申请后1-3个工作日到账，可关注公众号“成语状元榜”查看提现进度", "温馨提示：请在开奖后尽快提现，超过提现时间过期不补"],
				],
				[
					"title" => "四、其他说明",
					"content" => ["1.本活动无需用户承担任何费用，请勿相信非官方渠道的任何收费邀请", "2.本次活动最终解释权归活动主办方深圳小序科技所有"],
				],
			],
			"users" => [
				[
					"nickName"=>"秋执", 
					"avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/LqUcTySWAzChDtrLs9J1fUsria1R1QemeewgGy0sZCbw3AuXwP0S93rZF9PAzRhiacY9HthcT59rfH0eKo73WicQQ/132"
				],
				[
					"nickName"=>"ik", 
					"avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/rSeibcicPmtncTYuSfT3r5ByHYwAtMkgSPQIMDopfJw2NUXXMicgcqoPX1HM2ooxvOeicrDdJzyTYOGophq2xFTMdA/132"
				],
				[
					"nickName"=>"Daniel", 
					"avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/LqUcTySWAzChDtrLs9J1fUsria1R1QemeewgGy0sZCbw3AuXwP0S93rZF9PAzRhiacY9HthcT59rfH0eKo73WicQQ/132"
				],
				[
					"nickName"=>"意中人", 
					"avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/LqUcTySWAzChDtrLs9J1fUsria1R1QemeewgGy0sZCbw3AuXwP0S93rZF9PAzRhiacY9HthcT59rfH0eKo73WicQQ/132"
				],
			],
		];
		$this->output($data);
	}

	//广告配置
	public function doPageShareVideoRule()
	{
		$banner = $this->platform_row["banner_adunit"];
		$video = $this->platform_row["video_adunit"];
		$chaping = $this->platform_row["chaping_adunit"];
		$data = [
			"activityOpenBox" => $banner?2:0,
			"activityShare" => $banner?2:0,

			"canWatchVideo" => $video?1:0,
			"dailySign" => $banner?2:0,
			"doubleEnergy" => 0,
			"energyShortage" => $banner?4:0,
			"gameRemind" => $video?2:0,//2:视频 其他:分享
			"jsOpenBox" => $banner?2:0,
			"lightScholar" => $banner?2:0,
			"loginAward" => 2,
			"watchVideo" => $video?2:0,
			"adv" => [
				"activityAdv" => $video,
				"dailySignAdv" => $video,
				"doubleEnergyAdv" => $video,
				"gameRemindAdv" => $video,
				"lightScholarAdv" => $video,
				"loginAwardAdv" => $video,
				"energyShortageAdv" => $video,
				"watchVideoAdv" => $video,
				"activityBanner" => $banner,
				"commonBanner" => $banner,
				"dailyLoginBanner" => $banner,
				"dailySignBanner" => $banner,
				"energyShortageBanner" => $banner,
				"figureLevelBanner" => $banner,
				"figureUpgradeBanner" => $banner,
				"freeEnergyBanner" => $banner,
				"gameOverBanner" => $banner,
				"mixinBanner" => $chaping,
				"scholarBanner" => $banner,
				"tableScreenBanner" => $chaping,
				"tryBackBanner" => $banner,
				"tryGameBanner" => $banner,
			],
		];
		$this->output($data);
	}

	public function doPagePlayer()
	{
		//获取房子车子job的列表
		$kv_list = pdo_getall("yf_chengyu_kv", ["key"=>["houseList", "carList", "jobList"]]);
		$tmp = [];
		foreach($kv_list as $val)
		{
			$t1 = json_decode($val["value"], true);
			$t3 = [];
			foreach($t1 as $t2)
			{
				$t3[$t2["index"]] = $t2;
			}
			$tmp[$val["key"]] = $t3;
		}
		$kv_list = $tmp;

		$carList = $kv_list["carList"];
		$houseList = $kv_list["houseList"];
		$jobList = $kv_list["jobList"];
		
		//获取用户列表
		$level = $this->user_row["level"];//当前等级
		$car_index = $this->user_row["car_index"];//车子等级
		$house_index = $this->user_row["house_index"];//房间等级	
		$job_index = $this->user_row["job_index"];//人物等级

		//car
		//存在下一个等级
		if($carList[$car_index+1])
		{
			$nextIndex = $car_index+1;
			$achieve = $carList[$nextIndex]["level"]-$level;
			$achieve = $achieve < 0 ? 0 : $achieve;
			$car = [
				"achieve" => $achieve,
				"nextIndex" => $nextIndex,
				"nextLevel" => $carList[$nextIndex]["level"],
				"nextName" => $carList[$nextIndex]["name"],
				"tip" => "再过{$achieve}关即可升级座驾",
				"curIndex" => $car_index,
				"curName" => $carList[$car_index]?$carList[$car_index]["name"]:"未解锁",
				"type" => 3,
			];
		}else{//满级
			$car = [
				"curIndex" => $car_index,
				"curName" => $carList[$car_index]?$carList[$car_index]["name"]:"未解锁",
				"type" => 3,
			];
		}

		// pr($car);exit;

		//house
		if($houseList[$house_index+1])
		{
			$nextIndex = $house_index+1;
			$achieve = $houseList[$nextIndex]["level"]-$level;
			$achieve = $achieve < 0 ? 0 : $achieve;
			$house = [
				"achieve" => $achieve,
				"curIndex" => $house_index,
				"curName" => $houseList[$house_index]?$houseList[$house_index]["name"]:"未解锁",
				"nextIndex" => $nextIndex,
				"nextLevel" => $houseList[$nextIndex]["level"],
				"nextName" => $houseList[$nextIndex]["name"],
				"tip" => "再过{$achieve}关即可升级房屋",
				"type" => 2,
			];
		}else{
			$house = [
				"curIndex" => $house_index,
				"curName" => $houseList[$house_index]?$houseList[$house_index]["name"]:"未解锁",
				"type" => 2,
			];
		}

		// pr($house);exit;

		//job
		if($jobList[$job_index+1])
		{
			$nextIndex = $job_index+1;
			$achieve = $jobList[$nextIndex]["level"]-$level;
			$achieve = $achieve < 0 ? 0 : $achieve;
			$job = [
				"achieve" => $achieve,
				"curIndex" => $job_index,
				"curName" => $jobList[$job_index]["name"],
				"nextIndex" => $nextIndex,
				"nextLevel" => $jobList[$nextIndex]["level"],
				"nextName" => $jobList[$nextIndex]["name"],
				"tip" => "再过{$achieve}关即可升级官职",
				"type" => 1,
			];	
		}else{
			$job = [
				"curIndex" => $job_index,
				"curName" => $jobList[$job_index]["name"],
				"type" => 1,
			];
		}

		// pr($job);exit;

		//获取免费能量推荐上面的广告
		$moregame_row = pdo_get("yf_chengyu_moregame", ["recommend"=>1, "miniapp"=>$this->miniapp]);
		$navigateApp = [];
		if($moregame_row)
		{
			$navigateApp = [
				"recommend" => 1,
				"envVersion" => $moregame_row["envVersion"],
				"gameAppid" => $moregame_row["gameAppid"],
				"gameIcon" => getImage($moregame_row["gameIcon"], 0),
				"gameQrcode" => getImage($moregame_row["gameQrcode"], 0),
				"gameName" => $moregame_row["gameName"],
				"gamePath" => $moregame_row["gamePath"],
			];	
		}

		$daTiEnable = false;
		if( ! $this->user_row["nickname"] && $this->user_row["level"] >= 50)
		{
			$daTiEnable = true;
		}

		//客服
		$show_kefu = 0;
		$kv_row = pdo_get("yf_chengyu_kv", ["key"=>"kefu_{$this->miniapp}"]);
		if($kv_row)
		{
			$value = json_decode($kv_row["value"], true);
			$show_kefu = intval($value["open"]);
		}

		$data = [
			"show_kefu" => $show_kefu,
			"daTiEnable" => $daTiEnable,//去答题是否需要授权, true授权 false:不需要授权  首页
			"activityEnable" => false,
			"activityTip" => "再过49关即可开启字块参与瓜分万元奖学金",
			"advAuditSwitch" => false,//true:直接提示 提示已经用完 false:看视频or分享群
			"background" => "home-bj2@2x.png?ver=190704",
			"canPopActivityWindow" => false,
			"canPopLoginAward" => false,
			"canPopWeekScholar" => false,
			"car" => $car,
			"cityRank" => false,
			"dayPass" => 0,
			"energyAllCountDown" => 0,
			"energyCountDown" => 0,
			"energyExtraValue" => 0,
			"energyMaxValue" => 5,
			"energyTotal" => intval($this->user_row["energy"]),
			"energyValue" => intval($this->user_row["energy"]),
			"finishPageStrategy" => [0=>-1, 14=>3, 31=>2, 51=>1, 99=>1],
			"gzhEnergy" => 0,
			"gzhSign" => false,
			"hostUrl" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/shareCard/",
			"house" => $house,
			"howToPlayPop" => false,
			"iosPay" => false,
			"isBeta" => false,
			"isCollectGame" => 0,
			"isSubscribe" => true,//true:不显示公众号按钮 false:显示公众号按钮
			"loseUserStrategy" => [
				"figureLevelGuide" => 8,
				"firstFinish" => 8,
				"firstLevel" => 15,
				"homePageUpgrade" => 8,
				"secondFinish" => 10,
				"secondLevel" => 10,
			],
			//免费能量上面的广告
			"navigateApp" => $navigateApp,
			"nextBackground" => "home-bj2@2x.png?ver=190704",
			"nextLevel" => $this->user_row["level"]+1,
			"nextUnlock" => intval($this->user_row["nextUnlock"]),//0:需要消耗能量, 1不需要消耗能量
			"nickname" => $this->user_row["nickname"],
			"passLevel" => $this->user_row["level"],
			"payEnable" => false,
			"position" => $job,
			"quitGameFlag" => false,
			"recoverTime" => 1200,
			"scholarSwitch" => false,//状元榜是否开启
			"shareCards" => [
				"config/share_card_1.png", "config/share_card_2.png"
			],
			"shareForbidden" => false,
			"shareTitles" => [
				"快来！升官买房娶妻都在这里！", "太难了！求求你帮我解一下这题~"
			],
			"showId" => $this->user_row["id"],
			"sign" => false,
			"signDays" => 1,
			"signReward" => [1,1,1,1,1,1,1],
			"tipItem" => [
				"brokenSign" => false,
				"discounts" => "0.0",
				"originalPrice" => "6.0",
				"price" => "3.0",
				"propFlag" => 0,
				"propId" => 30001,
				"propName" => "购买10点提醒",
				"propType" => 3,
				"propValue" => 10,
				"recharge" => false,
				"remark" => "",
				"saleNum" => 193,
			],
			"userId" => $this->user_row["id"],
			"yearCardUser" => false,
		];

		$this->output($data);
	}

	public function doPagePreviewLevel()
	{
		$level = $this->user_row["level"]+1;

		$row = pdo_get("yf_chengyu_level", ["id"=>$level]);
		if( ! $row)
		{
			$yushu = $level%1000;
			$level2 = $yushu+2000;
			$row = pdo_get("yf_chengyu_level", ["id"=>$level2]);
			while (true) {
				if($row) break;
				$level2 = rand(2000, 3000);
				$row = pdo_get("yf_chengyu_level", ["id"=>$level2]);
			}
		}

		$asrEnable = false;
		if($row["level"] > 10)
		{
			$asrEnable = true;
		}

		if($asrEnable)
		{
			$kv_row = pdo_get("yf_chengyu_kv", ["key"=>"kefu_{$this->miniapp}"]);
			if($kv_row)
			{
				$value = json_decode($kv_row["value"], true);
				if( ! intval($value["recognize"]))
				{
					$asrEnable = false;
				}
			}
		}

		$data = [
			"id" => intval($row["id"]),
			"level" => intval($row["level"]),
			"asrEnable" => $asrEnable,//不显示语音识别
			"idiom" => json_decode($row["idiom"], true),
			"answer" => json_decode($row["answer"], true),
			"gameBox" => json_decode($row["gameBox"], true),
		];

		$this->output($data);
	}

	public function doPageMakeEnergy()
	{
		$res = "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/";
		$data = [];
		if($this->platform_row["video_adunit"])
		{
			$data[] = [
				"buttonImg"=> "{$res}makeEnergy/quget.png",
				"buttonType"=> 0,
				"curValue"=> 0,
				"energyValue"=> 2,
				"imageUrl"=> "{$res}makeEnergy/icon_video.png",
				"listIndex"=> 8,
				"sectionType"=> "watchVideo",
				"title"=> "观看视频得能量",
				"upperValue"=> 5,
			];
		}
		$data[] = [
			"buttonImg"=> "{$res}makeEnergy/quinvite.png",
			"buttonType"=> 0,
			"energyValue"=> 2,
			"imageUrl"=> "{$res}makeEnergy/icon_frihelp.png",
			"listIndex"=> 1,
			"sectionType"=> "friend",
			"title"=> "好友助力得能量",
		];
		$data[] = [
			"buttonImg"=> "{$res}makeEnergy/quinvite.png",
			"buttonType"=> 0,
			"energyValue"=> 6,
			"imageUrl"=> "{$res}makeEnergy/icon_invitenew.png",
			"listIndex"=> 10,
			"sectionType"=> "inviteNewUser",
			"title"=> "邀请新用户奖励",
		];
		// $data[] = [
		// 	"buttonImg"=> "{$res}makeEnergy/qusign.png",
		// 	"buttonType"=> 0,
		// 	"energyValue"=> 1,
		// 	"imageUrl"=> "{$res}makeEnergy/icon_sign.png",
		// 	"listIndex"=> 2,
		// 	"sectionType"=> "dailySign",
		// 	"title"=> "每日签到得能量",
		// ];

		$this->output($data);
	}

	public function doPageGetShareResult()
	{
		$list = pdo_getall("yf_chengyu_share");
		$data = [];
		foreach($list as $val)
		{
			$data[$val["position"]] = [
				"id" => $val["id"],
				"title" => $val["title"],
				"position" => $val["position"],
				"imageUrl" => $this->w["siteroot"].trim($val["imageUrl"],"/"),
			];
		}
		$this->output($data);
	}

	public function doPageTableScreenStrategy2()
	{
		$data = [0=>-1, 14=>3, 21=>2, 31=>1, 1000=>0];
		$this->output($data);
	}

	public function doPageMoreGame()
	{
		$list = pdo_getall("yf_chengyu_moregame", ["miniapp"=>$this->miniapp]);
		$data = [];
		if($list)
		{
			foreach($list as $val)
			{
				$data[] = [
					"gameName" => $val["gameName"],
					"gameAppid" => $val["gameAppid"],
					"gameIcon" => getImage($val["gameIcon"], 0),
					"gameQrcode" => getImage($val["gameQrcode"], 0),
					"envVersion" => $val["envVersion"],
					"gamePath" => $val["gamePath"],
					"playDesc" => $val["playDesc"],
					"redPoint" => intval($val["redPoint"]),
				];
			}	
		}

		$this->output($data);
	}

	public function doPageGameLevel()
	{
		$this->doPagePreviewLevel();
	}

	//用户的提示符数量
	public function doPageTipNumber()
	{
		if($_GET["operation"] == "cost")
		{
			if($this->user_row["tipNumber"] > 0)
				pdo_update("yf_chengyu_user", ["tipNumber"=>$this->user_row["tipNumber"]-1], ["id"=>$this->user_row["id"]]);
		}
		$this->user_row = pdo_get("yf_chengyu_user", ["openid"=>$this->openid]);
		$data = [
			"tipNumber" => $this->user_row["tipNumber"],
			"canGet" => true,
		];
		$this->output($data);
	}

	//小程序卡片ID
	public function doPageUploadFormId()
	{
		$formId = $_GET["formId"];
		if(strpos($formId, "formId")) $this->output();
		$form_ids = [$formId=>0];
		
		//save form_id
		$message_row = pdo_get("yf_chengyu_message", ["openid" => $this->openid]);
		if($message_row)
		{
			$form_arr = json_decode($message_row["form_id"], true);
			foreach($form_arr as $key=>$val)
			{
				if($val == 0)
				{
					$form_ids[$key] = 0;
				}
				if(count($form_ids) >= 7)
				{
					break;
				}
			}
			$params = [
				"form_id" => json_encode($form_ids),
				"status" => 0,
			];
			pdo_update("yf_chengyu_message", $params, ["id"=>$message_row["id"]]);
		}else{
			$params = [
				"miniapp" => $this->miniapp,
				"openid" => $this->openid,
				"form_id" => json_encode($form_ids),
				"status" => 0,
			];
			pdo_insert("yf_chengyu_message", $params);
		}

		$this->output();
	}

	public function doPageGamePageShareRealPop()
	{
		$data = ["isEnergy"=>false, "isTips"=>false];
		$this->output($data);
	}

	public function doPageFinishPageImg()
	{
		$res = "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/";
		$data = [
			"imgUrl" => "{$res}finishPageShare/20226148_11.jpg",
		];
		$this->output($data);
	}

	public function doPageFinishPageInfo()
	{
		$data = [
			"shareId" => 1000,
			"shareTitle" => "%s这个成语还有另外含义80%的人都不知道",
			"showPop" => true,
			"showResult" => true,
		];
		$this->output($data);
	}

	//成语解释
	public function doPageExplanation()
	{
		$word = trim($_GET["word"]);
		if( ! $word) $this->fail("参数有误");

		$idiom_row = pdo_get("yf_chengyu_idiom", ["word"=>$word]);
		$params = [
			"miniapp" => $this->miniapp,
			"openid" => $this->openid,
			"idiomId" => $idiom_row["id"],
		];
		$row = pdo_get("yf_chengyu_idiom_user" , $params);
		$collect = $row?true:false;
		$data = [
			"id" => $idiom_row["id"],
			"word" => $idiom_row["word"],
			"pinyin" => $idiom_row["pinyin"],
			"collect" => $collect,
			"derivation" => $idiom_row["derivation"],
			"explanation" => $idiom_row["explanation"],
			// "shareCard" => "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/shareCard/config/share_card_1.png",
			"shareTitle" => ["我又学会一个新成语，快来看看你认不认识？"],
		];
		$this->output($data);
	}

	//添加到生词本
	public function doPageAddVocab()
	{
		$idiomId = intval($_GET["idiomId"]);

		//获取生词信息
		$idiom_row = pdo_get("yf_chengyu_idiom", ["id"=>$idiomId]);
		if( ! $idiom_row) $this->fail("生词ID不存在");

		$params = [
			"miniapp" => $this->miniapp,
			"openid" => $this->openid,
			"idiomId" => $idiomId,
		];
		$row = pdo_get("yf_chengyu_idiom_user" , $params);
		if( ! $row)
		{
			$params["word"] = $idiom_row["word"];
			$params["firstLetter"] = substr($idiom_row["pinyin"], 0, 1);
			$params["collect"] = $idiom_row["collect"];
			pdo_insert("yf_chengyu_idiom_user", $params);
		}

		$this->output();
	}

	public function doPageAddGuide()
	{
		$this->output();
	}

	//删除生词本
	public function doPageDropVocab()
	{
		$idiomId = intval($_GET["idiomId"]);

		$params = [
			"miniapp" => $this->miniapp,
			"openid" => $this->openid,
			"idiomId" => $idiomId,
		];
		$row = pdo_get("yf_chengyu_idiom_user" , $params);
		if($row)
		{
			pdo_delete("yf_chengyu_idiom_user", ["id"=>$row["id"]]);
		}

		$this->output();
	}

	//能量特卖
	public function doPagePropStore()
	{
		$data = [
			"discountPop" => false,
			"hasDiscount" => false,
			"propItems" => [
				[
					"brokenSign"=> false,
					"deleteStatus"=> 0,
					"discounts"=> "0.0",
					"originalPrice"=> "3.0",
					"price"=> "3.0",
					"propFlag"=> 0,
					"propId"=> 10003,
					"propName"=> "单次购买",
					"propType"=> 1,
					"propValue"=> 5,
					"recharge"=> false,
					"remark"=> "购买5点能量",
					"saleNum"=> 1341,
				],
				[
					"brokenSign"=> false,
					"deleteStatus"=> 0,
					"discounts"=> "0.0",
					"originalPrice"=> "18.0",
					"price"=> "18.0",
					"propFlag"=> 0,
					"propId"=> 20002,
					"propName"=> "能量周卡",
					"propType"=> 2,
					"propValue"=> 10,
					"recharge"=> false,
					"remark"=> "每天10点额外能量",
					"saleNum"=> 0,
				],
				[
					"brokenSign"=> false,
					"deleteStatus"=> 0,
					"discounts"=> "10.0",
					"minPrice"=> "0.1",
					"originalPrice"=> "99.0",
					"price"=> "39.0",
					"propFlag"=> 0,
					"propId"=> 40001,
					"propName"=> "无限能量年卡",
					"propType"=> 4,
					"propValue"=> 999,
					"recharge"=> false,
					"remark"=> "全年无限畅玩",
					"saleNum"=> 36,
				],
				[
					"brokenSign"=> false,
					"deleteStatus"=> 0,
					"discounts"=> "0.0",
					"originalPrice"=> "3.0",
					"price"=> "1.0",
					"propFlag"=> 2,
					"propId"=> 50003,
					"propName"=> "新用户专享",
					"propType"=> 1,
					"propValue"=> 5,
					"recharge"=> false,
					"remark"=> "",
					"saleNum"=> 1709,
				],
			],
			"tips" => ["无限能量年卡已下单", "购买年卡支付成功", "签到达标已申请退款", "签到达标退款已到账", "获得限时优惠券", "限时优惠券已到期"],
			"users" => [
				["nickName"=>"南桥小生","avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIRJdDiactyiaFfnCak29uhIepibiaGPZx2rZ9oRoKkCepYUH8vLLCw0fCa4kDyos9a91FjmJF1iaMedmQ/132"],
				["nickName"=>"Niki","avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eohMLSUNInPs07z6oMuQPgjgF31kNXTiccFuPO7ibXuEFoIqwj3QEEfDEGMUUCUTgFekbIre8XwQMuQ/132"],
				["nickName"=>"唯一^O^","avatarUrl"=>"https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83erCRfiauj0qCjztCRP1iaAEjTw11T4fIaVPsIIgOiaSJ5iatHT5liccSYia43YfZPNEhyjSsKq8R4w8zbBg/132"],
			],
		];
		$this->output($data);
	}

	//支付
	public function doPagePrepay()
	{
		$data = [
			"code" => 0,
			"payWay" => 0,
			"prepayNo" => "6c25634cab7a4a79",
			"jsPay" => [
				"appId" => "wxd4c69125afec545e",
				"nonceStr" => "b1ce5437caac4dad8b3383fd9de62095",
				"package" => "prepay_id=wx2910115909875272f3082dbb1178638900",
				"paySign" => "79F8FBB26ACCDDAB5633B4DF4B4A0487",
				"signType" => "MD5",
				"timeStamp" => "1567044719",
			],
		];
		$this->output();
	}

	//免费能量 好友助力
	public function doPageClickInvitedBtn()
	{
		$this->output();
	}

	//免费能量 观看视频
	public function doPageShareVideoDynamicControl()
	{
		$this->output();
	}

	//免费能量 
	public function doPageMakeEnergyWatchVideo()
	{
		$data = [
			"awardValue" => 2,
			"awardType" => 1,
		];
		$this->output($data);
	}

	//免费能量 邀请好友
	public function doPageInvShareRandomTxt()
	{
		$data = [
			["邗斐", "4次", "6点"],
			["洋涵涤", "4次", "6点"],
			["乌雅兴安", "2次", "6点"],
			["巨林", "3次", "6点"],
		];
		$this->output($data);
	}

	//生词本
	public function doPageGetVocab()
	{
		$list = pdo_getslice("yf_chengyu_idiom_user", ["openid"=>$this->openid], [0, 300]); 
		$idioms = [];
		foreach($list as $val)
		{
			$idioms[$val["firstLetter"]][] = ["id"=>intval($val["id"]),"word"=>$val["word"],"firstLetter"=>$val["firstLetter"],"collect"=>intval($val["collect"])];
		}
		
		//获取成语信息
		$data = [
			"current" => count($list),
			"max" => 300,
			"data" => $idioms,
		];
		$this->output($data);
	}

	public function doPagePass()
	{
		$level = $this->user_row["level"]+1;
		$params = [
			"level" => $level,
			"nextUnlock" => 0,
		];
		pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);

		$kv_row = pdo_get("yf_chengyu_kv", ["key"=>"allList"]);
		$value = json_decode($kv_row["value"], true);
		$tmp = [];
		foreach($value as $val)
		{
			$tmp[$val["level"]] = $val;
		}
		$value = $tmp;
		ksort($value);
		$tip = "";
		$upgrade = false;
		foreach($value as $val)
		{
			if($val["level"] > $level)
			{
				$tip = "再过".($val["level"]-$level)."关即可升级{$val["name"]}";
				break;
			}
			if($val["level"] == $level) $upgrade = true;
		}

		//每日排行榜
		$params = ["openid"=>$this->openid, "ts_post"=>date("Ymd")];
		$rank_row = pdo_get("yf_chengyu_per_rank", $params);
		if( ! $rank_row)
		{
			$params = [
				"miniapp" => $this->miniapp,
				"openid"=>$this->openid, 
				"ts_post"=>date("Ymd"),
				"level" => 1,
		];
			pdo_insert("yf_chengyu_per_rank", $params);
		}else{
			$level = $rank_row["level"] + 1;
			pdo_update("yf_chengyu_per_rank", ["level"=>$level], ["id"=>$rank_row["id"]]);
		}

		$daTiFinishEnable = false;
		if( ! $this->user_row["nickname"] && $level > 3)//N+1关 开启授权
		{
			$daTiFinishEnable = true;
		}
		if($daTiFinishEnable)
		{
			$kv_row = pdo_get("yf_chengyu_kv", ["key"=>"kefu_{$this->miniapp}"]);
			if($kv_row)
			{
				$value = json_decode($kv_row["value"], true);
				if( ! intval($value["auth"]))
				{
					$daTiFinishEnable = false;
				}
			}
		}

		$data = [
			"daTiFinishEnable" => $daTiFinishEnable,//去答题是否需要授权, true授权 false:不需要授权  答题页面
			"activityEnable" => false,
			"code" => 0,
			"tip" => $tip,
			"upgrade" => $upgrade,
		];
		$this->output($data);
	}

	//排行榜
	public function doPageRanking()
	{
		$type = intval($_GET["type"]);//0:全服 2:每日闯关

		$world = [];
		$rank = "999+";
		$self = [];
		//全服
		if($type == 0)
		{
			$level = $this->user_row["level"];
			$myrank = 1;
			$sql = "select * from `ims_yf_chengyu_user` where nickname<>'' and miniapp='{$this->miniapp}' order by level desc limit 100"; 
			$list = pdo_fetchall($sql);
			foreach($list as $val)
			{
				if($val["level"] > $level)
				{
					$myrank ++;
				}
				$world[] = [
					"id"=> $val["id"],
					"nickName"=> $val["nickname"] ? $val["nickname"] : "匿名",
					"avatarUrl"=> $val["avatar_url"],
					"passLevel"=> $val["level"],
				];
			}	

			//自己
			$rank = "999+";
			if($level && $myrank) $rank = "{$myrank}";
			$self = [
				"nickName" => $this->user_row["nickname"],
				"passLevel" => $this->user_row["level"],
				"rank" => $rank,
				"avatarUrl" => $this->user_row["avatar_url"],
			];
		}
		//每日闯关
		if($type == 2)
		{
			$date = trim($_GET["date"]) ? trim($_GET["date"]) : date("Ymd");//日期
			$sql = "select * from `ims_yf_chengyu_per_rank` where ts_post={$date} and miniapp='{$this->miniapp}' order by level desc limit 100";
			$list = pdo_fetchall($sql);
			foreach($list as $val)
			{
				$openids[] = $val["openid"];
			}

			$user_list = pdo_getall("yf_chengyu_user", ["openid"=>$openids]);
			$tmp = [];
			foreach($user_list as $val)
			{
				$tmp[$val["openid"]] = $val;
			}
			$user_list = $tmp;

			$rank_row = pdo_get("yf_chengyu_per_rank", ["openid"=>$this->user_row["openid"], "ts_post"=>$date]);
			$passLevel = intval($rank_row["level"]);
			$myrank = 1;
			foreach($list as $val)
			{
				if( ! $user_list[$val["openid"]]["nickname"]) continue;

				if($val["level"] > $passLevel)
				{
					$myrank ++;
				}

				$world[] = [
					"id"=> $val["id"],
					"nickName"=> $user_list[$val["openid"]]["nickname"]?$user_list[$val["openid"]]["nickname"]:"匿名",
					"avatarUrl"=> $user_list[$val["openid"]]["avatar_url"],
					"passLevel"=> $val["level"],
				];
			}	

			//自己
			$rank = "999+";
			if($passLevel && $myrank) $rank = "{$myrank}";
			$self = [
				"nickName" => $this->user_row["nickname"],
				"avatarUrl" => $this->user_row["avatar_url"],
				"passLevel" => $passLevel,
				"rank" => $rank,
			];
		}

		$data = [
			"rank" => $rank,
			"self" => $self,
			"world" => $world,
		];
		$this->output($data);
	}

	public function doPageGetEnergyByInvite()
	{

	}

	public function doPageGetAllEnergyByInvite()
	{

	}

	//好友助力
	public function doPageInviteFriend()
	{
		$uid = intval($_GET["inviterId"]);
		
		$user_row = pdo_get("yf_chengyu_user", ["id"=>$uid]);
		//不能自己给自己分享
		if($user_row && $user_row["id"] != $this->user_row["id"] && $this->user_row["helpTime"]+600 < time())
		{
			//帮助的人(自己)添加1点能量
			$energy = min(50, $this->user_row["energy"]+1);
			$params = ["energy"=>$energy, "helpTime"=>time()];
			pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);

			//被帮助的人添加2点能量
			$energy = min(50, $user_row["energy"]+2);
			$params = ["energy"=>$energy];
			pdo_update("yf_chengyu_user", $params, ["id"=>$user_row["id"]]);
		}
		$this->output();
	}

	public function doPageInviteNewUser()
	{
		$uid = intval($_GET["inviterId"]);
		
		$user_row = pdo_get("yf_chengyu_user", ["id"=>$uid]);

		//好友信息
		$params = [
			"openid1" => $user_row["openid"],//邀请人
			"openid2" => $this->user_row["openid"],//被邀请人
		];
		$friends_row = pdo_get("yf_chengyu_friends", $params);

		//新用户
		if( ! $friends_row && $user_row && $user_row["id"] != $this->user_row["id"] && $this->user_row["register_time"]+5*60 > time())
		{
			//帮助的人(自己)添加1点能量
			$energy = min(50, $this->user_row["energy"]+1);
			$params = ["energy"=>$energy];
			pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);

			//被帮助的人添加6点能量
			$energy = min(50, $user_row["energy"]+6);
			$params = ["energy"=>$energy];
			pdo_update("yf_chengyu_user", $params, ["id"=>$user_row["id"]]);

			//添加好友信息
			$params = [
				"miniapp" => $this->miniapp,
				"openid1" => $user_row["openid"],//邀请人
				"openid2" => $this->user_row["openid"],//被邀请人
			];
			pdo_insert("yf_chengyu_friends", $params);
		}

		$this->output();
	}

	public function doPageGetAllNewUserInviteEnergy()
	{

	}
	//升级
	public function doPageUpgrade()
	{
		//car:3 house:2 job:1
		$type = intval($_GET["type"]);
		if( ! in_array($type, [1,2,3]))
		{
			$this->fail("error_type");
		}
		$car_index = $this->user_row["car_index"];
		$house_index = $this->user_row["house_index"];
		$job_index = $this->user_row["job_index"];
		$nextIndex = 0;
		$key = "";
		if($type == 1)
		{
			$nextIndex = $job_index += 1;
			$key = "jobList";
		}
		if($type == 2)
		{
			$nextIndex = $house_index += 1;
			$key = "houseList";
		}
		if($type == 3)
		{
			$nextIndex = $car_index += 1;
			$key = "carList";
		}
		if( ! $key) $this->fail("参数错误");
		$kv_row = pdo_get("yf_chengyu_kv", ["key"=>$key]);
		$value = json_decode($kv_row["value"], true);
		$tmp = [];
		foreach($value as $val)
		{
			$tmp[$val["index"]] = $val;
		}
		$value = $tmp;
		if( ! $value[$nextIndex]) $this->fail("已经是最高等级了");

		$params = [
			"car_index" => $car_index,
			"house_index" => $house_index,
			"job_index" => $job_index,
		];
		pdo_update("yf_chengyu_user", $params, ["id"=>$this->user_row["id"]]);

		$data = [
			"nextIndex" => $nextIndex++,
		];
		$this->output($data);
	}

	//看视频获取能量
	public function doPageShareAddEnergy()
	{
		$data = [
			"addValue" => 2,
			"leftTimes" => 99,
			"canSuccessShare" => 1,
			"failRate" => "0.0",
			"isFirst" => 1,
			"successRate" => "1.0",
			"timeInterVal" => 3000,
			"textList" => ["分享失败，请分享到群聊", "请勿重复分享，换一个群试试吧", "今天这个群分享过了，换一个群试试吧"],
		];
		$this->output($data);
	}

	public function doPageCollectGame()
	{

	}

	public function doPageAddFloatWindow()
	{

	}

	public function doPageDailyLoginAward()
	{

	}

	public function doPageAddShareVideoTimes()
	{

	}
	//头像上传
	public function doPageUimage()
	{	

		global $_GPC;
        global $_W;
        $uptypes = ["image/jpg", "image/jpeg", "image/png", "image/pjpeg", "image/gif", "image/bmp", "image/x-png"];
        $max_file_size = 2000000;
        $destination_folder = $_GPC["m"] . "/";
        if (!is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
            echo "图片不存在!";
            exit;
        }
        $file = $_FILES["upfile"];
        if ($max_file_size < $file["size"]) {
            echo "文件太大!";
            exit;
        }
        if (!in_array($file["type"], $uptypes)) {
            echo "文件类型不符!" . $file["type"];
            exit;
        }
        if (!file_exists('../attachment/' . $destination_folder)) {
            mkdir("../attachment/" . $destination_folder);
        }
        $filename = $file["tmp_name"];
        $pinfo = pathinfo($file["name"]);
        $ftype = $pinfo["extension"];
        $destination = "../attachment/" . $destination_folder . str_shuffle(time() . rand(111111, 999999)) . "." . $ftype;
        if (!move_uploaded_file($filename, $destination)) {
            echo "移动文件出错";
            exit;
        }
        $pinfo = pathinfo($destination);
        $fname = $pinfo["basename"];
        echo $_W["attachurl"] . $destination_folder . $fname;

	}

	//语音识别
	public function doPageRecognize()
	{
		//start it is mp3
		//mp3
		$filename = FCPATH."resource/voice/{$this->openid}.mp3";
		if(is_file($filename)) unlink($filename);
		move_uploaded_file($_FILES["file"]["tmp_name"], $filename);
		if( ! is_file($filename)) 
		{
			$this->file("文件不存在");
		}

		$access_token = $this->getAccessToken(1);
		$voice_id = md5(time().rand(1000,9999));
		$url = "http://api.weixin.qq.com/cgi-bin/media/voice/addvoicetorecofortext?access_token={$access_token}&format=mp3&voice_id={$voice_id}&lang=zh_CN";
		//上传
		$post = [
			"media" => new \CURLFile($filename),
		];
		$result = http_request($url, $post);

		$txt = "";
		for($i=0; $i<3; $i++)
		{
			sleep(2);
			$url = "http://api.weixin.qq.com/cgi-bin/media/voice/queryrecoresultfortext?access_token={$access_token}&voice_id={$voice_id}&lang=zh_CN";
			$result = http_request($url);
			$result = json_decode($result, true);
			if($result["errcode"]) continue;
			$txt = $result["result"];
			if($result["result"]) break;
		}
		$txt = str_replace("。", "", $txt);
		$txt = trim($txt);
		//end it is mp3
		// $txt = "厚积薄发";

		//获取用户当前的成语
		$level = $this->user_row["level"]+1;

		$row = pdo_get("yf_chengyu_level", ["id"=>$level]);
		if( ! $row)
		{
			$yushu = $level%1000;
			$level2 = $yushu+2000;
			$row = pdo_get("yf_chengyu_level", ["id"=>$level2]);
			while (true) {
				if($row) break;
				$level2 = rand(2000, 3000);
				$row = pdo_get("yf_chengyu_level", ["id"=>$level2]);
			}
		}

		$idiom = json_decode($row["idiom"], true);
		$gameBox = json_decode($row["gameBox"], true);
		$answer = json_decode($row["answer"], true);

		//判断是否在成语里面
		if( ! in_array($txt, $idiom))
		{
			$data = [
				"txt" => $txt,
				"level" => $level,
				"pass" => false,
			];
			$this->output($data);
		}

		$txt_arr = str_split($txt, 3);
		//查找x轴是否匹配
		$result = [];
		foreach($gameBox as $key=>$val)
		{
			foreach($val as $k=>$v)
			{
				$v_txt = $v["text"] ? $v["text"] : $v["ans"];
				if( ! $v_txt) continue;
				if($txt_arr[0] == $v_txt)
				{
					//命中了
					$t1 = $val[$k+1]["text"]?$val[$k+1]["text"]:$val[$k+1]["ans"];
					$t2 = $val[$k+2]["text"]?$val[$k+2]["text"]:$val[$k+2]["ans"];
					$t3 = $val[$k+3]["text"]?$val[$k+3]["text"]:$val[$k+3]["ans"];
					if($txt_arr[1] == $t1 && $txt_arr[2] == $t2 && $txt_arr[3] == $t3)
					{
						$ii = 0;
						foreach($val as $k1=>$v1)
						{
							if($k1 < $k) continue;
							if($k1 >= $k+4) continue;

							$ctxt = $gameBox[$key+1][$k1]["ans"]?$gameBox[$key+1][$k1]["ans"]:$gameBox[$key+1][$k1]["text"];
							$cross = $ctxt ? 1 : 0;
							if( ! $cross) 
							{
								$ctxt = $gameBox[$key-1][$k1]["ans"] ? $gameBox[$key-1][$k1]["ans"] : $gameBox[$key-1][$k1]["text"];
								$cross = $ctxt ? 1 : 0;
							}
							$result[] = [
								"actuallyText" => $txt_arr[$ii],
								"canSelect" => $v1["canSelect"],
								"ans" => $v1["ans"]?$v1["ans"]:"",
								"x" => $k1,
								"show" => $v1["show"],
								"cross" => $cross,//y轴是否有成语
								"y" => $key,
								"text" => $v1["text"],
							];
							$ii++;
						}
						break;
					}
				}
			}
			if($result) break;
		}

		//查找y轴是否匹配
		if( ! $result)
		{
			foreach($gameBox as $key=>$val)
			{
				foreach($val as $k=>$v)
				{
					$v_txt = $v["text"] ? $v["text"] : $v["ans"];
					if( ! $v_txt) continue;
					if($txt_arr[0] == $v_txt)
					{
						//命中了
						$t0 = $gameBox[$key][$k]["text"]?$gameBox[$key][$k]["text"]:$gameBox[$key][$k]["ans"];
						$t1 = $gameBox[$key+1][$k]["text"]?$gameBox[$key+1][$k]["text"]:$gameBox[$key+1][$k]["ans"];
						$t2 = $gameBox[$key+2][$k]["text"]?$gameBox[$key+2][$k]["text"]:$gameBox[$key+2][$k]["ans"];
						$t3 = $gameBox[$key+3][$k]["text"]?$gameBox[$key+3][$k]["text"]:$gameBox[$key+3][$k]["ans"];
						if($txt_arr[1] == $t1 && $txt_arr[2] == $t2 && $txt_arr[3] == $t3)
						{
							$yarr = [
								$key=>$gameBox[$key][$k],
								$key+1=>$gameBox[$key+1][$k],
								$key+2=>$gameBox[$key+2][$k],
								$key+3=>$gameBox[$key+3][$k]
							];
							$ii = 0;
							foreach($yarr as $k1=>$v1)
							{
								$ctxt = $gameBox[$k1][$k+1]["ans"]?$gameBox[$k1][$k+1]["ans"]:$gameBox[$k1][$k+1]["text"];
								$cross = $ctxt ? 1 : 0;
								if( ! $cross) 
								{
									$ctxt = $gameBox[$k1][$k-1]["ans"]?$gameBox[$k1][$k-1]["ans"]:$gameBox[$k1][$k-1]["text"];
									$cross = $ctxt ? 1 : 0;
								}
								$result[] = [
									"actuallyText" => $txt_arr[$ii],
									"canSelect" => $v1["canSelect"],
									"ans" => $v1["ans"]?$v1["ans"]:"",
									"x" => $k,
									"show" => $v1["show"],
									"cross" => $cross,//y轴是否有成语
									"y" => $k1,
									"text" => $v1["text"],
								];
								$ii++;
							}
							break;
						}
					}
				}
				if($result) break;
			}
		}

		$data = [
			"result" => $result,
			"level" => $level,
			"pass" => true,
			"idiom" => $txt,
		];

		$this->output($data);
	}

	//开卷有益详细
	public function doPageGetScholarData()
	{
		// echo '{"code":0,"msg":"\u6210\u529F","time":"1567682855193","data":{"userInfo":{"avatarUrl":"https:\/\/wx.qlogo.cn\/mmopen\/vi_32\/DYAIOgq83erlmbX2ibYgmpTopGkhySrlm4JGq061sCBR2PkkK4TKCKTN1l4F1awL5TMia9Wzian2XhFGrPctEOj7A\/132","nickname":"\u674E","selfId":"20226148","passLevel":2959,"userId":"20226148"},"isGet":1,"giveLikeList":[],"medalName":"\u5F00\u5377\u6709\u76CA","LastWeekInterval":["2019-08-26","2019-09-01"],"fake":false,"medalUrl":"https:\/\/cy-res.bleege.com\/cyzyb\/img\/scholar_medal\/kjyy1x.png","figureName":{"positionName":"\u7687\u4E0A","houseName":"\u91D1\u92AE\u6BBF","carName":"\u91D1\u8EAB\u9F99\u8F87"},"worldRankPercent":"0%","weekRecordResult":{"positionNum":1,"LearnChengYuNum":30617,"PassNum":2959,"carNum":1,"loginNum":3,"NewWordsNum":6,"houseNum":1},"bestPassRank":"0"}}';
	}

	public function doPageGetEnergyByGiveLike()
	{

	}

	public function doPageGiveLikeForScholar()
	{

	}

	//点亮
	public function doPageLightUpTheMedal()
	{

	}

	//状元榜
	public function doPageScholarMedalList()
	{
		// echo '{"code":0,"msg":"成功","time":"1567682789095","data":[{"isGet":1,"medalName":"开卷有益","medalUrl":"https:\/\/cy-res.bleege.com\/cyzyb\/img\/scholar_medal\/kjyy1x.png","week":"20190826"}]}';
	}

	public function doPageParticipate()
	{

	}

	public function doPageReward()
	{

	}

	public function doPageGetPrepayStatus()
	{

	}

	public function doPageGetWebPrepay()
	{

	}

	public function doPageSourceReport()
	{

	}

	//没能量
	public function doPageSubEnergyNotify()
	{
		$this->output();
	}

	//去答题没能量
	public function doPageGetSubEnergyNotify()
	{
		$data = ["subSwitch"=>1];//0, 1
		$this->output($data);
	}

	//没能量 弹窗
	public function doPagePopWindowTimes()
	{
		$this->output();
	}

	//没能量
	public function doPageRandomBanner()
	{
		// $data = [
		// 	"bannerType" => "buyYearCard",
		// 	"bannerUrl" => "https://cy-res.bleege.com/cyzyb/img/banner/pop_banner_wxnlcw@2x.png",
		// ];
		$this->output();
	}

	public function doPageGameTryApi()
	{

	}

	public function doPageSharePyq()
	{

	}

	//登录奖励
	public function doPageAbandonDailyLoginAward()
	{
		$this->output();
	}	




	public function doPageYearCardUserSign()
	{

	}

	public function doPagePopDiscountEvent()
	{

	}

	//双倍领取能量
	public function doPageDoubleGetEnergy()
	{
		//领取能量的值
		$value = intval($_GET["value"]);

		$this->output();
	}

	public function doPageClickAddTips()
	{

	}

	public function doPageGamePageShareClick()
	{

	}

	public function doPageSeodata()// seo/data
	{

	}

	public function doPageSuppleMpReward()
	{

	}


	//失败接口
	public function fail($message)
	{
		$result = [
			"code" => 202,
			"msg" => $message,
			"time" => time(),
		];

		echo json_encode($result, JSON_UNESCAPED_UNICODE);
		exit;
	}

	public function output($data=[])
	{
		$result = [
			"code" => 0, 
			"msg" => "操作成功",
			"time" => time(),
			"data" => $data,
		];

		echo json_encode($result, JSON_UNESCAPED_UNICODE);
		exit;
	}

	//发送消息
	public function doPageSend()
	{
		//提醒时间 
		$G = intval(date("G"));
		if($G < 12) exit("error_G {$G} < 12");

		//发送状态为0 且 发送时间小于今天日期
		// $params = array("status"=>0, "ts_post <"=>date("Ymd"));
		// $list = pdo_getslice("yf_chengyu_message", $params, [0, 100]);
		$date = date("Ymd");
		$sql = "select * from ims_yf_chengyu_message where `status`=0 and `ts_post`<'{$date}' order by id asc limit 100";
		$list = pdo_fetchall($sql);
		if( ! $list) return ;
		
		foreach($list as $val)
		{
			$form_ids = json_decode($val["form_id"], true);
			if($form_ids)
			{
				//获取最后一个数组 form_id
				$keys = array_keys($form_ids);
				$form_id = array_pop($keys);
				array_pop($form_ids);
				// pr($form_ids);pr($form_id);exit;

				$access_token = $this->getAccessToken($val["miniapp"]);

				$url = "https://api.weixin.qq.com/cgi-bin/message/wxopen/template/uniform_send?access_token={$access_token}";
				
				//获取小程序信息 
				$platform_row = pdo_get("yf_chengyu_platform", ["miniapp"=>$val["miniapp"]]);
				$template_id  = $platform_row["template_id"];

				$post = array(
					"touser" => $val["openid"],//小程序的openid
					"weapp_template_msg" => array(
						"template_id" => $template_id,//小程序模板ID
						"page" => "pages/index/index",//小程序页面路径
						"form_id" => $form_id,//小程序模板消息formid
						"data" => array(
							"keyword1" => array("value"=>"成语学习计划"),
							"keyword2" => array("value"=>"您今天的成语学习计划已经安排好了,点击进入学习"),
						),//程序模板数据
						"emphasis_keyword" => "",//小程序模板放大关键词
					),
				);
				//获取用户是否允许推送
				$result = http_request($url, json_encode($post, JSON_UNESCAPED_UNICODE));
				$result = json_decode($result, true);
			}

			$params = array("form_id"=>json_encode($form_ids), "ts_post"=>date("Ymd"));
			if( ! $form_ids) 
			{
				$params["status"] = 1;
			}
			pdo_update("yf_chengyu_message", $params, ["id"=>$val["id"]]);
			echo date("Y-m-d H:i:s").": {$val["id"]}\r\n";
		}
	}

// 	//获取成语单词
// 	public function doPageLevelChengyu()
// 	{
// 		$idiom = [];
// 		for($i=18; $i<=2959; $i++)
// 		{
// 			$file = FCPATH."gameLevel/{$i}.txt";
// 			$content = file_get_contents($file);
// 			$data = json_decode($content, true);
// 			// pr($data["data"]["idiom"]);
// 			foreach($data["data"]["idiom"] as $val)
// 			{
// 				$idiom[$val] = $val;
// 			}
// 		}
// 		// pr($idiom);exit;

// 		$header = [
// ':method:GET',
// ':scheme:https',
// ':path:/scholar/api/v1/gameLevel?ver=1.3.9',
// ':authority:cy.bleege.com',
// 'accept:*/*',
// 'content-type:application/json',
// 'x-wx-skey:f6e4466d877245a98e8f4bee3ab239c1',
// 'x-wx-id:3e030eefe5df4de9a8a9c5c49bfe83ff',
// 'ct:1567157086337',
// 'accept-language:zh-cn',
// 'user-agent:Mozilla/5.0 (iPhone; CPU iPhone OS 12_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/7.0.5(0x17000523) NetType/WIFI Language/zh_CN',
// 'referer:https://servicewechat.com/wxd4c69125afec545e/34/page-frame.html',
// 'accept-encoding:br, gzip, deflate',
// 		];
// 		//获取单词信息
// 		foreach($idiom as $val)
// 		{
// 			$row = pdo_get("yf_chengyu_idiom", ["word"=>$val]);
// 			if($row )
// 			{
// 				continue;
// 			}
// 			$url = "https://cy.bleege.com/scholar/api/v1/explanation?ver=1.3.6&word=".urlencode($val);
// 			$result = http_request($url, [], $header);
// 			$data = json_decode($result, true);
// 			$id = intval($data["data"]["id"]);
// 			if( ! $id) 
// 			{
// 				echo str_repeat(" ",1024*64);
// 				echo $val."<br>";
// 				ob_flush();
// 				flush();
// 				continue;
// 				// pr($data);
// 				// exit("error_id不存在");
// 			}


// 			$row = pdo_get("yf_chengyu_idiom", ["id"=>$id]);
// 			if( ! $row)
// 			{
// 				$params = [
// 					"id" => $data["data"]["id"],
// 					"word" => $data["data"]["word"],
// 					"pinyin" => $data["data"]["pinyin"],
// 					"collect" => $data["data"]["collect"],
// 					"derivation" => $data["data"]["derivation"],
// 					"explanation" => $data["data"]["explanation"],
// 					// "shareTitle" => $data["data"]["shareTitle"][0],
// 					// "shareCard" => $data["data"]["shareCard"],
// 				];
// 				pdo_insert("yf_chengyu_idiom", $params);
// 			}
// 			echo str_repeat(" ",1024*64);
// 			echo $data["data"]["id"]."<br>";
// 			ob_flush();
// 			flush();
// 		}
// 	}

// 	//自动升级 获取成语
// 	public function doPageAutoPass()
// 	{
// 		$header = [
// ':method:GET',
// ':scheme:https',
// ':path:/scholar/api/v1/gameLevel?ver=1.3.9',
// ':authority:cy.bleege.com',
// 'accept:*/*',
// 'content-type:application/json',
// 'x-wx-skey:730d769d11a4482ebc6577e324fd245c',
// 'x-wx-id:d6430414c2224e9da2a44dd5a6a6bc34',
// 'ct:1567687266281',
// 'accept-language:zh-cn',
// 'user-agent:Mozilla/5.0 (iPhone; CPU iPhone OS 12_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/7.0.5(0x17000523) NetType/WIFI Language/zh_CN',
// 'referer:https://servicewechat.com/wxd4c69125afec545e/36/page-frame.html',
// 'accept-encoding:br, gzip, deflate',
// 		];
// 		while(true)
// 		{
// 			$url = "https://cy.bleege.com/scholar/api/v1/gameLevel?ver=1.3.9";
// 			$result = http_request($url, [], $header);
// 			$data = json_decode($result, true);
// 			if( ! $data["data"]["idiom"]) 
// 			{
// 				pr($data);
// 				exit("error_当前等级没有单词");
// 			}
// 			// pr($data);exit;

// 			$level = $data["data"]["level"];
// 			$file = FCPATH."gameLevel/{$level}.txt";
// 			file_put_contents($file, $result);

// 			$timestamp = intval(microtime(true)*1000);
// 			$sign = md5("{$level}{$timestamp}bleege");
// 			$url = "https://cy.bleege.com/scholar/api/v2/pass?ver=1.3.9&level={$level}&gameTime=54620&timestamp={$timestamp}&sign={$sign}";
// 			$result = http_request($url, [], $header);
// 			$data = json_decode($result, true);
// 			if($data["code"] != 0) exit("升级失败");

			
// 			echo str_repeat(" ",1024*64);
// 			echo $level."<br>";
// 			ob_flush();
// 			flush();
// 			// sleep(1);
// 		}
// 	}

	//获取access token
	public function getAccessToken($miniapp)
	{
		$cache_file = FCPATH."resource/chengyu_access_token_{$miniapp}"; 

		if(is_file($cache_file) && filemtime($cache_file) + 3600 > time())
		{
			$result = file_get_contents($cache_file);
			$data = json_decode($result, true);//access_token expires_in
			if($data["access_token"])
			{
				return $data["access_token"];
			}
		}

		//获取access_token
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$this->platform_row["appid"]}&secret={$this->platform_row["appsecret"]}";
		$result = file_get_contents($url);
		$data = json_decode($result, true);//access_token expires_in

		file_put_contents($cache_file, $result);
		return $data["access_token"];
	}

	//遍历小程序目录, 将所有的域名相关的图片全部拿出来
	public function doPageChange()
	{
		// $dir = "/data/w7-client/yf_chengyujiekong";
		// $files = getDir($dir);
		// // pr($files);exit;
		// $images = [];
		// foreach($files as $file)
		// {
		// 	// $file = "/data/w7-client/yf_chengyujiekong/pages/index/index.wxml";
		// 	$data = file_get_contents($file);
		// 	$pattern = "/\"(https\:\/\/cy\-res\.bleege\.com.*?)\"/s";
		// 	preg_match_all($pattern, $data, $matches);
		// 	if( ! $matches[0]) continue ;
		// 	foreach($matches[1] as $val)
		// 	{
		// 		$images[] = $val;
		// 	}
		// }
		// foreach($images as $val)
		// {
		// 	$v = str_replace("https://cy-res.bleege.com/cyzyb/img", "", $val);
		// 	$v2 = dirname($v);
		// 	$dir = FCPATH."resource{$v2}";
		// 	$file = $dir."/".basename($v);
		// 	if(is_file($file)) continue;
		// 	if( ! file_exists($dir)) mkdir($dir, 0777, true);
		// 	//不是文件
		// 	if( ! is_file($file))
		// 	{
		// 		echo $file;
		// 		exit;
		// 	}

		// 	$result = file_get_contents($val);
		// 	file_put_contents($file, $result);
		// }
		// exit;

		// $kv_list = pdo_getall("yf_chengyu_kv", ["key"=>["allList", "houseList", "carList", "jobList"]]);
		// $tmp = [];
		// foreach($kv_list as $val)
		// {
		// 	$tmp[$val["key"]] = json_decode($val["value"], true);
		// }
		// $kv_list = $tmp;

		// $data = [
		// 	"baseUrl" => "https://cy-res.bleege.com/cyzyb/img/figure-v2/",//TODO
		// 	"allList" => $kv_list["allList"],
		// 	"carList" => $kv_list["carList"],
		// 	"houseList" => $kv_list["houseList"],
		// 	"jobList" => $kv_list["jobList"],
		// ];
		// pr($data["allList"]);
		// foreach($data["allList"] as $val)
		// {
		// 	foreach($val["resource"] as $v)
		// 	{
		// 		$url = $data["baseUrl"].$v;

		// 		$v = str_replace(["https://cy-res.bleege.com/cyzyb/img", "?ver=190704"], "", $url);
		// 		$v2 = dirname($v);
		// 		$dir = FCPATH."resource{$v2}";
		// 		$file = $dir."/".basename($v);

		// 		if(is_file($file)) continue;
		// 		if( ! file_exists($dir)) mkdir($dir, 0777, true);
		// 		// //不是文件
		// 		// if( ! is_file($file))
		// 		// {
		// 		// 	continue;
		// 		// }
		// 		// echo $file;exit;
		// 		$result = file_get_contents($url);
		// 		file_put_contents($file, $result);
		// 	}
		// }

		// $list = pdo_getall("yf_chengyu_idiom");
		// // pr($list);exit;
		// foreach($list as $val)
		// {
		// 	$url = $val["shareCard"];
		// 	// $res = "{$this->w["siteroot"]}addons/yf_chengyujiekong/resource/";
		// 	$res = FCPATH."resource/idiom/".basename($url);
		// 	if(is_file($res)) continue;
		// 	$result = file_get_contents($url);
		// 	file_put_contents($res, $result);
		// }

		// $list = pdo_getall("yf_chengyu_share");
		// // foreach($list as $val)
		// // {
		// // 	$url = $val["imageUrl"];
		// // 	$res = FCPATH."resource/shareCard/config/".basename($url);
		// // 	if(is_file($res)) continue;
		// // 	$result = file_get_contents($url);
		// // 	file_put_contents($res, $result);
		// // }
		// foreach($list as $val)
		// {
		// 	$imageUrl = str_replace("https://w7.mandiankan.com", "", $val["imageUrl"]);
		// 	pdo_update("yf_chengyu_share", ["imageUrl"=>$imageUrl], ["id"=>$val["id"]]);
		// }

		// $list = pdo_getall("yf_chengyu_moregame");
		// foreach($list as $val)
		// {
		// 	$gameIcon = str_replace("https://w7.mandiankan.com", "", $val["gameIcon"]);
		// 	$gameQrcode = str_replace("https://w7.mandiankan.com", "", $val["gameQrcode"]);
		// 	pdo_update("yf_chengyu_moregame", ["gameIcon"=>$gameIcon, "gameQrcode"=>$gameQrcode], ["id"=>$val["id"]]);
		// }
	}

	private function checkSignature()
	{
	    $signature = $_GET["signature"];
	    $timestamp = $_GET["timestamp"];
	    $nonce = $_GET["nonce"];

	    $token = "8a6e1b599c39f406f07951a2ceaf162a";
	    $tmpArr = array($token, $timestamp, $nonce);
	    sort($tmpArr, SORT_STRING);
	    $tmpStr = implode( $tmpArr );
	    $tmpStr = sha1( $tmpStr );

	    if ($tmpStr == $signature ) {
	        return true;
	    } else {
	        return false;
	    }
	}

	//发送客服消息
	public function doPageSendMessage()
	{
		// $get = '{"i":"3","t":"0","v":"1.0","from":"wxapp","c":"entry","a":"wxapp","do":"sendMessage","m":"yf_chengyujiekong","signature":"b72c7fa2ad925c894f843bac138c0dd304ebd029","timestamp":"1568248097","nonce":"1070099503"}';
		// $_GET = json_decode($get, true);
		$flag = $this->checkSignature();
		if( ! $flag) return;
		$input = file_get_contents('php://input');
		// file_put_contents("/tmp/sendMessage_input", $input);
		// file_put_contents("/tmp/sendMessage_get", json_encode($_GET));
		// $input = '{"ToUserName":"gh_71b12b7cd664","FromUserName":"oUnAs5MB_2faZSJu83hTjDxrlYyk","CreateTime":1568248097,"MsgType":"event","Event":"user_enter_tempsession","SessionFrom":"wxapp"}';

		//验证消息推送
		if($_GET["echostr"])
		{
			echo $_GET["echostr"];
			exit;
		}

		$post = json_decode($input, true);
		$openid = $post["FromUserName"]; 
		if( ! $openid) exit();
		//需要发送内容
		$MsgId = $post["MsgId"]; 
		$Event = $post["Event"]; 
		if($Event != "user_enter_tempsession") exit();
		// if( ! $MsgId) exit();

		//todo 不加ob, 显示  该小程序客服暂时无法提供服务，请稍后再试
		ob_start();
		$access_token = $this->getAccessToken($this->miniapp);
		
		$kv_row = pdo_get("yf_chengyu_kv", ["key"=>"kefu_{$this->miniapp}"]);
		if( ! $kv_row) exit;//没有配置
		$value = json_decode($kv_row["value"], true);
		if( ! $value["open"]) exit;//关闭

		//获取文字和图片
		$content = $value["txt"];
		if($content)
		{
			//发送文本消息
			$url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={$access_token}";
			$params = [
				"touser" => $post["FromUserName"],//用户的 OpenID
				"msgtype" => "text",//消息类型
				"text" => ["content"=>$content],
			];
			http_request($url, json_encode($params, JSON_UNESCAPED_UNICODE));	
		}

		//获取
		$file = FCPATH."../../attachment/".$value["pic"];
		if(is_file($file))
		{
			$media_id = $this->uploadTempMedia($file);

			//发送二维码
			$url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={$access_token}";
			$params = [
				"touser" => $post["FromUserName"],//用户的 OpenID
				"msgtype" => "image",//消息类型
				"image" => ["media_id"=>$media_id],
			];
			http_request($url, json_encode($params));
		}

		ob_end_clean();
	}

	//把媒体文件上传到微信服务器
	private function uploadTempMedia($file)
	{
		//缓存文件,过期时间
		$cache_file = FCPATH."resource/media.log";
		if(is_file($cache_file))
		{
			$data = file_get_contents($cache_file);
			$data = json_decode($data, true);
			if($data && $data["date"] == date("Ymd") && $data["media_id"])
			{
				return $data["media_id"];
			}
		}

		$access_token = $this->getAccessToken($this->miniapp);
		$url = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token={$access_token}&type=image";
		$post = [
			"type" => "image",
			"media" => new \CURLFile($file),
		];
		$result = http_request($url, $post);
		$data = json_decode($result, true);
		if($data["media_id"])
		{
			$params = [
				"date" => date("Ymd"),
				"media_id" => $data["media_id"],
			];
			file_put_contents($cache_file, json_encode($params, JSON_UNESCAPED_UNICODE));
			
			return $data["media_id"];
		}
	}

	// public function doPageMyGameLevel()
	// {
	// 	for($i=1; $i<=3008; $i++)
	// 	{
	// 		$row = pdo_get("yf_chengyu_level", ["id"=>$i]);
	// 		if($row) continue;
	// 		$file = FCPATH."gameLevel/{$i}.txt";
	// 		$result = file_get_contents($file);
	// 		$result = json_decode($result, true);
	// 		$data = $result["data"];
	// 		if( ! $data) exit("error_{$file}");
	// 		$params = [
	// 			"id" => $data["id"],
	// 			"level" => $data["level"],
	// 			"asrEnable" => $data["asrEnable"],
	// 			"idiom" => json_encode($data["idiom"], JSON_UNESCAPED_UNICODE),
	// 			"answer" => json_encode($data["answer"], JSON_UNESCAPED_UNICODE),
	// 			"gameBox" => json_encode($data["gameBox"], JSON_UNESCAPED_UNICODE),
	// 		];
	// 		pdo_insert("yf_chengyu_level", $params);
	// 	}
	// 	echo "操作成功";
	// }
}





