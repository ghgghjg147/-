function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var a = getApp(), e = require("../../utils/https"), i = (require("../../utils/ald-stat-conf.js"), 
require("../../vendor/qcloud-weapp-client-sdk/lib/session")), s = require("../../utils/wx"), o = require("../../config"), r = "";

Page({
    data: {
        siteInfo: require("../../siteinfo.js"),
        showNewPlayerModal8: !1,
        isShowShareGuide: !1,
        isShowNewUserGuide: !1,
        isShowNoTip: !1,
        selectBoxType: 8,
        totalFailTime: 0,
        isShakeBtn1: !1,
        isShakeBtn2: !1,
        timerList: [],
        canShakeBtn: !1,
        moveAnimation1: "",
        needRecordAuth: !1,
        showRecordAuth: !1,
        isFinish: !1,
        showRecordMsg: !1,
        isRecording: !1,
        ifCancel: !1,
        navHeight: 0,
        keepShow: !1,
        showTooShort: !1,
        hadSuccessList: [],
        canGetTip: !1,
        selectedWord: "",
        tipNum: "",
        failTime: 0,
        canCheat: !1,
        getTipTime: 0,
        toastList: [],
        shareTime: 0,
        isClickTip: !1,
        searchDirection: 0,
        answerList: [],
        gameBoxList: [],
        activeX: -1,
        activeY: -1,
        oldActiveX: -1,
        oldActiveY: -1,
        selectList: [],
        initSelectList: [],
        roundNum: 0,
        successNum: 0,
        isUseTip: !1,
        isNotShare: !0,
        defaultBox: {
            show: !1,
            canSelect: !1,
            text: "",
            isActive: !1,
            isSuccess: !1,
            isFail: !1,
            className: "game_box"
        },
        failMoveList: [],
        failMoveTimer: [],
        showNewPlayerModal1: !1,
        showNewPlayerModal2: !1,
        showNewPlayerModal7: !1,
        hadShowNewPlayerModal7: !1,
        newPlayerTip: !0,
        wrongGuideLeft: 0,
        wrongGuideTop: 0,
        playBoxWidth: 0,
        microInputGuide: !1,
        showFinishAllGuide: !0,
        interstitialAd1: null
    },
    showTipAd: function() {
        var i = this;
        if (a.actionTrace({
            event: "ad_video_click",
            subEvent: a.globalData.shareVideoRule.adv.gameRemindAdv,
            gameTime: this.data.gameTime
        }), !a.globalData.shareVideoRule.adv.gameRemindAdv) return this.getTipSuccess(), 
        void this.setData({
            shareVideoRule: this.data.shareVideoRule
        });
        var s = null;
        // 激励视频
     (s = wx.createRewardedVideoAd({
            adUnitId: a.globalData.shareVideoRule.adv.gameRemindAdv
        })).offError(), s.onError(function(s){
            console.log("err", s), e.shareVideoDynamicControl(), i.getTipSuccess();
            var o = t({}, "shareVideoRule.canWatchVideo", !1);
            for (var r in a.globalData.shareVideoRule) "canWatchVideo" != r && (o[[ "shareVideoRule." + r ]] = 1);111
            a.setGlobalData(o), i.setData({
                shareVideoRule: JSON.parse(JSON.stringify(a.globalData.shareVideoRule))
            });
        }), s.offClose(), s.onClose(function(t) {
            t.isEnded ? (a.toggleWatchVideoGuide(), a.actionTrace({
                event: "ad_video_finish",
                subEvent: a.globalData.shareVideoRule.adv.gameRemindAdv,
                gameTime: i.data.gameTime
            }), i.getTipSuccess(), i.setData({
                shareVideoRule: i.data.shareVideoRule
            })) : (wx.getStorageSync("isWatchGuideFinish") || a.toggleWatchVideoGuide(i.showTipAd), 
            a.actionTrace({
                event: "ad_video_close",
                subEvent: a.globalData.shareVideoRule.adv.gameRemindAdv,
                gameTime: i.data.gameTime
            }), i.showToast("请观看完整视频"));
        }), s.show().catch(function(t) {
            s.load().then(function() {
                s.show();
            });333
        }), this.data.videoAd = s;
    },
    closeGuide1: function() {
        this.setData({
            showNewPlayerModal7: !1
        });444
    },
    closeGuide8: function() {
        this.setData({
            showNewPlayerModal8: !1
        });555
    },
    closeGuide3: function() {
        this.setData({
            showFinishAllGuide: !1
        });666
    },
    selectBox: function(t) {
        1 == this.data.roundNum && a.clearLostUserTimer("firstLevel"), 2 == this.data.roundNum && a.clearLostUserTimer("secondLevel"), 
        this.data.showNewPlayerModal2 && (wx.setStorageSync("newPlayerFailTip", "tip"), 
        this.data.showNewPlayerModal2 = !1);
        var e = t.currentTarget.dataset.box;
        if (e.show && e.canSelect && !e.isSuccess) {
            a.globalData.setting.playAudio("changeBox"), -1 != this.data.activeX && -1 != this.data.activeY && (this.data.gameBoxList[this.data.activeX][this.data.activeY].isActive = !1), 
            this.data.oldActiveX = this.data.activeX, this.data.oldActiveY = this.data.activeY;
            var i = this.data.activeX, s = this.data.activeY;
            this.data.activeX = e.x, this.data.activeY = e.y, this.data.gameBoxList[this.data.activeX][this.data.activeY].isActive = !0;
            var o = e.wordIndex;
            e.text && (e.text = "", this.data.selectList[e.wordIndex].isSelected = !1, this.data.gameBoxList[this.data.activeX][this.data.activeY] = e, 
            this.checkAnswer(), e.isActive = !0, e.wordIndex = -1, this.data.totalFailTime = 0, 
            this.data.canShakeBtn = !1);
            var r = this.getBoxClass(e), n = {
                showNewPlayerModal2: this.data.showNewPlayerModal2,
                activeX: e.x,
                activeY: e.y
            };
            o > -1 && (n[[ "selectList[" + o + "]" ]] = this.data.selectList[o]), this.data.activeX > -1 && this.data.activeY > -1 && (n[[ "gameBoxList[" + this.data.activeX + "][" + this.data.activeY + "]" ]] = this.data.gameBoxList[this.data.activeX][this.data.activeY]), 
            i > -1 && s > -1 && (n[[ "gameBoxList[" + i + "][" + s + "]" ]] = this.data.gameBoxList[i][s]);
            var d = !0, c = !1, l = void 0;
            try {
                for (var h, u = r[Symbol.iterator](); !(d = (h = u.next()).done); d = !0) {
                    var g = h.value;
                    n[[ "gameBoxList[" + g.x + "][" + g.y + "]" ]] = g;
                }
            } catch (t) {
                c = !0, l = t;
            } finally {
                try {
                    !d && u.return && u.return();
                } finally {
                    if (c) throw l;
                }
            }
            this.setData(n), this.data.hadSuccessList.length === this.data.answerList.length - 3 && this.saveShareImg();
        }
    },
    closeGuide2: function() {
        this.setData({
            showNewPlayerModal1: !1,
            showNewPlayerModal8: !0
        }), this.data.gameBoxList[3][4].zIndex = 9, this.data.gameBoxList[4][4].zIndex = 9, 
        this.data.gameBoxList[5][4].zIndex = 9, this.data.gameBoxList[6][4].zIndex = 9;
    },
    getBoxClass: function(t) {
        var a = this, e = void 0;
        if (this.data.failMoveList = [], t) {
            e = [ this.data.gameBoxList[this.data.activeX][this.data.activeY] ];
            var i = void 0;
            this.data.oldActiveX > -1 && this.data.oldActiveY > -1 && (i = this.data.gameBoxList[this.data.oldActiveX][this.data.oldActiveY], 
            this.data.oldActiveX = -1, this.data.oldActiveY = -1, e.push(i));
            for (var s = t.x, o = t.y, r = 0; r < 4 && o >= 0; r++) {
                var n = this.data.gameBoxList[s][o];
                if (!n.show && 0 !== r) break;
                e.push(n), o -= 1;
            }
            s = t.x, o = t.y;
            for (var d = 0; d < 4 && (o += 1) < 9; d++) {
                var c = this.data.gameBoxList[s][o];
                if (!c.show) break;
                e.push(c);
            }
            s = t.x, o = t.y;
            for (var l = 0; l < 4 && s >= 0; l++) {
                var h = this.data.gameBoxList[s][o];
                if (!h.show) break;
                e.push(h), s -= 1;
            }
            s = t.x, o = t.y;
            for (var u = 0; u < 4 && (s += 1) < 9; u++) {
                var g = this.data.gameBoxList[s][o];
                if (!g.show) break;
                e.push(g);
            }
            var m = !0, v = !1, f = void 0;
            try {
                for (var x, T = e[Symbol.iterator](); !(m = (x = T.next()).done); m = !0) {
                    var S = x.value, w = "game_box";
                    S.show && (w += " space"), !S.show || S.canSelect || S.isSuccess || (w += " block"), 
                    S.isActive && (w += " active"), S.canSelect && S.text && !S.isSuccess && (w += " text"), 
                    S.animate && (w += " animate" + S.animate), S.isFail && (w += " fail"), S.isFailMove && (w += " fail-move", 
                    this.data.failMoveList.push(S)), S.isSuccess && (this.data.showNewPlayerModal1 || this.data.showNewPlayerModal8 ? w += " success2" : w += " success", 
                    this.data.showNewPlayerModal1 && this.closeGuide2()), S.className = w;
                }
            } catch (t) {
                v = !0, f = t;
            } finally {
                try {
                    !m && T.return && T.return();
                } finally {
                    if (v) throw f;
                }
            }
        } else for (var p = 0; p < 9; p++) for (var y = 0; y < 9; y++) {
            var b = this.data.gameBoxList[p][y], L = "game_box";
            b.show && (L += " space"), !b.show || b.canSelect || b.isSuccess || (L += " block"), 
            b.isActive && (L += " active"), b.canSelect && b.text && !b.isSuccess && (L += " text"), 
            b.animate && (L += " animate" + b.animate), b.isFail && (L += " fail"), b.isFailMove && (L += " fail-move", 
            this.data.failMoveList.push(b)), b.isSuccess && (this.data.showNewPlayerModal1 || this.data.showNewPlayerModal8 ? L += " success2" : L += " success", 
            this.data.showNewPlayerModal1 && this.closeGuide2()), b.className = L;
        }
        if (this.data.failMoveList.length > 0) {
            var D = setTimeout(function() {
                var t = !0, e = !1, i = void 0;
                try {
                    for (var s, o = a.data.failMoveList[Symbol.iterator](); !(t = (s = o.next()).done); t = !0) {
                        var r = s.value;
                        r.isFailMove = !1, a.getBoxClass(r);
                    }
                } catch (t) {
                    e = !0, i = t;
                } finally {
                    try {
                        !t && o.return && o.return();
                    } finally {
                        if (e) throw i;
                    }
                }
                a.setData({
                    gameBoxList: a.data.gameBoxList
                }), a.data.failMoveList = [], a.data.failMoveTimer = [];
            }, 300);
            this.data.failMoveTimer.push(D);
        }
        return this.setData({
            showNewPlayerModal2: this.data.showNewPlayerModal2
        }), e;
    },
    selectWord: function(t) {
        var e = this;
        console.log("selectWord", t), 1 == this.data.roundNum && a.clearLostUserTimer("firstLevel"), 
        2 == this.data.roundNum && a.clearLostUserTimer("secondLevel"), this.setData({
            isGuideShake: !1,
            noClick: !1
        }), this.data.microInputGuide && this.closeGuide4(), new Date().getTime(), this.data.showNewPlayerModal2 && (wx.setStorageSync("newPlayerFailTip", "tip"), 
        this.setData({
            showNewPlayerModal2: !1
        })), a.globalData.setting.playAudio("selectWord");
        var i = !0, s = !1, o = void 0;
        try {
            for (var r, n = this.data.failMoveList[Symbol.iterator](); !(i = (r = n.next()).done); i = !0) r.value.isFailMove = !1;
        } catch (t) {
            s = !0, o = t;
        } finally {
            try {
                !i && n.return && n.return();
            } finally {
                if (s) throw o;
            }
        }
        var d = !0, c = !1, l = void 0;
        try {
            for (var h, u = this.data.failMoveTimer[Symbol.iterator](); !(d = (h = u.next()).done); d = !0) {
                var g = h.value;
                clearTimeout(g);
            }
        } catch (t) {
            c = !0, l = t;
        } finally {
            try {
                !d && u.return && u.return();
            } finally {
                if (c) throw l;
            }
        }
        this.data.failMoveList = [], this.data.failMoveTimer = [];
        var m = t.currentTarget.dataset.index, v = this.data.selectList[m];
        if (this.data.selectedWord = v, !v.isSelected && -1 != this.data.activeX && -1 != this.data.activeY) {
            var f = this.data.gameBoxList[this.data.activeX][this.data.activeY];
            if (f) {
                f.wordIndex > -1 && (this.data.selectList[f.wordIndex].isSelected = !1, this.data.selectList[f.wordIndex].activeX = -1, 
                this.data.selectList[f.wordIndex].activeY = -1), v.isSelected = !0, a.log("selectItem true3", v), 
                v.activeX = f.x, v.activeY = f.y, f.text = v.text, f.wordIndex = m;
                var x = {
                    selectList: this.data.selectList
                }, T = this.checkAnswer();
                if (T.isFail) {
                    if (T.isSuccess) {
                        var S = T.failItem;
                        S.isActive = !0, x.activeX = S.x, x.activeY = S.y;
                    }
                } else this.searchActive();
                var w = this.getBoxClass(f), p = !0, y = !1, b = void 0;
                try {
                    for (var L, D = w[Symbol.iterator](); !(p = (L = D.next()).done); p = !0) {
                        var B = L.value;
                        x[[ "gameBoxList[" + B.x + "][" + B.y + "]" ]] = B;
                    }
                } catch (t) {
                    y = !0, b = t;
                } finally {
                    try {
                        !p && D.return && D.return();
                    } finally {
                        if (y) throw b;
                    }
                }
                this.setData(x), new Date().getTime();
                var _ = wx.getStorageSync("newPlayerFailTip");
                !_ && T.isFail && (wx.removeStorageSync("newPlayerFailTip"), _ = !0, this.data.showNewPlayerModal2 = !0, 
                wx.createSelectorQuery().select(".active").boundingClientRect(function(t) {
                    e.setData({
                        wrongGuideLeft: t.left,
                        wrongGuideTop: t.top
                    });
                }).exec()), this.data.hadSuccessList.length === this.data.answerList.length - 3 && this.saveShareImg();
            }
        }
    },
    checkAnswer: function(t, e) {
        var i = !1, s = !1, o = t ? t.x : this.data.activeX, r = t ? t.y : this.data.activeY, n = o, d = r, c = "", l = "", h = [], u = [], g = [];
        if (!e || 1 == e) {
            for (var m = 0; m < 4 && d >= 0; m++) {
                var v = this.data.gameBoxList[n][d];
                if (!v.text && 0 !== m) break;
                c = v.text + c, h.unshift(v), d -= 1;
            }
            n = o, d = r;
            for (var f = 0; f < 4 && (d += 1) < 9; f++) {
                var x = this.data.gameBoxList[n][d];
                if (!x.text) break;
                c += x.text, h.push(x);
            }
        }
        if (!e || 2 == e) {
            n = o, d = r;
            for (var T = 0; T < 4 && n >= 0; T++) {
                var S = this.data.gameBoxList[n][d];
                if (!S.text && 0 !== T) break;
                l = S.text + l, u.unshift(S), n -= 1;
            }
            n = o, d = r;
            for (var w = 0; w < 4 && (n += 1) < 9; w++) {
                var p = this.data.gameBoxList[n][d];
                if (!p.text) break;
                l += p.text, u.push(p);
            }
        }
        if (4 === c.length) {
            var y = !0, b = !0, L = !1, D = void 0;
            try {
                for (var B, _ = h[Symbol.iterator](); !(b = (B = _.next()).done); b = !0) {
                    var N = B.value;
                    if (N.canSelect && N.ans != N.text) {
                        y = !1;
                        break;
                    }
                }
            } catch (t) {
                L = !0, D = t;
            } finally {
                try {
                    !b && _.return && _.return();
                } finally {
                    if (L) throw D;
                }
            }
            if (y && -1 != this.data.answerList.indexOf(c)) {
                var k = 1;
                this.data.successNum += 1;
                var A = !0, R = !1, I = void 0;
                try {
                    for (var M, G = h[Symbol.iterator](); !(A = (M = G.next()).done); A = !0) {
                        var E = M.value;
                        s = !0, E.isSuccess = !0, E.wordIndex && (this.data.selectList[E.wordIndex].isSuccess = !0), 
                        E.isFail = !1, E.animate = k, k += 1, this.data.failTime = Math.max(this.data.failTime - 1, 0);
                    }
                } catch (t) {
                    R = !0, I = t;
                } finally {
                    try {
                        !A && G.return && G.return();
                    } finally {
                        if (R) throw I;
                    }
                }
                this.successTrace(), this.data.totalFailTime = 0, -1 == this.data.hadSuccessList.indexOf(c) && this.data.hadSuccessList.push(c);
            } else {
                var Y = !0, C = !1, F = void 0;
                try {
                    for (var P, O = h[Symbol.iterator](); !(Y = (P = O.next()).done); Y = !0) {
                        var X = P.value;
                        X.canSelect && !X.isSuccess && (X.isSuccess = !1, X.isFail = !0, i = !0, g.push(X), 
                        X.animate = 0), X.isFailMove = !0;
                    }
                } catch (t) {
                    C = !0, F = t;
                } finally {
                    try {
                        !Y && O.return && O.return();
                    } finally {
                        if (C) throw F;
                    }
                }
                this.failTrace(), this.data.failTime += 1, this.data.totalFailTime += 1;
            }
        } else {
            var J = !0, W = !1, V = void 0;
            try {
                for (var U, z = h[Symbol.iterator](); !(J = (U = z.next()).done); J = !0) {
                    var H = U.value;
                    !H.isSuccess && H.isFail && (H.isFail = !1, H.animate = 0);
                }
            } catch (t) {
                W = !0, V = t;
            } finally {
                try {
                    !J && z.return && z.return();
                } finally {
                    if (W) throw V;
                }
            }
        }
        if (4 === l.length) {
            var q = !0, Q = !0, j = !1, Z = void 0;
            try {
                for (var K, $ = u[Symbol.iterator](); !(Q = (K = $.next()).done); Q = !0) {
                    var tt = K.value;
                    if (tt.canSelect && tt.ans != tt.text) {
                        q = !1;
                        break;
                    }
                }
            } catch (t) {
                j = !0, Z = t;
            } finally {
                try {
                    !Q && $.return && $.return();
                } finally {
                    if (j) throw Z;
                }
            }
            if (q && -1 != this.data.answerList.indexOf(l)) {
                var at = 1;
                this.data.successNum += 1;
                var et = !0, it = !1, st = void 0;
                try {
                    for (var ot, rt = u[Symbol.iterator](); !(et = (ot = rt.next()).done); et = !0) {
                        var nt = ot.value;
                        s = !0, nt.isSuccess = !0, nt.wordIndex && (this.data.selectList[nt.wordIndex].isSuccess = !0), 
                        nt.isFail = !1, nt.animate = at, at += 1;
                    }
                } catch (t) {
                    it = !0, st = t;
                } finally {
                    try {
                        !et && rt.return && rt.return();
                    } finally {
                        if (it) throw st;
                    }
                }
                this.successTrace(), this.data.totalFailTime = 0, -1 == this.data.hadSuccessList.indexOf(l) && this.data.hadSuccessList.push(l), 
                this.data.failTime = Math.max(this.data.failTime - 1, 0);
            } else {
                var dt = !0, ct = !1, lt = void 0;
                try {
                    for (var ht, ut = u[Symbol.iterator](); !(dt = (ht = ut.next()).done); dt = !0) {
                        var gt = ht.value;
                        gt.canSelect && !gt.isSuccess && (gt.isSuccess = !1, gt.isFail = !0, i = !0, g.push(gt), 
                        gt.animate = 0), gt.isFailMove = !0;
                    }
                } catch (t) {
                    ct = !0, lt = t;
                } finally {
                    try {
                        !dt && ut.return && ut.return();
                    } finally {
                        if (ct) throw lt;
                    }
                }
                this.failTrace(), this.data.failTime += 1, this.data.totalFailTime += 1;
            }
        } else if (4 !== c.length) {
            var mt = !0, vt = !1, ft = void 0;
            try {
                for (var xt, Tt = u[Symbol.iterator](); !(mt = (xt = Tt.next()).done); mt = !0) {
                    var St = xt.value;
                    !St.isSuccess && St.isFail && (St.isFail = !1, St.animate = 0);
                }
            } catch (t) {
                vt = !0, ft = t;
            } finally {
                try {
                    !mt && Tt.return && Tt.return();
                } finally {
                    if (vt) throw ft;
                }
            }
        }
        return this.data.hadSuccessList.length === this.data.answerList.length - 2 && (this.data.lastSuccessWord = this.data.hadSuccessList[this.data.hadSuccessList.length - 1]), 
        this.data.hadSuccessList.length === this.data.answerList.length && this.finishGame(), 
        s && !e && a.globalData.setting.playAudio("correct"), i && a.globalData.setting.playAudio("incorrect"), 
        this.data.totalFailTime >= 3 && this.btnShakeStart(), 2 != this.data.failTime || this.data.hadShowNewPlayerModal7 || (this.data.failTime = 0, 
        wx.setStorage({
            key: "hadShowNewPlayerModal7",
            data: !0
        }), this.setData({
            showNewPlayerModal7: !0,
            hadShowNewPlayerModal7: !0
        })), {
            rowItemArr: h,
            colItemArr: u,
            isSuccess: s,
            isFail: i,
            failItem: g.filter(function(t) {
                return !t.isSuccess;
            })[0]
        };
    },
    saveShareImg: function() {
        wx.setStorage({
            key: "shareImgBox",
            data: JSON.stringify(this.data.gameBoxList)
        });
    },
    submitForm: function(t) {
        1 === this.data.roundNum && e.uploadFormId(t.detail.formId, this.data.player.userId);
    },
    successTrace: function() {
        1 === this.data.roundNum && ("一" == this.data.selectedWord.text && (a.actionTrace({
            event: "novice_guide",
            subEvent: "novice_game1_wrtite1",
            gameTime: this.data.gameTime
        }), a.actionTrace({
            event: "ald_first",
            subEvent: "ald_first_click",
            gameTime: this.data.gameTime
        }), a.globalData.ald_media_id && -1 != a.globalData.aldConfig.clickOneWord.indexOf(a.globalData.ald_media_id) && i && i.get() && i.get().openId && (wx.aldstat.sendOpenid(i.get().openId), 
        wx.setStorage({
            key: "isAld",
            data: !0
        }))), "二" == this.data.selectedWord.text && (a.actionTrace({
            event: "novice_guide",
            subEvent: "novice_game1_wrtite2",
            gameTime: this.data.gameTime
        }), a.actionTrace({
            event: "ald_first",
            subEvent: "ald_second_click",
            gameTime: this.data.gameTime
        }), a.globalData.ald_media_id && -1 != a.globalData.aldConfig.clickTwoWord.indexOf(a.globalData.ald_media_id) && i && i.get() && i.get().openId && (wx.aldstat.sendOpenid(i.get().openId), 
        wx.setStorage({
            key: "isAld",
            data: !0
        })), this.setData({
            showNewPlayerModal8: !1
        })), "三" == this.data.selectedWord.text && a.actionTrace({
            event: "novice_guide",
            subEvent: "novice_game1_wrtite3",
            gameTime: this.data.gameTime
        })), 2 === this.data.roundNum && a.actionTrace({
            event: "novice_guide",
            subEvent: "novice_game2_wrtite",
            gameTime: this.data.gameTime
        });
    },
    failTrace: function() {
        1 === this.data.roundNum && a.actionTrace({
            event: "novice_guide",
            subEvent: "novice_game1_wrong",
            gameTime: this.data.gameTime
        }), 2 === this.data.roundNum && a.actionTrace({
            event: "novice_guide",
            subEvent: "novice_game2_wrong",
            gameTime: this.data.gameTime
        });
    },
    passLevel: function() {
        this.data.canCheat && wx.redirectTo({
            url: "/package/pages/finish/finish?roundNum=" + this.data.roundNum
        });
    },
    finishGame: function() {
        var t = this;
        this.data.isFinish || (a.actionTrace({
            event: "game_input",
            subEvent: "game_input_last",
            gameTime: this.data.gameTime
        }), this.data.isFinish = !0, setTimeout(function() {
            wx.redirectTo({
                url: "/package/pages/finish/finish?roundNum=" + t.data.roundNum + "&&lastSuccessWord=" + t.data.lastSuccessWord
            });
        }, 800));
    },
    searchActive: function() {
        if (-1 != this.data.activeX && -1 != this.data.activeY && (this.data.gameBoxList[this.data.activeX][this.data.activeY].isActive = !1), 
        -1 != this.data.activeX && -1 != this.data.activeY) {
            for (var t = "", a = "", e = this.data.activeX, i = this.data.activeY, s = 0; s < 4 && (i += 1) < 9; s++) {
                var o = this.data.gameBoxList[e][i];
                if (!o.show) break;
                if (o.canSelect && !o.text) {
                    t = o;
                    break;
                }
            }
            e = this.data.activeX, i = this.data.activeY;
            for (var r = 0; r < 4 && (e += 1) < 9; r++) {
                var n = this.data.gameBoxList[e][i];
                if (!n.show) break;
                if (n.canSelect && !n.text) {
                    a = n;
                    break;
                }
            }
            if (t && a) {
                e = this.data.activeX, i = this.data.activeY;
                for (var d = 0, c = 0, l = 0; l < 4 && i >= 0; l++) {
                    var h = this.data.gameBoxList[e][i];
                    if (!h.show) break;
                    h.canSelect && !h.text ? d -= 1 : d += 1, i -= 1;
                }
                e = this.data.activeX, i = this.data.activeY;
                for (var u = 0; u < 4 && e >= 0; u++) {
                    var g = this.data.gameBoxList[e][i];
                    if (!g.show) break;
                    g.canSelect && !g.text ? c -= 1 : c += 1, e -= 1;
                }
                var m = void 0;
                return m = d > c ? t : d < c ? a : 2 === this.data.searchDirection ? a : t, m.isActive = !0, 
                void this.setData({
                    activeX: m.x,
                    activeY: m.y
                });
            }
            if (t || a) {
                e = this.data.activeX, i = this.data.activeY;
                var v = -1, f = -1, x = void 0;
                if (t) {
                    for (var T = 0; T < 4 && i >= 0; T++) {
                        var S = this.data.gameBoxList[e][i];
                        if (!S.show) break;
                        S.canSelect && !S.text && (v = S.x, f = S.y), i -= 1;
                    }
                    if (v > -1 && f > -1) {
                        this.data.searchDirection = 1;
                        var w = this.data.gameBoxList[v][f];
                        return w.isActive = !0, void this.setData({
                            activeX: w.x,
                            activeY: w.y
                        });
                    }
                    x = t, this.data.searchDirection = 1;
                } else {
                    for (var p = 0; p < 4 && e >= 0; p++) {
                        var y = this.data.gameBoxList[e][i];
                        if (!y.show) break;
                        y.canSelect && !y.text && (v = y.x, f = y.y), e -= 1;
                    }
                    if (v > -1 && f > -1) {
                        this.data.searchDirection = 2;
                        var b = this.data.gameBoxList[v][f];
                        return b.isActive = !0, void this.setData({
                            activeX: b.x,
                            activeY: b.y
                        });
                    }
                    x = a, this.data.searchDirection = 2;
                }
                return x.isActive = !0, void this.setData({
                    activeX: x.x,
                    activeY: x.y
                });
            }
            e = this.data.activeX, i = this.data.activeY;
            for (var L = -1, D = -1, B = 0; B < 4 && i >= 0; B++) {
                var _ = this.data.gameBoxList[e][i];
                if (!_.show) break;
                _.canSelect && !_.text && (L = _.x, D = _.y), i -= 1;
            }
            if (L > -1 && D > -1) {
                this.data.searchDirection = 1;
                var N = this.data.gameBoxList[L][D];
                return N.isActive = !0, void this.setData({
                    activeX: N.x,
                    activeY: N.y
                });
            }
            e = this.data.activeX, i = this.data.activeY, L = -1, D = -1;
            for (var k = 0; k < 4 && e >= 0; k++) {
                var A = this.data.gameBoxList[e][i];
                if (!A.show) break;
                A.canSelect && !A.text && (L = A.x, D = A.y), e -= 1;
            }
            if (L > -1 && D > -1) {
                this.data.searchDirection = 2;
                var R = this.data.gameBoxList[L][D];
                return R.isActive = !0, void this.setData({
                    activeX: R.x,
                    activeY: R.y
                });
            }
        }
        if (-1 == this.data.activeX || -1 == this.data.activeY) for (var I = 0; I < 9; I++) for (var M = 0; M < 9; M++) {
            var G = this.data.gameBoxList[I][M];
            if (G.canSelect && !G.text) return G.isActive = !0, this.data.searchDirection = 0, 
            void this.setData({
                activeX: G.x,
                activeY: G.y
            });
        } else {
            var E = this.wideTraversal(this.data.gameBoxList[this.data.activeX][this.data.activeY]);
            if (E) {
                if (3 === E.direction || 4 === E.direction) {
                    for (var Y = E.node.x, C = E.node.y, F = -1, P = -1, O = 0; O < 4 && C >= 0; O++) {
                        var X = this.data.gameBoxList[Y][C];
                        if (!X.show) break;
                        X.canSelect && !X.text && (F = X.x, P = X.y), C -= 1;
                    }
                    if (F > -1 && P > -1) {
                        this.data.searchDirection = 1;
                        var J = this.data.gameBoxList[F][P];
                        return J.isActive = !0, void this.setData({
                            activeX: J.x,
                            activeY: J.y
                        });
                    }
                } else {
                    for (var W = E.node.x, V = E.node.y, U = -1, z = -1, H = 0; H < 4 && W >= 0; H++) {
                        var q = this.data.gameBoxList[W][V];
                        if (!q.show) break;
                        q.canSelect && !q.text && (U = q.x, z = q.y), W -= 1;
                    }
                    if (U > -1 && z > -1) {
                        this.data.searchDirection = 2;
                        var Q = this.data.gameBoxList[U][z];
                        return Q.isActive = !0, void this.setData({
                            activeX: Q.x,
                            activeY: Q.y
                        });
                    }
                }
                E.node.isActive = !0, this.data.searchDirection = 0, this.setData({
                    activeX: E.node.x,
                    activeY: E.node.y
                });
            }
        }
    },
    wideTraversal: function(t) {
        var a = [];
        if (t.show) {
            var e = {
                direction: 5,
                node: t
            };
            for (a.unshift(e); 0 != a.length; ) {
                if ((e = a.shift()).node.x > 0 && 2 != e.direction) {
                    var i = this.data.gameBoxList[e.node.x - 1][e.node.y];
                    i.show && a.push({
                        direction: 1,
                        node: i
                    });
                }
                if (e.node.x < 8 && 1 != e.direction) {
                    var s = this.data.gameBoxList[e.node.x + 1][e.node.y];
                    s.show && a.push({
                        direction: 2,
                        node: s
                    });
                }
                if (e.node.y > 0 && 4 != e.direction) {
                    var o = this.data.gameBoxList[e.node.x][e.node.y - 1];
                    o.show && a.push({
                        direction: 3,
                        node: o
                    });
                }
                if (e.node.y < 8 && 3 != e.direction) {
                    var r = this.data.gameBoxList[e.node.x][e.node.y + 1];
                    r.show && a.push({
                        direction: 4,
                        node: r
                    });
                }
                if (e.node.canSelect && !e.node.text) return e;
            }
        }
    },
    setBoxStatus: function(t, a, e, i) {
        this.data.gameBoxList[t][a].show = !0, this.data.gameBoxList[t][a].text = e, e || (this.data.gameBoxList[t][a].canSelect = !0), 
        i && (this.data.gameBoxList[t][a].ans = i);
    },
    restart: function() {
        var t = this;
        a.actionTrace({
            event: "game_oper",
            subEvent: "game_replay_click",
            gameTime: this.data.gameTime
        }), a.globalData.setting.playAudio("btnClick"), wx.showModal({
            title: "确认重玩吗",
            content: "正确答案也会清空，是否确认",
            success: function(e) {
                e.confirm && (a.actionTrace({
                    event: "game_oper",
                    subEvent: "game_replay_suc",
                    gameTime: t.data.gameTime
                }), t.setData({
                    showRecordMsg: !1,
                    isRecording: !1,
                    ifCancel: !1,
                    navHeight: 0,
                    keepShow: !1,
                    showTooShort: !1,
                    hadSuccessList: [],
                    needRecordAuth: !1,
                    showRecordAuth: !1,
                    isFinish: !1,
                    activeX: -1,
                    activeY: -1,
                    oldActiveX: -1,
                    oldActiveY: -1,
                    successNum: 0,
                    isUseTip: !1,
                    failMoveList: [],
                    failMoveTimer: [],
                    gameBoxList: JSON.parse(JSON.stringify(t.data.initList)),
                    selectList: JSON.parse(JSON.stringify(t.data.initSelectList))
                }), t.searchActive());
            }
        });
    },
    setBoxStorage: function() {
        var t = {
            answerList: this.data.answerList,
            roundNum: this.data.roundNum,
            gameBoxList: JSON.parse(JSON.stringify(this.data.gameBoxList)),
            selectList: JSON.parse(JSON.stringify(this.data.selectList)),
            initList: JSON.parse(JSON.stringify(this.data.initList)),
            initSelectList: JSON.parse(JSON.stringify(this.data.initSelectList)),
            hadSuccessList: this.data.hadSuccessList,
            activeX: this.data.activeX,
            activeY: this.data.activeY,
            oldActiveX: this.data.oldActiveX,
            oldActiveY: this.data.oldActiveY,
            successNum: this.data.successNum
        };
        wx.setStorage({
            key: "boxStorage",
            data: t
        });
    },
    setRound: function(t) {
        for (var a = 0; a < 9; a++) {
            this.data.gameBoxList[a] = [];
            for (var e = 0; e < 9; e++) {
                var i = JSON.parse(JSON.stringify(this.data.defaultBox));
                i.x = a, i.y = e, this.data.gameBoxList[a].push(i);
            }
        }
        var s = void 0, o = void 0;
        1 === t ? (this.setBoxStatus(3, 4, "独"), this.setBoxStatus(4, 4, "", "一"), this.setBoxStatus(5, 4, "无", ""), 
        this.setBoxStatus(6, 4, "", "二"), this.setBoxStatus(4, 3, "心"), this.setBoxStatus(4, 2, "一"), 
        this.setBoxStatus(4, 5, "意"), this.setBoxStatus(6, 3, "接"), this.setBoxStatus(6, 5, "连"), 
        this.setBoxStatus(6, 6, "", "三"), s = [ {
            text: "三",
            isSelected: !1
        }, {
            text: "二",
            isSelected: !1
        }, {
            text: "一",
            isSelected: !1
        } ], o = [ "一心一意", "独一无二", "接二连三" ]) : (this.setBoxStatus(3, 3, "万"), this.setBoxStatus(3, 4, "马"), 
        this.setBoxStatus(3, 5, "奔"), this.setBoxStatus(3, 6, "", "腾"), this.setBoxStatus(4, 4, "", "到"), 
        this.setBoxStatus(5, 4, "成"), this.setBoxStatus(6, 4, "功"), this.setBoxStatus(5, 2, "望"), 
        this.setBoxStatus(5, 3, "子"), this.setBoxStatus(5, 5, "", "龙"), s = [ {
            text: "龙",
            isSelected: !1
        }, {
            text: "腾",
            isSelected: !1
        }, {
            text: "到",
            isSelected: !1
        } ], o = [ "万马奔腾", "马到成功", "望子成龙" ]);
        var r = this.data.selectList.length > 21 ? 8 : this.data.selectList.length > 12 ? 7 : 6;
        this.setData({
            selectList: s,
            answerList: o,
            selectBoxType: r,
            selectRow: Math.ceil(this.data.selectList.length / r),
            gameBoxList: this.data.gameBoxList,
            initList: JSON.parse(JSON.stringify(this.data.gameBoxList)),
            initSelectList: JSON.parse(JSON.stringify(this.data.selectList))
        }), this.searchActive();
    },
    goback: function() {
        a.actionTrace({
            event: "game_home",
            subEvent: "game_home_click",
            gameTime: this.data.gameTime
        }), this.setBoxStorage(), a.goback();
    },
    setBoxWidth: function() {
        var t = a.pxTransformer(76), e = a.pxTransformer(75), i = a.pxTransformer(70), s = a.pxTransformer(80), o = a.pxTransformer(77), r = 0;
        r = (a.globalData.system = "android") ? a.pxTransformer(3) : a.pxTransformer(1), 
        this.setData({
            boxWidth: t,
            boxHeight: e,
            activeBoxHeight: i,
            selectBoxWidth: s,
            selectBoxHeight: o,
            transForm: r
        });
    },
    getBoxList: function() {
        var t = this, i = wx.getStorageSync("boxStorage");
        if (console.log("boxStorage", i, i.roundNum, this.data.roundNum), i && i.roundNum == this.data.roundNum) {
            this.setData(i);
            var s = this.data.selectList.length > 21 ? 8 : this.data.selectList.length > 12 ? 7 : 6;
            this.setData({
                selectBoxType: s,
                selectRow: Math.ceil(this.data.selectList.length / s)
            }), this.getBoxClass(), a.log(this.data.selectList);
        } else if (a.globalData.gameLevel) {
            for (var o = a.globalData.gameLevel.gameBox, r = a.globalData.gameLevel.idiom, n = [], d = 0; d < 9; d++) for (var c = 0; c < 9; c++) {
                var l = o[d][c];
                l.x = d, l.y = c, l.isActive = !1, l.isSuccess = !1, l.isFail = !1, l.className = "game_box";
            }
            for (var h = 0; h < a.globalData.gameLevel.answer.length; h++) n.push({
                text: a.globalData.gameLevel.answer[h],
                isSelected: !1
            });
            1 != a.globalData.gameLevel.level && this.shuffle(n), this.data.gameBoxList = o, 
            1 == a.globalData.gameLevel.level && (this.data.gameBoxList[4][2].zIndex = 9, this.data.gameBoxList[4][3].zIndex = 9, 
            this.data.gameBoxList[4][4].zIndex = 9, this.data.gameBoxList[4][5].zIndex = 9, 
            this.setData({
                showNewPlayerModal1: !0,
                isShowNewUserGuide: !0
            })), this.data.gameBoxList = o, this.data.selectList = n, this.searchActive(), this.getBoxClass();
            var u = this.data.selectList.length > 21 ? 8 : this.data.selectList.length > 12 ? 7 : 6;
            this.setData({
                answerList: r,
                selectList: n,
                roundNum: a.globalData.gameLevel.level,
                canCheat: a.globalData.gameLevel.canCheat || !1,
                selectBoxType: u,
                selectRow: Math.ceil(this.data.selectList.length / u),
                gameBoxList: this.data.gameBoxList,
                initList: JSON.parse(JSON.stringify(this.data.gameBoxList)),
                initSelectList: JSON.parse(JSON.stringify(this.data.selectList))
            });
        }
        e.gameLevel().then(function(e) {
            if (t.selectComponent("#navbar").getData("noInit"), 0 === e.data.code) {
                if (a.globalData.gameLevel || i && i.roundNum == t.data.roundNum) return a.globalData.gameLevel = e.data.data, 
                void t.setData({
                    canCheat: a.globalData.gameLevel.canCheat || !1
                });
                for (var s = e.data.data.gameBox, o = e.data.data.idiom, r = [], n = 0; n < 9; n++) for (var d = 0; d < 9; d++) {
                    var c = s[n][d];
                    c.x = n, c.y = d, c.isActive = !1, c.isSuccess = !1, c.isFail = !1, c.className = "game_box";
                }
                for (var l = 0; l < e.data.data.answer.length; l++) r.push({
                    text: e.data.data.answer[l],
                    isSelected: !1
                });
                1 != e.data.data.level && t.shuffle(r), t.data.gameBoxList = s, 1 == e.data.data.level && (t.data.gameBoxList[4][2].zIndex = 9, 
                t.data.gameBoxList[4][3].zIndex = 9, t.data.gameBoxList[4][4].zIndex = 9, t.data.gameBoxList[4][5].zIndex = 9, 
                t.setData({
                    showNewPlayerModal1: !0
                })), t.data.gameBoxList = s, t.data.selectList = r, t.searchActive(), t.getBoxClass();
                var h = t.data.selectList.length > 21 ? 8 : t.data.selectList.length > 12 ? 7 : 6;
                t.setData({
                    answerList: o,
                    selectList: r,
                    roundNum: e.data.data.level,
                    canCheat: e.data.data.canCheat || !1,
                    selectBoxType: h,
                    selectRow: Math.ceil(t.data.selectList.length / h),
                    gameBoxList: t.data.gameBoxList,
                    initList: JSON.parse(JSON.stringify(t.data.gameBoxList)),
                    initSelectList: JSON.parse(JSON.stringify(t.data.selectList))
                });
            }
        }).catch(function(t) {
            a.log("catch", t);
        });
    },
    shuffle: function(t) {
        for (var a = t.length; a; ) {
            var e = Math.floor(Math.random() * a--), i = [ t[a], t[e] ];
            t[e] = i[0], t[a] = i[1];
        }
    },

 // 分享到朋友圈
 onShareTimeline: function () {
  return {
    title: '这一题你会嘛，快来帮帮我!',
    query: 'tommie_duanshiping/pages/index/index',
    imageUrl: '/image/test/1.jpg'
  }
},

    getGameTip: function() {
        var t = this;
        e.player().then(function(e) {
            if (0 === e.data.code) {
                var i = e.data.data.passLevel, s = a.globalData.listData.allList.filter(function(t) {
                    return t.level > i;
                });
                s.sort(function(t, a) {
                    return t.level - a.level;
                });
                var o = s[0], r = {
                    1: "官职",
                    2: "房屋",
                    3: "座驾"
                }, n = [ "还差" + (o.level - i) + "关", "升级" + r[o.type] ];
                t.setData({
                    gameTip: n
                }), e.data.data.activityEnable && a.setGlobalData({
                    showWanyuanActivity: e.data.data.activityEnable
                });
            }
        });
    },
    buySuccess: function() {
        this.showToast("购买成功"), this.getTipNum();
    },
    getTipNum: function() {
        var t = this;
        e.tipNumber().then(function(a) {
            0 === a.data.code && (t.setData({
                tipNum: a.data.data.tipNumber
            }), t.data.canGetTip = a.data.data.canGet);
        });
    },
    useTipNum: function() {
        var t = this;
        e.tipNumber("cost").then(function(a) {
            0 === a.data.code && t.setData({
                tipNum: a.data.data.tipNumber
            });
        });
    },
    onLoad: function(t) {
        a.aldstat.sendEvent("游戏页面" + t.level);
        var o = this;
        if (a.setGlobalData({
            isShowTreasure: !1,
            isShowWatchVideoGuide: !1
        }), 1129 == a.globalData.scene && e.getSeoData("game", JSON.stringify(t)).then(function(t) {
            0 == t.data.code && o.setData({
                seoData: t.data.data
            });
        }), 1129 == a.globalData.scene || 0 != a.globalData.mode) {
            if (1129 == a.globalData.scene && 0 == a.globalData.mode) return console.log("seoMode"), 
            void this.setData({
                seoMode: !0
            });
            this.setData({
                seoMode: !1
            }), a.globalData.mode = 1, console.log("game.onLoad", t), a.setWatch(this, "", "game"), 
            a.globalData.options.path = "pages/game/game", a.globalData.gameTimeStart = new Date().getTime(), 
            a.loginTrace("page_load", t), this.setBtnShakeTimer(), wx.updateShareMenu({
                withShareTicket: !0
            }), this.data.hadShowNewPlayerModal7 = wx.getStorageSync("hadShowNewPlayerModal7"), 
            this.getGameTip(), this.getTipNum(), a.shareVideoRule(function(t) {
                o.setData({
                    shareVideoRule: JSON.parse(JSON.stringify(t))
                });
            });
            var r = "getTipTime" + new Date().getMonth() + "_" + new Date().getDate(), n = wx.getStorageSync(r);
            n && this.setData({
                getTipTime: n
            }), t.level && this.setData({
                roundNum: t.level
            }), this.setBoxWidth(), this.getBoxList(), s.getSetting("scope.record").then(function(t) {
                o.setData({
                    needRecordAuth: !1
                });
            }).catch(function(t) {
                o.setData({
                    needRecordAuth: !0
                });
            }), a.globalData.gameStartTime = Date.now(), this.setData({
                isActivityEnd: a.globalData.isActivityEnd
            }), 2 === this.data.roundNum && (this.data.noClick = !0), setTimeout(function() {
                1 === o.data.roundNum && (a.setLostUserTimer("firstLevel"), a.actionTrace({
                    event: "ald_first",
                    subEvent: "ald_first_over",
                    gameTime: o.data.gameTime
                }), a.globalData.ald_media_id && -1 != a.globalData.aldConfig.enterOne.indexOf(a.globalData.ald_media_id) && i && i.get() && i.get().openId && (wx.aldstat.sendOpenid(i.get().openId), 
                wx.setStorage({
                    key: "isAld",
                    data: !0
                }))), 2 === o.data.roundNum && (a.setLostUserTimer("secondLevel"), a.globalData.ald_media_id && -1 != a.globalData.aldConfig.enterTwo.indexOf(a.globalData.ald_media_id) && i && i.get() && i.get().openId && (wx.aldstat.sendOpenid(i.get().openId), 
                wx.setStorage({
                    key: "isAld",
                    data: !0
                })));
            }, 500), setTimeout(function() {
                o.flyOne();
            }, 2e3), setTimeout(function() {
                o.data.noClick && o.setData({
                    isGuideShake: !0
                });
            }, 3e3);
        } else wx.redirectTo({
            url: "/pages/index/index"
        });
    },
    onUnload: function() {
        this.data.videoAd && this.data.videoAd.destroy(), console.log("game.onUnload");
        var t = 0, e = new Date().getTime();
        this.data.roundNum === a.globalData.gameTimeLevel ? t = a.globalData.gameTimeBefore : a.globalData.gameTimeBefore = 0, 
        this.data.gameTime = t + e - a.globalData.gameTimeStart, a.actionTrace({
            event: "page_unload",
            subEvent: "",
            gameTime: this.data.gameTime
        }), a.globalData.gameTimeLevel && a.globalData.gameTimeLevel === this.data.roundNum ? a.globalData.gameTimeBefore += new Date().getTime() - a.globalData.gameTimeStart : (a.globalData.gameTimeBefore = new Date().getTime() - a.globalData.gameTimeStart, 
        a.globalData.gameTimeLevel = this.data.roundNum);
        var i = !0, s = !1, o = void 0;
        try {
            for (var r, n = this.data.timerList[Symbol.iterator](); !(i = (r = n.next()).done); i = !0) {
                var d = r.value;
                clearInterval(d);
            }
        } catch (t) {
            s = !0, o = t;
        } finally {
            try {
                !i && n.return && n.return();
            } finally {
                if (s) throw o;
            }
        }
    },
    showToast: function(t) {
        var a = this, e = [];
        e = "string" == typeof t || "number" == typeof t ? [ t ] : t, this.data.toastList.push(e), 
        this.setData({
            toastList: this.data.toastList
        }), r && clearTimeout(r), r = setTimeout(function() {
            r = "", a.setData({
                toastList: []
            });
        }, 2e3);
    },
    clickTip: function() {
        var t = this;
        if (a.actionTrace({
            event: "game_oper",
            subEvent: "game_tips_click",
            gameTime: this.data.gameTime
        }), this.data.showNewPlayerModal7 && this.closeGuide1(), this.data.tipNum > 0) this.flyTip(function() {
            t.getTip(!0);
        }); else {
            if (this.data.player.advAuditSwitch) return void this.showToast("今日提示已用完");
            a.globalData.setting.playAudio("btnClick"), 2 == this.data.shareVideoRule.gameRemind ? this.showTipAd() : this.shareGetTip();
        }
    },
    flyOne: function() {
        var t = this;
        this.data.showNewPlayerModal1 && wx.createSelectorQuery().select("#select-box-02").boundingClientRect(function(a) {
            t.setData({
                livesRect: {
                    left: a.left / o.pixelRate,
                    top: a.top / o.pixelRate
                }
            }), wx.createSelectorQuery().select("#game-box44").boundingClientRect(function(a) {
                var e = a.left / o.pixelRate - t.data.livesRect.left - 5, i = a.top / o.pixelRate - t.data.livesRect.top - 5;
                t.setData({
                    oneLeft: t.data.livesRect.left,
                    oneTop: t.data.livesRect.top,
                    moveAnimation2: "transform: translate(" + e + "rpx, " + i + "rpx) scale(0.5);"
                }), setTimeout(function() {
                    t.setData({
                        moveAnimation2: "",
                        oneLeft: "100%",
                        oneTop: 0
                    }), t.selectWord({
                        currentTarget: {
                            dataset: {
                                index: 2
                            }
                        }
                    });
                }, 500);
            }).exec();
        }).exec();
    },
    flyTip: function(t) {
        var a = this;
        this.data.isTipFlying || (this.data.isTipFlying = !0, wx.createSelectorQuery().select("#tip-btn").boundingClientRect(function(e) {
            a.setData({
                livesRect: {
                    left: e.left / o.pixelRate,
                    top: e.top / o.pixelRate
                }
            });
            var i = "#game-box" + a.data.activeX + a.data.activeY;
            wx.createSelectorQuery().select(i).boundingClientRect(function(e) {
                var i = e.left / o.pixelRate - a.data.livesRect.left + 5, s = e.top / o.pixelRate - a.data.livesRect.top;
                a.setData({
                    tipLeft: a.data.livesRect.left,
                    tipTop: a.data.livesRect.top,
                    moveAnimation1: "transform: translate(" + i + "rpx, " + s + "rpx) scale(1);"
                }), setTimeout(function() {
                    a.setData({
                        moveAnimation1: "",
                        tipLeft: 0,
                        tipTop: 0
                    }), a.data.isTipFlying = !1, t && t();
                }, 500);
            }).exec();
        }).exec());
    },
    getTip: function(t) {
        a.actionTrace({
            event: "game_oper",
            subEvent: "game_tips_suc",
            gameTime: this.data.gameTime
        }), a.globalData.setting.playAudio("gameTip"), t && this.useTipNum();
        var e = this.data.gameBoxList[this.data.activeX][this.data.activeY], i = this.data.selectList.filter(function(t) {
            return t.text === e.ans;
        }), s = void 0, o = !0, r = !1, n = void 0;
        try {
            for (var d, c = i[Symbol.iterator](); !(o = (d = c.next()).done); o = !0) {
                var l = d.value;
                if (!l.isSelected) {
                    s = l;
                    break;
                }
                l.isSuccess || (s = l);
            }
        } catch (t) {
            r = !0, n = t;
        } finally {
            try {
                !o && c.return && c.return();
            } finally {
                if (r) throw n;
            }
        }
        var h = this.data.selectList.indexOf(s);
        if (s && s.isSelected) {
            var u = !0, g = !1, m = void 0;
            try {
                for (var v, f = this.data.gameBoxList[Symbol.iterator](); !(u = (v = f.next()).done); u = !0) {
                    var x = v.value, T = !0, S = !1, w = void 0;
                    try {
                        for (var p, y = x[Symbol.iterator](); !(T = (p = y.next()).done); T = !0) {
                            var b = p.value;
                            if (b.wordIndex === h && !b.isSuccess && b.canSelect) {
                                b.text = "", b.isFail = !1, b.wordIndex = -1;
                                break;
                            }
                        }
                    } catch (t) {
                        S = !0, w = t;
                    } finally {
                        try {
                            !T && y.return && y.return();
                        } finally {
                            if (S) throw w;
                        }
                    }
                }
            } catch (t) {
                g = !0, m = t;
            } finally {
                try {
                    !u && f.return && f.return();
                } finally {
                    if (g) throw m;
                }
            }
        }
        e.wordIndex > -1 && !e.isSuccess && e.canSelect && !this.data.selectList[e.wordIndex].isSuccess && (this.data.selectList[e.wordIndex].isSelected = !1, 
        e.wordIndex = -1), e.text = e.ans, e.wordIndex = h, e.canSelect = !1, e.isFail = !1, 
        s && (s.isSelected = !0), a.log("selectItem true1", s);
        var L = "getTipTime" + new Date().getMonth() + "_" + new Date().getDate();
        wx.setStorage({
            key: L,
            data: this.data.getTipTime
        });
        var D = this.checkAnswer();
        if (D.isFail) {
            var B = D.colItemArr;
            if (4 == D.rowItemArr.length && (B = D.rowItemArr), B = B.filter(function(t) {
                return t.canSelect;
            }), -1 != this.data.activeX && -1 != this.data.activeY && (this.data.gameBoxList[this.data.activeX][this.data.activeY].isActive = !1), 
            B.length > 0) {
                var _ = B[0];
                _.isActive = !0, this.setData({
                    activeX: _.x,
                    activeY: _.y
                });
            } else this.searchActive();
        } else this.searchActive();
        var N = this.getBoxClass(e), k = {
            selectList: this.data.selectList,
            gameBoxList: this.data.gameBoxList,
            getTipTime: this.data.getTipTime + 1
        }, A = !0, R = !1, I = void 0;
        try {
            for (var M, G = N[Symbol.iterator](); !(A = (M = G.next()).done); A = !0) {
                var E = M.value;
                k[[ "gameBoxList[" + E.x + "][" + E.y + "]" ]] = E;
            }
        } catch (t) {
            R = !0, I = t;
        } finally {
            try {
                !A && G.return && G.return();
            } finally {
                if (R) throw I;
            }
        }
        this.setData(k), this.getTipNum(), this.data.hadSuccessList.length === this.data.answerList.length - 3 && this.saveShareImg();
    },
    addShareVideoTimes: function() {
        e.tipNumber("add").then(function(t) {
            a.shareVideoRule();
        });
    },
    getRecordAuth: function() {
        var t = this;
        s.authorize("scope.record").then(function(e) {
            a.actionTrace({
                event: "auth_record",
                subEvent: "game_record_click",
                op_result: 1,
                gameTime: t.data.gameTime
            }), t.setData({
                needRecordAuth: !1
            });
        }).catch(function(e) {
            a.log("用户取消授权", e), "authorize:fail auth deny" === e.errMsg ? (a.actionTrace({
                event: "auth_record",
                subEvent: "game_record_click",
                op_result: 0,
                gameTime: t.data.gameTime
            }), t.showToast("授权失败，无法使用语音功能")) : t.setData({
                showRecordAuth: !0
            });
        });
    },
    closeRecordAuth: function() {
        this.setData({
            showRecordAuth: !1
        });
    },
    rootCatch: function(t) {
        1 == this.data.roundNum && a.clearLostUserTimer("firstLevel"), 2 == this.data.roundNum && a.clearLostUserTimer("secondLevel"), 
        this.data.showNewPlayerModal7 && "daixuanci" !== t.target.id && this.closeGuide1(), 
        this.data.showFinishAllGuide && this.closeGuide3(), this.data.microInputGuide && this.closeGuide4(), 
        this.data.totalFailTime < 3 && (this.data.canShakeBtn = !1), this.setBtnShakeTimer(), 
        this.setData({
            isGuideShake: !1,
            noClick: !1
        });
    },
    openSettingHandler: function(t) {
        t.detail.authSetting["scope.record"] ? (a.actionTrace({
            event: "auth_record",
            subEvent: "game_record_setting",
            op_result: 1,
            gameTime: this.data.gameTime
        }), this.setData({
            showRecordAuth: !1,
            needRecordAuth: !1
        })) : a.actionTrace({
            event: "auth_record",
            subEvent: "game_record_setting",
            op_result: 0,
            gameTime: this.data.gameTime
        });
    },
    closeGuide4: function() {
        this.setData({
            microInputGuide: !1
        }), a.globalData.guideList.microInput = !0, a.setGlobalData({
            microInput: !0
        }), e.addGuide("microInput");
    },
    bindRecordTouchStart: function(t) {
        var e = this;
        if (a.actionTrace({
            event: "game_input",
            subEvent: "game_voice_click",
            gameTime: this.data.gameTime
        }), !this.data.microInputGuide && a.globalData.guideList.microInput || this.closeGuide4(), 
        this.data.needRecordAuth) this.getRecordAuth(); else if (!this.data.ifRecognizing || !this.data.isRecording) {
            if (s.report("recordbtn_click"), this.usingRecorder) return a.actionTrace({
                event: "game_home",
                subEvent: "game_voice_fail",
                gameTime: this.data.gameTime
            }), this.setData({
                isRecording: !1
            }), void wx.showToast({
                title: "你的操作太快",
                icon: "none",
                duration: 1500
            });
            this.usingRecorder = !0, this.data.isCancel = !1, this.data.isRecording = !1, s.recorderStart().then(function(t) {
                if (e.data.isCancel) return e.usingRecorder = !1, s.recorderStop(), void (e.data.isCancel = !1);
                e.recordStartT = new Date().getTime(), e.recordTouchY = null, e.data.isRecording = !0, 
                e.setData({
                    isRecording: !0,
                    isCancel: !1,
                    showRecordMsg: !0,
                    showTooShort: !1,
                    ifRecognizing: !1
                });
            }).catch(function(t) {
                e.usingRecorder = !1, s.recorderStop();
            });
        }
    },
    recordMsgEnd: function(t) {
        this.data.isRecording || this.setData({
            showRecordMsg: !1
        });
    },
    bindRecordTouchMove: function(t) {
        if (!this.data.ifRecognizing) if (null == this.recordTouchY) this.recordTouchY = t.touches[0].clientY; else {
            var a = t.touches[0].clientY;
            a - this.recordTouchY < -3 ? this.data.isCancel || this.setData({
                isCancel: !0
            }) : a - this.recordTouchY > 3 && this.data.isCancel && this.setData({
                isCancel: !1
            }), this.recordTouchY = a;
        }
    },
    bindRecordTouchEnd: function(t) {
        var i = this;
        this.data.ifRecognizing || (this.data.isRecording ? s.recorderStop().then(function(t) {
            i.usingRecorder = !1, i.data.isCancel ? (a.actionTrace({
                event: "game_home",
                subEvent: "game_voice_fail",
                gameTime: i.data.gameTime
            }), i.setData({
                isRecording: !1
            })) : (i.recordEndT = new Date().getTime(), i.recordEndT - i.recordStartT < 600 ? (a.actionTrace({
                event: "game_home",
                subEvent: "game_voice_fail",
                gameTime: i.data.gameTime
            }), i.setData({
                showTooShort: !0,
                isRecording: !1,
                keepShow: !0
            }), setTimeout(function() {
                i.setData({
                    keepShow: !1
                });
            }, 1500)) : (i.setData({
                ifRecognizing: !0
            }), e.recognize(i.data.roundNum, t.tempFilePath).then(function(t) {
                var e = JSON.parse(t.data);
                0 === e.code && e.data.pass ? i.recordSuccessHandle(e.data) : (a.actionTrace({
                    event: "game_home",
                    subEvent: "game_voice_fail",
                    gameTime: i.data.gameTime
                }), i.setData({
                    isFail: !0,
                    keepShow: !0
                }), setTimeout(function() {
                    i.setData({
                        isFail: !1,
                        keepShow: !1
                    });
                }, 1500)), i.setData({
                    ifRecognizing: !1,
                    isRecording: !1
                });
            }).catch(function(t) {
                a.actionTrace({
                    event: "game_home",
                    subEvent: "game_voice_fail",
                    gameTime: i.data.gameTime
                }), i.setData({
                    ifRecognizing: !1,
                    isFail: !0,
                    keepShow: !0,
                    isRecording: !1
                }), setTimeout(function() {
                    i.setData({
                        isFail: !1,
                        keepShow: !1
                    });
                }, 1500);
            }))), i.data.isCancel = !1;
        }).catch(function(t) {
            a.actionTrace({
                event: "game_home",
                subEvent: "game_voice_fail",
                gameTime: i.data.gameTime
            }), i.usingRecorder = !1, i.setData({
                isRecording: !1
            });
        }) : (a.actionTrace({
            event: "game_home",
            subEvent: "game_voice_fail",
            gameTime: this.data.gameTime
        }), this.data.isCancel = !0, this.setData({
            isRecording: !1
        })));
    },
    recordSuccessHandle: function(t) {
        var e = this, i = t.idiom;
        if (-1 == this.data.hadSuccessList.indexOf(i)) {
            a.actionTrace({
                event: "game_input",
                subEvent: "game_voice_suc",
                gameTime: this.data.gameTime
            }), a.globalData.setting.playAudio("correct"), this.data.hadSuccessList.push(i);
            var s = t.result, o = [], r = 0;
            s.sort(function(t, a) {
                return t.x != a.x ? (r = 2, t.x - a.x) : (r = 1, t.y - a.y);
            });
            for (var n = 0; n < s.length; n++) !function(t) {
                var i = s[t], n = e.data.gameBoxList[i.y][i.x];
                if (n.ans && n.canSelect && !n.isSuccess) {
                    var d = e.data.selectList.filter(function(t) {
                        return t.text === n.ans;
                    }), c = void 0, l = !0, h = !1, u = void 0;
                    try {
                        for (var g, m = d[Symbol.iterator](); !(l = (g = m.next()).done); l = !0) {
                            var v = g.value;
                            if (!v.isSelected) {
                                c = v;
                                break;
                            }
                            v.isSuccess || (c = v);
                        }
                    } catch (t) {
                        h = !0, u = t;
                    } finally {
                        try {
                            !l && m.return && m.return();
                        } finally {
                            if (h) throw u;
                        }
                    }
                    var f = e.data.selectList.indexOf(c);
                    if (c.isSelected) {
                        var x = !0, T = !1, S = void 0;
                        try {
                            for (var w, p = e.data.gameBoxList[Symbol.iterator](); !(x = (w = p.next()).done); x = !0) {
                                var y = w.value, b = !0, L = !1, D = void 0;
                                try {
                                    for (var B, _ = y[Symbol.iterator](); !(b = (B = _.next()).done); b = !0) {
                                        var N = B.value;
                                        if (N.wordIndex === f && !N.isSuccess && N.canSelect) {
                                            N.text = "", N.isFail = !1, N.wordIndex = -1;
                                            break;
                                        }
                                    }
                                } catch (t) {
                                    L = !0, D = t;
                                } finally {
                                    try {
                                        !b && _.return && _.return();
                                    } finally {
                                        if (L) throw D;
                                    }
                                }
                            }
                        } catch (t) {
                            T = !0, S = t;
                        } finally {
                            try {
                                !x && p.return && p.return();
                            } finally {
                                if (T) throw S;
                            }
                        }
                    }
                    c && (c.isSelected = !0, a.log("selectItem true2", c), o.push(c)), n.wordIndex > -1 && !n.isSuccess && n.canSelect && !e.data.selectList[n.wordIndex].isSuccess && (e.data.selectList[n.wordIndex].isSelected = !1, 
                    n.wordIndex = -1), n.text = n.ans, n.wordIndex = f;
                }
                n.isSuccess = !0, n.wordIndex && (e.data.selectList[n.wordIndex].isSuccess = !0), 
                n.animate = t, i.cross && e.checkAnswer(n, r);
            }(n);
            this.data.successNum += 1, this.searchActive(), this.getBoxClass(), this.setData({
                selectList: this.data.selectList,
                gameBoxList: this.data.gameBoxList
            }), this.data.hadSuccessList.length === this.data.answerList.length && this.finishGame(), 
            this.data.hadSuccessList.length === this.data.answerList.length - 3 && this.saveShareImg();
        }
    },
    countDistance: function(t, a) {
        var e = t.x, i = t.y, s = a.x, o = a.y, r = 0;
        e === s && (r = 1), i === o && (r = 2);
        var n = {
            way: r,
            distance: Math.pow(e - s, 2) + Math.pow(i - o, 2)
        };
        return 1 === n.distance && (t.countItem ? t.isPart = !0 : t.countItem = n, a.countItem ? a.isPart = !0 : a.countItem = n), 
        n;
    },
    checkHeight: function() {
        var t = this;
        this.measureBox("#top-container").then(function(e) {
            var i = wx.getSystemInfoSync().windowHeight, s = e.height;
            parseInt(i) - parseInt(s) > 240 && (t.setData({
                isShowRecord: !0
            }), t.data.roundNum > 10 && wx.setStorage({
                key: "isSeeRecord",
                data: !0
            }), a.actionTrace({
                event: "game_input",
                subEvent: "game_input_voice",
                gameTime: t.data.gameTime
            })), t.measureBox("#select-container").then(function(a) {
                console.log("checkHeight2", e.height + a.height, i), e.height + a.height > i && t.setData({
                    isSmallWindow: !0
                });
            });
        }), this.measureBox("#game_container").then(function(a) {
            t.setData({
                playBoxWidth: a.width
            });
        });
    },
    measureBox: function(t) {
        return new Promise(function(a, e) {
            var i = wx.createSelectorQuery();
            i.select(t).fields({
                dataset: !0,
                size: !0,
                rect: !0
            }, function(t) {
                a(t);
            }), i.exec();
        });
    },
    onReady: function() {
        var t = this;
        wx.nextTick(function() {
            t.checkHeight();
        });
    },
    onHide: function() {
        if (console.log("game.onHide"), !this.data.isShare) {
            var t = 0, e = new Date().getTime();
            this.data.roundNum === a.globalData.gameTimeLevel ? t = a.globalData.gameTimeBefore : a.globalData.gameTimeBefore = 0, 
            this.data.gameTime = t + e - a.globalData.gameTimeStart, a.actionTrace({
                event: "page_hide",
                subEvent: "",
                gameTime: this.data.gameTime
            });
        }
    },
    onShow: function() {
        var t = this;
        if (this.selectComponent("#noTip") && this.selectComponent("#noTip").show(), this.selectComponent("#shareGuide") && this.selectComponent("#shareGuide").show(), 
        console.log("game.onShow"), this.data.isShare) this.data.isShare = !1; else {
            var e = 0, i = new Date().getTime();
            this.data.roundNum === a.globalData.gameTimeLevel ? e = a.globalData.gameTimeBefore : a.globalData.gameTimeBefore = 0, 
            this.data.gameTime = e + i - a.globalData.gameTimeStart, a.actionTrace({
                event: "page_show",
                subEvent: "",
                gameTime: this.data.gameTime
            });
        }
        console.log("game onShow"), this.data.isClickTip && (this.data.isClickTip = !1), 
        this.data.roundNum > 10 && !a.globalData.guideList.microInput && this.setData({
            microInputGuide: !0
        });
        var s = Number(wx.getStorageSync("lastOpenInterstitialAdTime"));
        "game" === a.globalData.lastPageName && (!s || Date.now() - s > 36e5) ? (wx.createInterstitialAd && (this.data.interstitialAd1 = wx.createInterstitialAd({
            adUnitId: a.globalData.shareVideoRule.adv.backGameBanner
        }), this.data.interstitialAd1.onLoad(function() {
            t.data.interstitialAd1.show().then(function() {
                wx.setStorageSync("lastOpenInterstitialAdTime", String(Date.now()));
            });
        })), a.globalData.lastPageName = "game") : a.globalData.lastPageName = "game", a.globalData.showWanyuanActivity && a.globalData.remainLevelGetZikuai && a.setGlobalData({
            wanyuanActivityTip: !a.globalData.wanyuanActivityTip
        });
    },
    shareHandle: function() {
        console.log("shareHandle");
        var t = a.globalData.toShare;
        if (a.setGlobalData({
            toShare: 0
        }), Date.now() - t < a.globalData.shareGetEnergy.timeInterVal) return this.data.tipTraceData.result = 0, 
        a.shareTrace(this.data.tipTraceData), this.showToast("操作失败 换个群试试");
        if (this.data.lastShareEnergyFail || Math.random() < a.globalData.shareGetEnergy.successRate) this.getTipSuccess(), 
        this.data.lastShareEnergyFail = !1; else {
            var e = Math.floor(Math.random() * a.globalData.shareGetEnergy.textList.length);
            this.showToast(a.globalData.shareGetEnergy.textList[e]), this.data.lastShareEnergyFail = !0, 
            this.data.tipTraceData.result = 0;
        }
        a.shareTrace(this.data.tipTraceData);
    },
    onShareAppMessage: function(t) {
        this.data.isShare = !0, a.globalData.lastPageName = "", a.sourceReport("exam_friend_click");
        var e = 0, i = new Date().getTime();
        this.data.roundNum === a.globalData.gameTimeLevel ? e = a.globalData.gameTimeBefore : a.globalData.gameTimeBefore = 0, 
        this.data.gameTime = e + i - a.globalData.gameTimeStart;
        var s = {
            title: a.globalData.shareResult.top_right_share.title,
            imageUrl: a.globalData.shareResult.top_right_share.imageUrl,
            path: a.sharePath()
        };
        return "button" == t.from && "kao_friend" === t.target.dataset.type ? (a.actionTrace({
            event: "game_oper",
            subEvent: "game_exam_friend",
            gameTime: this.data.gameTime
        }), s = {
            title: a.globalData.shareResult.kao_friend.title,
            imageUrl: a.globalData.shareResult.kao_friend.imageUrl,
            path: a.sharePath() + "&event=exam_friend_conver"
        }, a.shareTrace({
            sharePath: s.path,
            event: "receive_energy",
            subEvent: "invite_button_click",
            shareCard: a.globalData.shareResult.kao_friend.id,
            shareTitle: s.title,
            result: 1,
            gameTime: this.data.gameTime
        }), s) : "button" == t.from && "tip" === t.target.dataset.type ? (this.data.isClickTip = !0, 
        a.sourceReport("tipshare_click"), s = {
            title: a.globalData.shareResult.remind_share.title,
            imageUrl: a.globalData.shareResult.remind_share.imageUrl,
            path: a.sharePath() + "&event=tipshare_conver&otherId=" + a.globalData.player.userId + "&shareTsp=" + Date.now() + "&bonusType=tip"
        }, this.data.tipTraceData = {
            sharePath: s.path,
            event: "game_tips",
            subEvent: "game_tips_click",
            shareCard: a.globalData.shareResult.remind_share.id,
            shareTitle: s.title,
            result: 1,
            gameTime: this.data.gameTime
        }, s) : (a.shareTrace({
            sharePath: s.path,
            event: "share_menu",
            subEvent: "share_menu_click",
            shareCard: a.globalData.shareResult.top_right_share.id,
            shareTitle: s.title,
            result: 1,
            gameTime: this.data.gameTime
        }), s);
    },
    containerTouchStart: function(t) {},
    containerTouchEnd: function(t) {},
    animationEnd1: function() {
        var t = this;
        this.setData({
            isShakeBtn1: !1
        }), this.data.canShakeBtn && setTimeout(function() {
            t.setData({
                isShakeBtn2: !0
            });
        }, 600);
    },
    animationEnd2: function() {
        var t = this;
        this.setData({
            isShakeBtn2: !1
        }), this.data.canShakeBtn && setTimeout(function() {
            t.setData({
                isShakeBtn1: !0
            });
        }, 600);
    },
    setBtnShakeTimer: function() {
        var t = this, a = !0, e = !1, i = void 0;
        try {
            for (var s, o = this.data.timerList[Symbol.iterator](); !(a = (s = o.next()).done); a = !0) {
                var r = s.value;
                clearInterval(r);
            }
        } catch (t) {
            e = !0, i = t;
        } finally {
            try {
                !a && o.return && o.return();
            } finally {
                if (e) throw i;
            }
        }
        var n = setInterval(function() {
            t.btnShakeStart();
        }, 3e3);
        this.data.timerList.push(n);
    },
    btnShakeStart: function() {
        this.data.canShakeBtn || (this.data.canShakeBtn = !0, this.data.isShakeBtn1 || this.data.isShakeBtn2 || this.setData({
            isShakeBtn1: !0
        }));
    },
    toActivity: function() {
        a.actionTrace({
            event: "game_oper",
            subEvent: "game_oper_act",
            gameTime: this.data.gameTime
        }), this.setBoxStorage(), wx.redirectTo({
            url: "/package/pages/activity/activity?isGame=" + this.data.roundNum
        });
    },
    toggleNoTip: function() {
        this.setData({
            isShowNoTip: !this.data.isShowNoTip
        }), this.data.isShowNoTip || a.globalData.setting.playAudio("btnClick");
    },
    seoStart: function() {
        wx.redirectTo({
            url: "/pages/index/index?toGame=1"
        });
    },
    shopGetUserInfo: function(t) {
        t.detail ? (i.clear(), a.setGlobalData({
            needAuth: !1,
            userInfo: t.detail.userInfo
        })) : this.showToast("请点击允许，授权信息购买能量");
    },
    toggleMoreGame: function() {
        var t = this;
        this.data.showMoreGamePopup ? this.setData({
            showMoreGamePopup: !1
        }) : (a.globalData.setting.playAudio("btnClick"), e.moreGame().then(function(a) {
            0 === a.data.code && t.setData({
                moreGameList: a.data.data,
                showMoreGamePopup: !0
            });
        }));
    },
    getTipSuccess: function() {
        var t = this;
        this.setData({
            isShowShareGuide: !1
        }), this.addShareVideoTimes(), this.flyTip(function() {
            t.getTip();
        });
    },
    clickTreasure: function() {
        1 == this.data.roundNum && a.actionTrace({
            event: "game_1",
            subEvent: "game1_box_click",
            gameTime: this.data.gameTime
        }), 2 == this.data.roundNum && a.actionTrace({
            event: "game_2",
            subEvent: "game2_box_click",
            gameTime: this.data.gameTime
        }), this.toggleMoreGame();
    },
    closeNewUserGuide: function() {
        a.globalData.ald_media_id && -1 != a.globalData.aldConfig.clickAnswer.indexOf(a.globalData.ald_media_id) && i && i.get() && i.get().openId && (wx.aldstat.sendOpenid(i.get().openId), 
        wx.setStorage({
            key: "isAld",
            data: !0
        })), a.actionTrace({
            event: "ald_first",
            subEvent: "ald_guide_click"
        }), this.setData({
            isShowNewUserGuide: !this.data.isShowNewUserGuide
        });
    },
    toggleShareGuide: function() {
        this.setData({
            isShowShareGuide: !this.data.isShowShareGuide
        });
    },
    shareGetTip: function() {
        this.setData({
            isShowShareGuide: !0,
            shareGuideType: "tip",
            pageGuideType: 4
        });
    },
    shareScb: function() {
        a.setGlobalData({
            toShare: Date.now()
        });
    },
    toggleWatchVideoGuide: function() {
        a.setGlobalData({
            isShowWatchVideoGuide: !a.globalData.isShowWatchVideoGuide
        });
    },
    refreshReward: function() {
        console.log("refreshReward"), this.getTipNum();
    }
});