function a(a, t, e) {
    return t in a ? Object.defineProperty(a, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[t] = e, a;
}

var t, e = getApp(), i = require("../../config"), o = require("../../utils/https"), n = (require("../../utils/ald-stat-conf.js"), 
require("../../vendor/qcloud-weapp-client-sdk/lib/session")), s = "";

Page({
    data: (t = {
        siteInfo: require("../../siteinfo.js"),
        activityTestTab: 0,
        friendLineType: "",
        isShowShareGuide: !1,
        isShowShareSuccess: !1,
        isShowShowOff: !1,
        isShowDetention: !1,
        isShowWatchVideo: !1,
        isShowExit: !0,
        isShowBanner: !0,
        moreGameSideListNum: 0,
        moreGameSideList: [],
        isShowFriendLine: !1,
        isEnergyTip: !1,
        isShowAddFuchuang: !1,
        isShowInviteNew: !1,
        hasPopLoginAward: !1,
        levelUpList: [],
        isSubscribe: !0,
        flyMsgIndex: 1,
        text1: "",
        text2: "",
        animalStep: 1,
        lessLevel: 0,
        getWord: [],
        scrollTop: 0,
        version: i.service.version,
        isShowGameTry: !1,
        isBuyTip: !1,
        isShowShopEnter: !1,
        isShowShop: !1,
        shareResult: {},
        daysSignInfo: {
            nowSignDays: 0,
            week: 0
        },
        isShowEnergyRed: !1,
        scrollId: "",
        rankClickNum: 0,
        currentDate: "",
        currentDateText: "",
        activeRank: 0,
        isStarted: !1,
        capsuleHeight: i.capsuleHeight,
        statusBarHeight: i.statusBarHeight,
        pixelRate: i.pixelRate,
        toastTime: 2e3,
        isShowWordBook: !1,
        isShowReward: !1,
        rewardType: 0,
        totalValue: 0,
        isShowInviteRedpoint: !1,
        isChangeBg: !1,
        pageCountDownReady: !1,
        pageReady: !1,
        rankData: {},
        curListIndex: "",
        isShowCar: !1,
        isShowHouse: !1,
        levelUpTip: "",
        player: "",
        showIdiomPopup: !1,
        isIphonX: !1,
        isNew: !1,
        round: 25,
        isShowListPopup: !1,
        listType: 1,
        list: [],
        soundSwitch: !0,
        listData: {},
        baseUrl: e.baseUrl() + "/addons/yf_chengyujiekong/resource/figure/",
        isShowBtn: !1,
        btnType: 1,
        livesRect: {},
        moveAnimationOrigin: "",
        moveAnimation1: "",
        isShowSignUp: !1,
        isShowRank: !1,
        isShowInvite: !1,
        isInviteShare: !1,
        isTest: !1,
        toastList: [],
        wordItem: {},
        newPlayHelp: "",
        inviteList: [],
        whatDidIDo: "",
        positionIndex: -1,
        carIndex: -1,
        houseIndex: -1,
        bgIndex: 1,
        isBeta: !0,
        carResource: "",
        houseResource: "",
        jobResource: "",
        lastShareEnergyFail: !1,
        isShowEarnEnergy: !1,
        isShowCollectApp: !1,
        currentSwiper1: 0,
        showNewPlayerModal4: !1,
        earnEnergyList: []
    }, a(t, "showIdiomPopup", !1), a(t, "wordExplain", {}), a(t, "newUserHadDaysSign", !1), 
    a(t, "daysSignStyle", !1), a(t, "isShowGzhSign", !1), a(t, "commonGetEnegyPopupValue", 0), 
    a(t, "daysLoginRewardPopup", !1), a(t, "isShowSettingPage", !1), a(t, "toDaySignShare", 0), 
    a(t, "lastDaySignShareFail", !1), a(t, "openWordBookGudie", !1), a(t, "earnEnergyGudie", !1), 
    a(t, "viewRankGudie", !1), a(t, "pageHide", !1), a(t, "newguideHouseShow", 0), a(t, "newguideCarShow", 0), 
    a(t, "achieve", 0), a(t, "isFirstHouseGuide", !1), a(t, "interstitialAdList", []), 
    a(t, "interstitialAd1", null), a(t, "showGoActivityPopup", !1), a(t, "showZhuangyuanbang", !1), 
    a(t, "showMoreGamePopup", !1), a(t, "zhuangyuanbangList", []), a(t, "moreGameList", []), 
    a(t, "canPopWeekScholar", !1), a(t, "isIdiomShare", !1), a(t, "forceGoGame", !1), 
    a(t, "goGzhSign", !1), a(t, "pageOptions", {}), t),
    onReady: function() {
        e.globalData.navHeight = (this.data.statusBarHeight + this.data.capsuleHeight) / this.data.pixelRate, 
        e.log("navHeight2", e.globalData.navHeight, this.data.statusBarHeight, this.data.pixelRate, this.data.capsuleHeight), 
        this.setData({
            capsuleHeight: i.capsuleHeight,
            statusBarHeight: i.statusBarHeight,
            pixelRate: i.pixelRate
        });
    },
    toggleAddFuchuang: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowAddFuchuang: !this.data.isShowAddFuchuang
        });
    },
    toggleInviteNew: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowInviteNew: !this.data.isShowInviteNew
        });
    },
    todayRedPointHandle: function() {
        var a = this.dateFilter(new Date()), t = wx.getStorageSync("todayRedPointDict"), e = {};
        t && t.date == a ? e = t : (e = {
            date: a,
            activity: !0,
            total: !0,
            friend: !0,
            dailySign: !0,
            gzhReceive: !0,
            collect: !0,
            wanyuan: !0,
            gametry: !0,
            watchScholar: !0,
            moreGame: !0,
            shop: !0,
            inviteNewUser: !0,
            watchVideo: !0
        }, wx.setStorage({
            key: "todayRedPointDict",
            data: e
        })), this.setData({
            todayRedPointDict: e
        });
    },
    onLoad: function(a) {
        console.log(a), e.aldstat.sendEvent("进入首页");
        var t = this;
        e.globalData.notFirstLoad = !1, 1129 == e.globalData.scene && o.getSeoData("index", JSON.stringify(a)).then(function(a) {
            0 == a.data.code && t.setData({
                seoData: a.data.data
            });
        });
        var i = wx.getStorageSync("isShowExit"), s = new Date();
        i && s.getDate() === i && this.setData({
            isShowExit: !1
        }), console.log("index.onLoad", a), e.globalData.options.path = "pages/index/index", 
        wx.updateShareMenu({
            withShareTicket: !0
        }), this.todayRedPointHandle(), this.setData({
            now: new Date().getTime(),
            pageOptions: a,
            currentDate: new Date(),
            currentDateText: this.dateFilter(new Date(), 1)
        }), setTimeout(function() {
            t.data.pageReady ? t.setData({
                pageReady: !0
            }) : t.data.pageCountDownReady = !0;
        }, 1500), setTimeout(function() {
            t.setData({
                pageReady: !0
            });
        }, 5e3), this.getHotWord(), a.word && (e.log("options", a), this.data.isIdiomShare = !0, 
        this.openIdiomPopup(a.word)), console.log("公众号赚能量", a), ("gzh" === a.source && "true" == a.login || this.data.goGzhSign) && (n.clear(), 
        o.suppleMpReward(e.globalData.scene, "gzhSign").then(function(a) {
            0 === a.data.code && (e.actionTrace({
                event: "enlist_wxoa",
                subEvent: "enlist_wxoa_suc"
            }), t.selectComponent("#navbar") && t.selectComponent("#navbar").getData("noInit"), 
            t.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: a.data.data.gzhEnergy
            }), t.showMixinBanner(), e.globalData.setting.playAudio("getEnergy"));
        }));
    },
    onUnload: function() {
        e.globalData.notFirstPlayer = !1, console.log("index.onUnload"), e.actionTrace({
            event: "page_unload",
            subEvent: ""
        }), clearInterval(this.data.flyMsgInterval);
    },
    getHotWord: function() {
        var a = this;
        o.hotWord().then(function(t) {
            0 === t.data.code && (e.globalData.isTest = t.data.data.isBeta, a.setData({
                isTest: t.data.data.isBeta,
                idioms: t.data.data.idioms
            }));
        });
    },
    interstitialAdLoad: function(a) {
        var t = void 0;
        return wx.createInterstitialAd && !this.data.interstitialAdList[a] ? ((t = wx.createInterstitialAd({
            adUnitId: a
        })).offLoad(), t.onLoad(function() {
            e.actionTrace({
                event: "ad_popup_show",
                subEvent: a
            }), e.log("onLoad event emit");
        }), t.offError(), t.onError(function(t) {
            e.actionTrace({
                event: "ad_popup_fail",
                subEvent: a
            }), e.log("onError event emit", t);
        }), t.onClose(function(a) {
            e.log("onClose event emit", a);
        }), this.data.interstitialAdList[a] = t) : t = this.data.interstitialAdList[a], 
        t;
    },
    showMixinBanner: function() {
        this.data.player.passLevel > 13 && (console.log("showMixinBanner1"), this.interstitialAdLoad(e.globalData.shareVideoRule.adv.mixinBanner).show().catch(function(a) {
            console.log("showMixinBanner2", a);
        }));
    },
    onShow: function() {
        var t = this;
        2 == this.data.activityTestTab && this.setData({
            activityTestTab: 0
        }), e.setGlobalData({
            isShowTreasure: !1,
            isShowWatchVideoGuide: !1
        }), e.globalData.toOtherGame && (e.globalData.toOtherGame = !1, this.interstitialAdLoad(e.globalData.shareVideoRule.adv.tableScreenBanner).show().catch(function(a) {})), 
        console.log("index.onShow"), e.globalData.options.path = "pages/index/index", this.data.isTryingGame && (this.data.isTryingGame = !1, 
        this.tryGameHandle()), this.data.isNewUserShare && (this.data.isNewUserShare = !1, 
        this.selectComponent("#inviteNewUser") && this.selectComponent("#inviteNewUser").show()), 
        this.selectComponent("#shop") && this.selectComponent("#shop").hide(), this.selectComponent("#shop") && this.selectComponent("#shop").show(), 
        this.selectComponent("#showOffPopup") && this.selectComponent("#showOffPopup").show(), 
        this.data.pageReady && (this.getPlayer(), this.getInviteList(), this.selectComponent("#navbar") && this.selectComponent("#navbar").getData("noInit"), 
        this.previewLevel(), this.getGuideList(), this.activityDetail());
        var i = Number(wx.getStorageSync("lastOpenInterstitialAdTime"));
        if ("index" === e.globalData.lastPageName && (!i || Date.now() - i > 36e5) ? (wx.createInterstitialAd && (this.data.interstitialAd1 = wx.createInterstitialAd({
            adUnitId: e.globalData.shareVideoRule.adv.backGameBanner
        }), this.data.interstitialAd1.onLoad(function() {
            t.data.interstitialAd1.show().then(function() {
                wx.setStorageSync("lastOpenInterstitialAdTime", String(Date.now()));
            });
        })), e.globalData.lastPageName = "index") : e.globalData.lastPageName = "index", 
        e.globalData.showWanyuanActivity && e.globalData.remainLevelGetZikuai && e.setGlobalData({
            wanyuanActivityTip: !e.globalData.wanyuanActivityTip
        }), this.selectComponent("#navbar") && this.selectComponent("#navbar").show(), this.setData({
            pageHide: !1
        }), this.data.isInviteShare && (this.data.isInviteShare = !1, this.showToast("请提醒好友打开游戏，即可获取能量奖励")), 
        "goDaysSign" === this.data.whatDidIDo && (this.setData({
            isShowSignUp: !1
        }), this.getPlayer()), this.data.friendLine, "yes" == wx.getStorageSync("newPlayHelp") ? (this.setData({
            newPlayHelp: "yes"
        }), this.data.image1 = !0, e.setLostUserTimer("homePageUpgrade"), wx.removeStorageSync("newPlayHelp")) : wx.getStorageSync("guideOpenWordBook") && !e.globalData.guideList.wordBook ? (this.setData({
            openWordBookGudie: !0
        }), wx.removeStorageSync("guideOpenWordBook"), o.addGuide("wordBook")) : e.globalData.guideList.noEnergy || 0 !== e.globalData.energyTotal ? e.globalData.needAuth && wx.getStorageSync("guideViewRank") && (this.setData({
            viewRankGudie: !0
        }), wx.removeStorageSync("guideViewRank")) : (e.log("guideList", e.globalData.guideList), 
        this.setData({
            earnEnergyGudie: !0
        }), e.globalData.guideList.noEnergy = !0, e.setGlobalData(a({}, "guideList.noEnergy", !0)), 
        o.addGuide("noEnergy")), this.data.isShowEarnEnergy && this.makeEnergy(), e.globalData.toShare) {
            var n = e.globalData.toShare;
            if (e.setGlobalData({
                toShare: 0
            }), Date.now() - n < e.globalData.shareGetEnergy.timeInterVal) return this.data.energyTraceData.result = 0, 
            e.shareTrace(this.data.energyTraceData), this.showToast("操作失败 换个群试试");
            if (this.data.lastShareEnergyFail || Math.random() < e.globalData.shareGetEnergy.successRate) this.shareGetEnergySuccess(), 
            this.data.lastShareEnergyFail = !1; else {
                var s = Math.floor(Math.random() * e.globalData.shareGetEnergy.textList.length);
                this.showToast(e.globalData.shareGetEnergy.textList[s]), this.data.lastShareEnergyFail = !0, 
                this.data.energyTraceData.result = 0;
            }
            e.shareTrace(this.data.energyTraceData);
        }
        this.selectComponent("#daysLoginReward") && this.selectComponent("#daysLoginReward").shareHandle(), 
        e.globalData.notFirstPlayer && (this.data.isShare ? this.data.isShare = !1 : e.actionTrace({
            event: "page_show",
            subEvent: ""
        }));
    },
    submitForm: function(a) {
        e.log("submit11111111111", a), o.uploadFormId(a.detail.formId, this.data.player.userId);
    },
    previewLevel: function() {
        o.previewLevel().then(function(a) {
            0 === a.data.code ? e.globalData.gameLevel = a.data.data : e.globalData.gameLevel = "";
        }).catch(function(a) {
            e.globalData.gameLevel = "";
        });
    },
    toggleWeekZYB: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            canPopWeekScholar: !this.data.canPopWeekScholar
        });
    },
    goWeekReport: function() {
        this.toggleWeekZYB(), wx.navigateTo({
            url: "/package/pages/weekReport/weekReport"
        });
    },
    changeRankTab: function(a) {
        e.globalData.setting.playAudio("btnClick");
        var t = a.currentTarget.dataset.tab;
        e.log("tab", t, this.data.activeRank), Number(t) !== this.data.activeRank && (this.setData({
            scrollTop: 0,
            rankClickNum: 0,
            activeRank: t,
            currentDate: new Date(),
            currentDateText: this.dateFilter(new Date(), 1)
        }), this.getRankData());
    },
    activityDetail: function() {
        var a = this;
        o.activityDetail().then(function(t) {
            if (0 === t.data.code) {
                for (var i = t.data.data.passLevel, o = t.data.data.detail.word, n = t.data.data.getWord || [], s = t.data.data.users, r = 0; r < o.length; r++) {
                    if (i < o[r].level) {
                        e.setGlobalData({
                            remainLevelGetZikuai: o[r].level - i
                        });
                        break;
                    }
                    if (o[r + 1] && i >= o[r].level && i < o[r + 1].level) {
                        e.setGlobalData({
                            remainLevelGetZikuai: o[r + 1].level - i
                        });
                        break;
                    }
                    i >= o[r].level && e.setGlobalData({
                        remainLevelGetZikuai: 0
                    });
                }
                var d = 0, l = t.data.data.detail.word, h = t.data.data.passLevel, g = l.filter(function(a) {
                    return a.level > h;
                })[0];
                g && (d = g.level - h), a.setData({
                    userList: s,
                    lessLevel: d,
                    getWord: n
                }), a.flyMsgHandle(), t.data.data.detail.finishTime < new Date().getTime() && (a.setData({
                    isActivityEnd: !0
                }), e.globalData.isActivityEnd = !0);
            }
        });
    },
    addWord: function(a) {
        var t = this, e = a.currentTarget.dataset.word;
        o.addVocab(e.id).then(function(a) {
            0 === a.data.code ? (t.data.wordExplain.collect = !0, t.setData({
                wordExplain: t.data.wordExplain
            }), t.showToast("添加成功", 1e3), t.getHotWord()) : t.showToast(a.data.msg);
        });
    },
    deleteWord: function(a) {
        var t = this, e = a.currentTarget.dataset.word;
        o.dropVocab(e.id).then(function(a) {
            0 === a.data.code && (t.data.wordExplain.collect = !1, t.setData({
                wordExplain: t.data.wordExplain
            }), t.showToast("删除成功", 1e3), t.getHotWord());
        });
    },
    closeGuide4: function() {
        this.setData({
            openWordBookGudie: !1
        });
    },
    toggleWordBook: function() {
        this.setData({
            isShowWordBook: !this.data.isShowWordBook
        }), this.data.isShowWordBook ? e.globalData.setting.playAudio("btnClick") : (this.toggleSettingPage(), 
        this.changeTestTab(0), this.data.openWordBookGudie && this.closeGuide4());
    },
    openIdiom: function(a) {
        var t = a.detail.word;
        this.openIdiomPopup(t);
    },
    openIdiomPopup: function(a) {
        var t = this;
        e.globalData.setting.playAudio("btnClick"), o.explanation(a).then(function(a) {
            0 === a.data.code && t.setData({
                showIdiomPopup: !0,
                wordExplain: a.data.data
            });
        });
    },
    closeIdiomPopup: function() {
        if (e.globalData.setting.playAudio("btnClick"), this.setData({
            showIdiomPopup: !1
        }), !this.data.showIdiomPopup) {
            var a = this.selectComponent("#wordbook");
            a && a.getWordList();
        }
    },
    toggleShowOff: function() {
        this.setData({
            isShowShowOff: !this.data.isShowShowOff
        });
    },
    closeReward: function() {
        if (this.setData({
            isBuyTip: !1
        }), 10 != this.data.rewardType) {
            1 == this.data.rewardType && 3 == this.data.player.position.curIndex && (this.setData({
                iconType: 1
            }), this.toggleShowOff()), console.log("closeReward"), e.globalData.setting.playAudio("btnClick");
            var a = this.data.moreGameList.length > 6 ? 6 : this.data.moreGameList.length, t = Math.round(Math.random() * a);
            this.data.moreGameList.length > 6 ? this.setData({
                moreGameSideList: e.getRandomArrayElements(this.data.moreGameList, 6),
                moreGameSideListNum: 3,
                moreGameSideIndex: t
            }) : this.setData({
                moreGameSideList: this.data.moreGameList,
                moreGameSideListNum: Math.floor(this.data.moreGameList.length / 2),
                moreGameSideIndex: t
            }), this.setData({
                isShowReward: !1
            });
        } else this.setData({
            isEnergyTip: !1,
            isShowReward: !0,
            rewardType: 6,
            commonGetEnegyPopupValue: 10
        });
    },
    toggleReward: function(a) {
        var t = this;
        e.log("type", a, "string" == typeof a);
        var i = {};
        a && "string" == typeof a && (i.rewardType = a, 4 != a && e.globalData.setting.playAudio("levelUp")), 
        i.isBuyTip = !1, i.isEnergyTip = !1, i.isShowReward = !this.data.isShowReward, 2 == this.data.rewardType && 1 == this.data.houseIndex && (i.newguideCarShow = 1, 
        i.newguideHouseShow = 0, setTimeout(function() {
            t.setData({
                newguideCarShow: 0
            });
        }, 3e3)), this.setData(i), this.data.isShowReward && this.showMixinBanner();
    },
    init: function() {
        var a = this;
        this.data.isTest || (e.setWatch(this, "", "index"), this.setData({
            soundSwitch: e.globalData.setting.getSetting().isPlayAudio
        }), -1 != i.model.indexOf("iPhone X") && this.setData({
            isIphonX: !0
        }), wx.createSelectorQuery().select("#navbar>>>#navBarLives").boundingClientRect(function(t) {
            t && a.setData({
                livesRect: {
                    left: t.left / i.pixelRate,
                    top: t.top / i.pixelRate
                }
            }), wx.createSelectorQuery().select("#livesEndId1").boundingClientRect(function(t) {
                if (t) {
                    var e = t.left / i.pixelRate + 255 - a.data.livesRect.left, o = t.top / i.pixelRate + 44 - a.data.livesRect.top;
                    a.data.moveAnimationOrigin = "transform: translate(" + e + "rpx, " + o + "rpx) scale(1.3)";
                }
            }).exec();
        }).exec(), Promise.all([ this.getFigureConfig(), this.getInviteList(), this.getShareAddEnergyStrategy(), this.getGuideList(), this.activityDetail() ]).then(function(t) {
            e.shareVideoRule(), a.getPlayer(), a.previewLevel(), a.makeEnergy(!0), a.getShareResult(), 
            a.tableScreenStrategy(), a.getMoreGameData();
        }));
    },
    tableScreenStrategy: function() {
        o.tableScreenStrategy().then(function(a) {
            0 === a.data.code && (e.globalData.tableScreenStrategy = a.data.data);
        });
    },
    getShareResult: function() {
        var a = this;
        o.getShareResult().then(function(t) {
            if (0 === t.data.code) {
                e.globalData.shareResult = t.data.data, a.setData({
                    shareResult: t.data.data
                });
                for (var i = [], o = 1; o < 6; o++) {
                    var n = a.data.shareResult["load_img_" + o], s = a.data.shareResult["load_txt_" + o], r = {
                        bg: n,
                        txt: s
                    };
                    n && s && i.push(r);
                }
                wx.setStorage({
                    key: "loadingList",
                    data: i
                });
            }
        });
    },
    getGuideList: function() {
        o.guideList().then(function(a) {
            0 === a.data.code && (e.globalData.guideList = a.data.data);
        });
    },
    toggleEarnEnergy: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowEarnEnergy: !this.data.isShowEarnEnergy
        }), this.data.isShowEarnEnergy ? this.checkEarnList() : this.makeEnergy(!0);
    },
    changeSwiper1: function(a) {
        this.setData({
            currentSwiper1: a.detail.current
        });
    },
    lastSwiper1: function() {
        0 !== this.data.currentSwiper1 && this.setData({
            currentSwiper1: this.data.currentSwiper1 - 1
        });
    },
    nextSwiper1: function() {
        2 !== this.data.currentSwiper1 && this.setData({
            currentSwiper1: this.data.currentSwiper1 + 1
        });
    },
    toggleCollectApp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowCollectApp: !this.data.isShowCollectApp
        });
    },
    switchNewguideHouse: function() {
        var a = this;
        1 !== this.data.newguideHouseShow && (e.globalData.setting.playAudio("btnClick"), 
        this.setData({
            newguideHouseShow: 0 === this.data.newguideHouseShow ? 1 : 0
        }), setTimeout(function() {
            a.setData({
                newguideHouseShow: 0
            });
        }, 3e3));
    },
    switchNewguideCar: function() {
        var a = this;
        1 !== this.data.newguideCarShow && (e.globalData.setting.playAudio("btnClick"), 
        this.setData({
            newguideCarShow: 0 === this.data.newguideCarShow ? 1 : 0
        }), setTimeout(function() {
            a.setData({
                newguideCarShow: 0
            });
        }, 3e3));
    },
    shareGetEnergySuccess: function() {
        var a = this;
        o.shareAddEnergy("share").then(function(t) {
            0 === t.data.code && (a.selectComponent("#navbar") && a.selectComponent("#navbar").shareSuccess(), 
            e.shareVideoRule(), e.log("xxxxxxxxxxxxxxxxxxxxxxx", e.globalData.shareGetEnergy.isFirst), 
            e.log("xxxxxxxxxxxxxxxxxxxxxxx", e.globalData.shareGetEnergy.leftTimes), a.selectComponent("#navbar") && a.selectComponent("#navbar").getData("noInit"), 
            a.selectComponent("#navbar") && a.selectComponent("#navbar").closeNoEnergyPopup(), 
            e.log("xxxxxxxxxxxxxxxxxxxxxxx", e.globalData.shareGetEnergy.isFirst), e.log("xxxxxxxxxxxxxxxxxxxxxxx", e.globalData.shareGetEnergy.leftTimes));
        });
    },
    rootCatch: function() {
        e.clearLostUserTimer("homePageUpgrade"), e.clearLostUserTimer("figureLevelGuide"), 
        this.data.newguideHouseShow && this.switchNewguideHouse(), this.data.newguideCarShow && this.switchNewguideCar(), 
        this.data.showNewPlayerModal4 && this.closeGuide1(), this.data.earnEnergyGudie && this.closeGuide2(), 
        this.data.viewRankGudie && this.closeGuide3(), this.data.openWordBookGudie && this.closeGuide4();
    },
    toSetData: function(a) {
        this.setData(a.detail);
    },
    searchWord: function(a) {
        var t = a.detail.value.trim(), e = this.data.idioms.filter(function(a) {
            return a.idiom === t;
        })[0];
        e ? (this.setData({
            wordItem: e
        }), this.swithIdiomPopup()) : this.showToast("暂未收录，敬请期待");
    },
    swithIdiomPopup: function(a) {
        if (e.globalData.setting.playAudio("btnClick"), this.setData({
            showIdiomPopup: !this.data.showIdiomPopup
        }), this.data.showIdiomPopup && a && a.currentTarget.dataset.item) {
            var t = a.currentTarget.dataset.item;
            this.setData({
                wordExplain: t
            });
        }
    },
    showToast: function(a) {
        var t = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3, o = [];
        o = "string" == typeof a || "number" == typeof a ? [ a ] : a, this.data.toastList.push(o), 
        e.log("time2", i), this.setData({
            toastTime: i,
            toastList: this.data.toastList
        }), s && clearTimeout(s), s = setTimeout(function() {
            s = "", t.setData({
                toastList: []
            });
        }, i);
    },
    playClickSound: function(a) {
        "sign" === a.currentTarget.dataset.type ? this.data.whatDidIDo = "goDaysSign" : "gzhSign" === a.currentTarget.dataset.type && (this.data.goGzhSign = !0, 
        e.actionTrace({
            event: "index_wxoa",
            subEvent: "index_wxoa_click"
        }));
    },
    toSign: function() {
        this.data.whatDidIDo = "goDaysSign";
    },
    toGzh: function() {
        e.setGlobalData({
            goGzhSign: !0
        });
    },
    toFriendLine: function() {
        this.data.friendLine = !0;
    },
    toggleFriendLine: function() {
        this.setData({
            isShowFriendLine: !this.data.isShowFriendLine
        }), this.data.isShowFriendLine || this.setData({
            friendLineType: ""
        });
    },
    clickSection: function(a) {
        switch (e.globalData.setting.playAudio("btnClick"), a.currentTarget.dataset.index) {
          case 0:
            this.toggleInvite();
        }
    },
    getAllEnergyByInvite: function() {
        var a = this;
        e.globalData.setting.playAudio("btnClick"), this.data.totalValue && o.getAllEnergyByInvite().then(function(t) {
            0 === t.data.code ? (a.selectComponent("#navbar") && a.selectComponent("#navbar").getData(), 
            a.getInviteList(), a.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: a.data.totalValue
            }), a.showMixinBanner(), e.globalData.setting.playAudio("getEnergy")) : a.showToast(t.data.msg);
        });
    },
    getEnergyByInvite: function(a) {
        var t = this, i = a.currentTarget.dataset.item;
        e.globalData.setting.playAudio("btnClick"), o.getEnergyByInvite(i.invitedId).then(function(a) {
            0 === a.data.code ? (t.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: i.energyValue
            }), t.showMixinBanner(), e.globalData.setting.playAudio("getEnergy"), t.selectComponent("#navbar") && t.selectComponent("#navbar").getData(), 
            t.getInviteList()) : t.showToast(a.data.msg);
        });
    },
    toggleInvite: function() {
        this.data.isShowInvite && e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowInvite: !this.data.isShowInvite
        });
    },
    toggleSignUp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowSignUp: !this.data.isShowSignUp,
            daysSignStyle: !!this.data.newUserHadDaysSign
        });
    },
    closeDaysLoginRewardPopup: function() {
        e.actionTrace({
            event: "sign_gift",
            subEvent: "sign_gift_close"
        }), e.globalData.setting.playAudio("btnClick"), this.setData({
            daysLoginRewardPopup: !1
        }), o.abandonDailyLoginAward();
    },
    getRankData: function() {
        var a = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        wx.showLoading({
            title: "加载中"
        }), o.ranking(this.data.activeRank, t).then(function(t) {
            0 === t.data.code && a.setData({
                rankData: t.data.data
            }), wx.hideLoading();
        }).catch(function(a) {
            wx.hideLoading();
        });
    },
    changeDate: function(a) {
        e.globalData.setting.playAudio("btnClick");
        var t = a.currentTarget.dataset.type;
        e.log("type", t);
        var i = this.data.currentDate;
        if ("left" == t) {
            if (this.data.rankClickNum >= 6) return;
            this.data.rankClickNum += 1, i.setTime(i.getTime() - 864e5);
        } else {
            if (0 == this.data.rankClickNum) return;
            this.data.rankClickNum -= 1, i.setTime(i.getTime() + 864e5);
        }
        this.setData({
            scrollTop: 0,
            rankClickNum: this.data.rankClickNum,
            currentDate: i,
            currentDateText: this.dateFilter(i, 1)
        }), this.getRankData(this.dateFilter(i));
    },
    dateFilter: function(a, t) {
        return e.log("date", a, a.getFullYear() + "-" + this.fillZero(a.getMonth() + 1) + "-" + this.fillZero(a.getDate())), 
        1 == t ? a.getFullYear() + "-" + this.fillZero(a.getMonth() + 1) + "-" + this.fillZero(a.getDate()) : "" + a.getFullYear() + this.fillZero(a.getMonth() + 1) + this.fillZero(a.getDate());
    },
    fillZero: function(a) {
        return a < 10 ? "0" + a : a;
    },
    toggleRank: function() {
        e.globalData.setting.playAudio("btnClick"), this.data.isShowRank || (this.getRankData(), 
        this.data.viewRankGudie && this.closeGuide3()), this.setData({
            rankClickNum: 0,
            isShowRank: !this.data.isShowRank,
            activeRank: 0,
            rankData: []
        });
    },
    onHide: function() {
        console.log("index.onHide"), this.data.isShare || e.actionTrace({
            event: "page_hide",
            subEvent: ""
        }), this.setData({
            moveAnimation1: "",
            pageHide: !0
        }), this.selectComponent("#navbar") && this.selectComponent("#navbar").hide();
    },
    levelUp: function(a) {
        var t = this, i = a.currentTarget.dataset.type;
        e.sourceReport("imageup_button_click"), 1 == i && e.sourceReport("lead_grade_click"), 
        2 == i && e.sourceReport("house_grade_click"), 3 == i && e.sourceReport("vehicle_grade_click"), 
        e.log("type", i), o.upgrade(i).then(function(a) {
            0 === a.data.code ? (t.data.newPlayHelp && (t.setData({
                newPlayHelp: "",
                showNewPlayerModal4: !0,
                isFirstHouseGuide: !0
            }), t.data.image2 = !0, e.setLostUserTimer("figureLevelGuide")), t.getPlayer(!0, i)) : t.showToast(a.data.msg);
        });
    },
    closeGuide1: function() {
        this.setData({
            showNewPlayerModal4: !1
        });
    },
    openZhuangYuanBang: function() {
        var a = this;
        e.globalData.setting.playAudio("btnClick"), o.scholarMedalList().then(function(t) {
            a.setData({
                zhuangyuanbangList: t.data.data,
                showZhuangyuanbang: !0
            });
        });
    },
    closeZhuangyuanbang: function() {
        this.setData({
            showZhuangyuanbang: !1
        });
    },
    toggleMoreGame: function() {
        var a = this;
        this.data.showMoreGamePopup ? this.setData({
            showMoreGamePopup: !1
        }) : (e.globalData.setting.playAudio("btnClick"), o.moreGame().then(function(t) {
            0 === t.data.code && a.setData({
                moreGameList: t.data.data,
                showMoreGamePopup: !0
            });
        })), this.data.isShowSettingPage && this.setData({
            isShowSettingPage: !1
        });
    },
    toggleListPopup: function(a) {
        var t = this;
        if (e.globalData.setting.playAudio("btnClick"), this.data.isShowListPopup) this.setData({
            isShowListPopup: !this.data.isShowListPopup
        }), this.data.isFirstHouseGuide && (this.setData({
            newguideHouseShow: 1,
            isFirstHouseGuide: !1
        }), setTimeout(function() {
            t.setData({
                newguideHouseShow: 0
            });
        }, 3e3)); else {
            var i = a.currentTarget.dataset.type || 0, o = void 0, n = void 0;
            if (2 === i) o = this.data.listData.houseList, n = this.data.player.house.curIndex, 
            setTimeout(function() {
                t.setData({
                    scrollId: "list-scroll-item" + (o.length - n)
                });
            }, 50); else if (3 === i) {
                if (this.data.carIndex <= 0) return;
                o = this.data.listData.carList, n = this.data.player.car.curIndex, setTimeout(function() {
                    t.setData({
                        scrollId: "list-scroll-item" + (o.length - n)
                    });
                }, 50);
            } else o = this.data.listData.jobList, n = this.data.player.position.curIndex, this.data.showNewPlayerModal4 && this.closeGuide1(), 
            setTimeout(function() {
                t.setData({
                    scrollId: "list-scroll-item" + (o.length - n - 1)
                });
            }, 50);
            this.setData({
                curListIndex: n,
                list: o,
                listType: i,
                isShowListPopup: !this.data.isShowListPopup
            });
        }
    },
    toGameRank: function() {
        e.log("toGameRank"), this.toggleRank(), this.toGame(!0);
    },
    toGame: function(a) {
        var t = this;
        e.globalData.mode = 1, this.data.isStarted || (this.data.isShowDetention && e.actionTrace({
            event: "guide_game_detain",
            subEvent: "guide_detain_click"
        }), this.setData({
            isShowDetention: !1,
            isShowReward: !1
        }), this.data.isStarted = !0, a || e.globalData.setting.playAudio("btnClick"), this.data.player.nextUnlock ? wx.navigateTo({
            url: "/pages/game/game?level=" + this.data.player.nextLevel,
            success: function() {
                t.data.isStarted = !1;
            }
        }) : this.selectComponent("#navbar") && this.selectComponent("#navbar").useEnergy());
    },
    resetStart: function() {
        this.data.isStarted = !1;
    },
    toGameRedirect: function() {
        var a = this;
        e.globalData.mode = 1, this.setData({
            isShowDetention: !1,
            moveAnimation1: this.data.moveAnimationOrigin
        }), setTimeout(function() {
            a.setData({
                moveAnimation1: ""
            }), wx.navigateTo({
                url: "/pages/game/game?level=" + a.data.player.nextLevel,
                success: function() {
                    a.data.isStarted = !1;
                }
            });
        }, 800);
    },
    clickSideBtn: function(a) {
        e.log("e", a);
        var t = a.currentTarget.dataset.type;
        if (t) switch (t) {
          case "activity":
            this.toActivity(), this.data.todayRedPointDict.activity && (this.data.todayRedPointDict.activity = !1, 
            this.setData({
                todayRedPointDict: this.data.todayRedPointDict
            }), wx.setStorage({
                key: "todayRedPointDict",
                data: this.data.todayRedPointDict
            }));
            break;

          case "sound":
            this.toggleSound();
            break;

          case "rank":
            this.toggleRank();
            break;

          case "sign":
            this.data.player.yearCardUser ? this.toSignWatchVideo() : this.toggleSignUp();
            break;

          case "energy":
            e.sourceReport("receive_energy_visit"), e.globalData.setting.playAudio("btnClick"), 
            this.data.todayRedPointDict.total && (this.data.todayRedPointDict.total = !1, this.setData({
                todayRedPointDict: this.data.todayRedPointDict
            }), wx.setStorage({
                key: "todayRedPointDict",
                data: this.data.todayRedPointDict
            })), this.data.earnEnergyGudie && this.closeGuide2(), this.makeEnergy();
            break;

          case "setting":
            this.toggleSettingPage();
            break;

          case "shop":
            this.toggleShop(), this.data.todayRedPointDict.shop && (this.data.todayRedPointDict.shop = !1, 
            this.setData({
                todayRedPointDict: this.data.todayRedPointDict
            }), wx.setStorage({
                key: "todayRedPointDict",
                data: this.data.todayRedPointDict
            }));
            break;

          case "moreGame":
            this.toggleMoreGame(), this.data.todayRedPointDict.moreGame && (this.data.todayRedPointDict.moreGame = !1, 
            this.setData({
                todayRedPointDict: this.data.todayRedPointDict
            }), wx.setStorage({
                key: "todayRedPointDict",
                data: this.data.todayRedPointDict
            }));
        }
    },
    closeGuide2: function() {
        this.setData({
            earnEnergyGudie: !1
        }), e.globalData.guideList.noEnergy = !0, e.setGlobalData(a({}, "guideList.noEnergy", !0));
    },
    closeGuide3: function() {
        this.setData({
            viewRankGudie: !1
        });
    },
    toggleSound: function() {
        var a = e.globalData.setting.switchAudio().isPlayAudio;
        e.log("soundSwitch", a), this.setData({
            soundSwitch: a
        }), e.globalData.setting.playAudio("btnClick");
    },
    configHandle: function() {
        this.data.carList, this.data.houseList, this.data.jobList, this.data.allList;
    },
    toggleSettingPage: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowSettingPage: !this.data.isShowSettingPage
        });
    },
    levelListHandle: function() {
        var a = [], t = -1, e = 0, i = "", o = !1, n = !1;
        a.push(this.data.player.car), a.push(this.data.player.house), a.push(this.data.player.position), 
        "未解锁" != this.data.player.car.curName && (o = !0), "未解锁" != this.data.player.house.curName && (n = !0), 
        this.setData({
            isShowCar: o,
            isShowHouse: n
        });
        var s = -1, r = void 0, d = !1, l = !0, h = !1, g = void 0;
        try {
            for (var c, u = a[Symbol.iterator](); !(l = (c = u.next()).done); l = !0) {
                var p = c.value;
                0 === p.achieve ? (d = !0, -1 == s ? (s = p.type, r = p.nextLevel) : p.nextLevel < r && (s = p.type, 
                r = p.nextLevel)) : (-1 === t || -1 != t && t > p.achieve) && (t = p.achieve, e = p.achieve, 
                i = p.tip);
            }
        } catch (a) {
            h = !0, g = a;
        } finally {
            try {
                !l && u.return && u.return();
            } finally {
                if (h) throw g;
            }
        }
        this.setData({
            isShowBtn: d,
            levelUpTip: i,
            btnType: s,
            achieve: e
        });
    },
    switchDaysSignStyle: function() {
        this.setData({
            daysSignStyle: !this.data.daysSignStyle
        });
    },
    getFigureConfig: function() {
        var a = this;
        return new Promise(function(t, i) {
            o.figureConfig().then(function(o) {
                0 === o.data.code ? (e.globalData.listData = o.data.data, a.setData({
                    listData: o.data.data,
                    baseUrl: o.data.data.baseUrl
                }), t()) : i(o);
            }).catch(function(a) {
                i(a);
            });
        });
    },
    makeEnergy: function(a) {
        var t = this;
        o.makeEnergy().then(function(i) {
            if (e.log("xxxxxxxxxxxxxx", i.data), 0 === i.data.code) {
                var o = !1, n = !0, s = !1, r = void 0;
                try {
                    for (var d, l = i.data.data[Symbol.iterator](); !(n = (d = l.next()).done); n = !0) {
                        var h = d.value;
                        1 === h.buttonType && (o = !0), "gametry" == h.sectionType && (console.log("gametry", h.gameTryList), 
                        e.globalData.gameTryList = h.gameTryList);
                    }
                } catch (a) {
                    s = !0, r = a;
                } finally {
                    try {
                        !n && l.return && l.return();
                    } finally {
                        if (s) throw r;
                    }
                }
                t.setData({
                    isShowEnergyRed: o,
                    earnEnergyList: i.data.data,
                    isShowEarnEnergy: !a
                }), t.data.isShowEarnEnergy && t.checkEarnList();
            }
        });
    },
    checkEarnList: function() {
        var a = !0, t = !1, i = void 0;
        try {
            for (var o, n = this.data.earnEnergyList[Symbol.iterator](); !(a = (o = n.next()).done); a = !0) {
                var s = o.value;
                "gzhReceive" == s.sectionType && e.actionTrace({
                    event: "enlist_wxoa",
                    subEvent: "enlist_wxoa_show"
                }), "sharePyq" == s.sectionType && e.actionTrace({
                    event: "enlist_sharepq",
                    subEvent: "enlist_sharepq_show"
                });
            }
        } catch (a) {
            t = !0, i = a;
        } finally {
            try {
                !a && n.return && n.return();
            } finally {
                if (t) throw i;
            }
        }
    },
    tapEarnEnergy: function(a) {
        var t = this, i = a.currentTarget.dataset.item;
        if (i.sectionType) {
            switch (i.sectionType) {
              case "friend":
                this.getInviteList(!0);
                break;

              case "dailySign":
                e.globalData.setting.playAudio("btnClick"), this.setData({
                    isShowSignUp: !0,
                    daysSignStyle: !!this.data.newUserHadDaysSign
                });
                break;

              case "gzhReceive":
                this.toggleGzhSignUp();
                break;

              case "collect":
                1 === i.buttonType ? this.doCollectGame(2).then(function(a) {
                    e.setGlobalData({
                        energyTotal: e.globalData.energyTotal + i.energyValue
                    }), t.data.earnEnergyList = t.data.earnEnergyList.filter(function(a) {
                        return "collect" !== a.sectionType;
                    }), t.setData({
                        earnEnergyList: t.data.earnEnergyList,
                        isEnergyTip: !0,
                        isShowReward: !0,
                        commonGetEnegyPopupValue: i.energyValue,
                        rewardType: 5
                    }), t.showMixinBanner();
                }) : this.toggleCollectApp();
                break;

              case "addwindow":
                1 === i.buttonType ? (e.globalData.setting.playAudio("btnClick"), this.addFloatWindow(2).then(function(a) {
                    e.setGlobalData({
                        energyTotal: e.globalData.energyTotal + i.energyValue
                    }), t.data.earnEnergyList = t.data.earnEnergyList.filter(function(a) {
                        return "addwindow" !== a.sectionType;
                    }), t.setData({
                        earnEnergyList: t.data.earnEnergyList,
                        isEnergyTip: !0,
                        isShowReward: !0,
                        commonGetEnegyPopupValue: i.energyValue,
                        rewardType: 5
                    }), t.showMixinBanner();
                })) : this.toggleAddFuchuang();
                break;

              case "sharePyq":
                1 === i.buttonType ? o.sharePyq(2).then(function(a) {
                    0 === a.data.code && (e.setGlobalData({
                        energyTotal: e.globalData.energyTotal + i.energyValue
                    }), t.data.earnEnergyList = t.data.earnEnergyList.filter(function(a) {
                        return "sharePyq" !== a.sectionType;
                    }), t.setData({
                        isShowFriendLine: !1,
                        earnEnergyList: t.data.earnEnergyList,
                        isEnergyTip: !0,
                        isShowReward: !0,
                        commonGetEnegyPopupValue: i.energyValue,
                        rewardType: 5
                    }), t.showMixinBanner());
                }) : this.toggleFriendLine();
                break;

              case "wanyuan":
                this.toActivity();
                break;

              case "gametry":
                e.globalData.gameTryList || (e.globalData.gameTryList = i.gameTryList), this.toggleGameTry();
                break;

              case "watchScholar":
                e.globalData.setting.playAudio("btnClick"), wx.navigateTo({
                    url: "/package/pages/weekReport/weekReport?week=" + i.week
                });
                break;

              case "watchVideo":
                this.toggleWatchVideo();
                break;

              case "inviteNewUser":
                1 === i.buttonType ? o.getAllNewUserInviteEnergy().then(function(a) {
                    console.log("res", a), 0 === a.data.code && (e.setGlobalData({
                        energyTotal: e.globalData.energyTotal + a.data.data.value
                    }), t.data.earnEnergyList = t.data.earnEnergyList.filter(function(a) {
                        return "inviteNewUser" !== a.sectionType;
                    }), t.setData({
                        earnEnergyList: t.data.earnEnergyList,
                        isEnergyTip: !0,
                        isShowReward: !0,
                        commonGetEnegyPopupValue: a.data.data.value,
                        rewardType: 5
                    }), t.showMixinBanner());
                }) : this.toggleInviteNew();
            }
            this.data.todayRedPointDict[i.sectionType] && (this.data.todayRedPointDict[i.sectionType] = !1, 
            this.setData({
                todayRedPointDict: this.data.todayRedPointDict
            }), wx.setStorage({
                key: "todayRedPointDict",
                data: this.data.todayRedPointDict
            }));
        }
    },
    toggleGameTry: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGameTry: !this.data.isShowGameTry
        });
    },
    toggleGzhSignUp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGzhSign: !this.data.isShowGzhSign
        });
    },
    getPlayer: function(a, t) {
        var i = this;
        o.player().then(function(n) {
            if (0 === n.data.code) {
                wx.setStorage({
                    key: "player",
                    data: n.data.data
                }), e.globalData.player = n.data.data, e.appOnshow();
                var s = n.data.data.car, r = n.data.data.house, d = n.data.data.position, l = [ s, r, d ], h = [], g = !0, c = !1, u = void 0;
                try {
                    for (var p, y = l[Symbol.iterator](); !(g = (p = y.next()).done); g = !0) {
                        var w = p.value;
                        0 === w.achieve && h.push(w);
                    }
                } catch (a) {
                    c = !0, u = a;
                } finally {
                    try {
                        !g && y.return && y.return();
                    } finally {
                        if (c) throw u;
                    }
                }
                var v = i.data.listData.carList[i.data.listData.carList.length - s.curIndex], D = i.data.listData.houseList[i.data.listData.houseList.length - r.curIndex], m = i.data.listData.jobList[i.data.listData.jobList.length - d.curIndex - 1];
                e.log("carItem", v);
                var f = {
                    isBeta: n.data.data.isBeta,
                    player: n.data.data,
                    positionIndex: d.curIndex,
                    carIndex: s.curIndex,
                    houseIndex: r.curIndex,
                    levelUpList: h
                };
                v && (f.carWidth = v.resWidth, f.carHeight = v.resHeight, f.carResource = v.resource), 
                D && (f.houseResource = D.resource), m && (f.jobResource = m.resource), a ? i.data.background != n.data.data.background && (f.isChangeBg = !0) : (f.background = n.data.data.background, 
                f.nextBackground = n.data.data.nextBackground, f.isChangeBg = !1), n.data.data.canPopWeekScholar && (f.canPopWeekScholar = !0), 
                f.isSubscribe = n.data.data.isSubscribe, i.data.isSubscribe && e.actionTrace({
                    event: "index_wxoa",
                    subEvent: "index_wxoa_show"
                }), f.firstSign = n.data.data.firstSign, i.setData(f), i.levelListHandle(), n.data.data.activityEnable && e.setGlobalData({
                    showWanyuanActivity: n.data.data.activityEnable
                });
                var b = n.data.data.signDays + 1;
                n.data.data.sign && (b = n.data.data.signDays);
                var S = Math.floor((b - 8) / 6) + 1;
                S < 0 && (S = 0), i.setData({
                    daysSignInfo: {
                        nowSignDays: b,
                        week: S
                    }
                }), "goDaysSign" === i.data.whatDidIDo && n.data.data.firstSign && i.signSuccess(), 
                wx.getStorageSync("newUserHadDaysSign") && i.setData({
                    newUserHadDaysSign: !0
                }), n.data.data.gzhEnergy && (i.setData({
                    isEnergyTip: !0,
                    isShowReward: !0,
                    rewardType: 5,
                    commonGetEnegyPopupValue: n.data.data.gzhEnergy
                }), i.showMixinBanner(), e.globalData.setting.playAudio("getEnergy")), 1089 === e.globalData.scene && 0 === i.data.player.isCollectGame && i.doCollectGame(1).then(function(a) {
                    if (0 === a.data.code) for (var t = 0; t < i.data.earnEnergyList.length; t++) "collect" === i.data.earnEnergyList[t].sectionType && (i.data.earnEnergyList[t].buttonType = 1);
                }), 1131 === e.globalData.scene && i.addFloatWindow(1).then(function(a) {
                    if (console.log("addFloatWindow", a), 0 === a.data.code) for (var t = 0; t < i.data.earnEnergyList.length; t++) "addwindow" === i.data.earnEnergyList[t].sectionType && (i.data.earnEnergyList[t].buttonType = 1);
                }), n.data.data.canPopLoginAward && (i.data.hasPopLoginAward || (i.data.hasPopLoginAward = !0, 
                e.actionTrace({
                    event: "sign_gift",
                    subEvent: "sign_gift_visit"
                })), i.setData({
                    daysLoginRewardPopup: !0
                })), a && i.toggleReward(t), n.data.data.payEnable && i.shopShowHandle(), i.data.pageReady || (i.data.pageCountDownReady ? i.setData({
                    pageReady: !0
                }) : i.data.pageReady = !0), e.globalData.notFirstPlayer || (e.loginTrace("page_load", i.data.pageOptions), 
                e.actionTrace({
                    event: "page_show",
                    subEvent: ""
                }), e.sourceReport(), e.globalData.notFirstPlayer = !0), 1 == i.data.pageOptions.toShop && (e.actionTrace({
                    event: "index_coupon",
                    subEvent: "coupon_mes_open"
                }), i.toggleShop(), i.setData({
                    fromToShop: !0
                })), "pyqCard" == i.data.pageOptions.position && (i.data.friendLine = !1, o.sharePyq(2).then(function(a) {
                    0 === a.data.code && (e.setGlobalData({
                        energyTotal: e.globalData.energyTotal + a.data.data.awardValue
                    }), i.data.earnEnergyList = i.data.earnEnergyList.filter(function(a) {
                        return "sharePyq" !== a.sectionType;
                    }), i.setData({
                        isShowFriendLine: !1,
                        earnEnergyList: i.data.earnEnergyList,
                        isEnergyTip: !0,
                        isShowReward: !0,
                        commonGetEnegyPopupValue: a.data.data.awardValue,
                        rewardType: 5
                    }), i.showMixinBanner());
                })), wx.setStorage({
                    key: "yearCardUser",
                    data: n.data.data.yearCardUser
                }), i.data.pageOptions.otherId && o.gamePageShareClick(i.data.pageOptions.otherId, i.data.pageOptions.shareTsp, i.data.pageOptions.bonusType), 
                i.data.player.nextLevel < 3 ? (i.setData({
                    isShowDetention: !0
                }), e.actionTrace({
                    event: "guide_game_detain",
                    subEvent: "guide_detain_show"
                })) : i.setData({
                    isShowDetention: !1
                }), "true" == i.data.pageOptions.goWeekReport ? (i.data.pageOptions.goWeekReport = "", 
                i.data.forceGoGame = !0, wx.navigateTo({
                    url: "/package/pages/weekReport/weekReport?week=" + i.data.pageOptions.week + "&shareId=" + i.data.pageOptions.shareId
                })) : n.data.data.canPopActivityWindow ? i.setData({
                    showGoActivityPopup: !0
                }) : 1 === n.data.data.nextLevel && 2 === n.data.data.nextLevel ? (e.globalData.mode = 1, 
                e.globalData.notFirstLoad || i.data.isTest || (e.globalData.notFirstLoad = !0, wx.navigateTo({
                    url: "/pages/game/game?level=" + n.data.data.nextLevel
                }), i.setData({
                    isShowDetention: !1
                }))) : i.data.forceGoGame || "1" != i.data.pageOptions.toGame && 1007 !== e.globalData.scene && 1008 !== e.globalData.scene && 1073 !== e.globalData.scene && 1044 !== e.globalData.scene && 1035 !== e.globalData.scene && 1058 !== e.globalData.scene || i.data.isIdiomShare || !(d.curIndex > 0) || i.data.isTest || (n.data.data.nextUnlock ? (e.globalData.mode = 1, 
                i.data.forceGoGame = !0, wx.navigateTo({
                    url: "/pages/game/game?level=" + n.data.data.nextLevel,
                    success: function() {
                        i.data.isStarted = !1;
                    }
                }), i.setData({
                    isShowDetention: !1
                })) : e.globalData.energyTotal > 0 && (i.data.forceGoGame = !0, i.selectComponent("#navbar") && i.selectComponent("#navbar").useEnergy()));
            }
        });
    },
    signSuccess: function(a) {
        o.yearCardUserSign(), this.data.whatDidIDo = "", this.setData({
            isEnergyTip: !0,
            isShowReward: !0,
            commonGetEnegyPopupValue: a ? 1 : this.data.firstSign,
            rewardType: 5
        }), this.showMixinBanner();
        var t = this.data.player;
        t.sign = !0, e.setGlobalData({
            player: t
        }), this.setData({
            player: t
        }), e.globalData.setting.playAudio("getEnergy"), wx.getStorageSync("newUserHadDaysSign") || (wx.setStorageSync("newUserHadDaysSign", "yes"), 
        this.setData({
            newUserHadDaysSign: !0
        }));
    },
    goActivity: function() {
        e.actionTrace({
            event: "activity_guide",
            subEvent: "activity_win_click"
        }), wx.navigateTo({
            url: "/package/pages/activity/activity?from=newGuide"
        }), this.setData({
            showGoActivityPopup: !1
        });
    },
    closeGoActivity: function() {
        e.actionTrace({
            event: "activity_guide",
            subEvent: "activity_cwin_click"
        }), wx.navigateTo({
            url: "/package/pages/activity/activity?from=newGuide"
        }), this.setData({
            showGoActivityPopup: !1
        });
    },
    getMoreGameData: function() {
        var a = this;
        o.moreGame().then(function(t) {
            if (0 === t.data.code) {
                e.setGlobalData({
                    moreGameList: t.data.data
                });
                var i = a.data.moreGameList.length > 6 ? 6 : a.data.moreGameList.length, o = Math.round(Math.random() * i);
                a.data.moreGameList.length > 6 ? a.setData({
                    moreGameSideList: e.getRandomArrayElements(a.data.moreGameList, 6),
                    moreGameSideListNum: 3,
                    moreGameSideIndex: o
                }) : a.setData({
                    moreGameSideList: a.data.moreGameList,
                    moreGameSideListNum: Math.floor(a.data.moreGameList.length / 2),
                    moreGameSideIndex: o
                });
            }
        });
    },
    getEnergyWatchVideo: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.watchVideoAdv
        }), e.globalData.shareVideoRule.adv.watchVideoAdv) {
            var i = null;
            (i = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.watchVideoAdv
            })).load(), i.offError(), i.onError(function(i) {
                console.log("err", i), o.shareVideoDynamicControl(), t.getEnergyWatchVideoSuccess();
                var n = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var s in e.globalData.shareVideoRule) "canWatchVideo" != s && (n[[ "shareVideoRule." + s ]] = 1);
                e.setGlobalData(n);
            }), i.offClose(), i.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.watchVideoAdv
                }), t.getEnergyWatchVideoSuccess()) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(t.getEnergyWatchVideo), 
                e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.watchVideoAdv
                }), t.showToast("请观看完整视频"));
            }), i.show().catch(function(a) {
                i.load().then(function() {
                    i.show();
                });
            }), this.data.videoAd = i;
        } else this.getEnergyWatchVideoSuccess();
    },
    toSignWatchVideo: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
        }), e.globalData.shareVideoRule.adv.dailySignAdv) {
            var i = null;
            (i = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.dailySignAdv
            })).load(), i.offError(), i.onError(function(t) {
                console.log("err", t), o.shareVideoDynamicControl();
                var i = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var n in e.globalData.shareVideoRule) "canWatchVideo" != n && (i[[ "shareVideoRule." + n ]] = 1);
                e.setGlobalData(i);
            }), i.offClose(), i.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
                }), t.signSuccess(!0)) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(t.toSignWatchVideo), 
                e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
                }), t.showToast("请观看完整视频"));
            }), i.show().catch(function(a) {
                i.load().then(function() {
                    i.show();
                });
            }), this.data.videoAd = i;
        } else this.signSuccess(!0);
    },
    getEnergyWatchVideoSuccess: function() {
        var a = this;
        o.makeEnergyWatchVideo().then(function(t) {
            if (0 === t.data.code) {
                e.globalData.setting.playAudio("getEnergy");
                var i = a.data.earnEnergyList.filter(function(a) {
                    return "watchVideo" === a.sectionType;
                })[0];
                console.log("watchVideo", i, i.curValue, i.upperValue), i && i.curValue == i.upperValue - 1 ? a.data.earnEnergyList = a.data.earnEnergyList.filter(function(a) {
                    return "watchVideo" !== a.sectionType;
                }) : i.curValue += 1, e.setGlobalData({
                    energyTotal: e.globalData.energyTotal + t.data.data.awardValue
                }), a.data.rewardType = 5, a.setData({
                    earnEnergyList: a.data.earnEnergyList,
                    isEnergyTip: !0,
                    isShowReward: !0,
                    commonGetEnegyPopupValue: t.data.data.awardValue,
                    daysLoginRewardPopup: !1,
                    rewardType: a.data.rewardType
                }), a.showMixinBanner();
            } else a.showToast(t.data.msg);
        });
    },
    daysLoginWatchAd: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.loginAwardAdv
        }), e.actionTrace({
            event: "sign_gift",
            subEvent: "sign_open_video"
        }), e.globalData.setting.playAudio("btnClick"), !e.globalData.shareVideoRule.adv.loginAwardAdv || this.data.player.shareForbidden && (this.data.player.advAuditSwitch || !this.data.player.advAuditSwitch && 1 == this.data.shareVideoRule.loginAward)) this.daySignShareSuccess(); else {
            e.log("ppppppp");
            var i = null;
            (i = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.loginAwardAdv
            })).load(), i.offError(), i.onError(function(i) {
                console.log("err", i), o.shareVideoDynamicControl(), t.daySignShareSuccess();
                var n = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var s in e.globalData.shareVideoRule) "canWatchVideo" != s && (n[[ "shareVideoRule." + s ]] = 1);
                e.setGlobalData(n);
            }), i.offClose(), i.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.loginAwardAdv
                }), t.daySignShareSuccess()) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(t.daysLoginWatchAd), 
                e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.loginAwardAdv
                }), t.showToast("请观看完整视频"));
            }), i.show().catch(function(a) {
                i.load().then(function() {
                    i.show();
                });
            }), this.data.videoAd = i;
        }
    },
    daysLoginEnergy: function() {
        e.globalData.setting.playAudio("btnClick"), e.actionTrace({
            event: "sign_gift",
            subEvent: "sign_open_share"
        }), this.data.toDaySignShare = Date.now();
    },
    daySignShareSuccess: function() {
        var a = this;
        e.actionTrace({
            event: "sign_gift",
            subEvent: "sign_open_suc"
        }), o.getDailyLoginAward().then(function(t) {
            e.log("xxxxxxxx", t), 0 === t.data.code ? 1 === t.data.data.awardType ? (e.setGlobalData({
                energyTotal: e.globalData.energyTotal + t.data.data.awardValue
            }), a.data.rewardType = 5, a.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                commonGetEnegyPopupValue: t.data.data.awardValue,
                daysLoginRewardPopup: !1,
                rewardType: a.data.rewardType
            }), a.showMixinBanner()) : 2 === t.data.data.awardType && (a.data.rewardType = 6, 
            a.setData({
                isShowReward: !0,
                commonGetEnegyPopupValue: t.data.data.awardValue,
                daysLoginRewardPopup: !1,
                rewardType: a.data.rewardType
            }), a.showMixinBanner()) : a.showToast(t.data.msg);
        });
    },
    doCollectGame: function(a) {
        return new Promise(function(t, e) {
            o.doCollectGame(a).then(function(a) {
                0 === a.data.code ? t(a) : e(a);
            }).catch(function(a) {
                e(a);
            });
        });
    },
    addFloatWindow: function(a) {
        return new Promise(function(t, e) {
            o.addFloatWindow(a).then(function(a) {
                0 === a.data.code ? t(a) : e(a);
            }).catch(function(a) {
                e(a);
            });
        });
    },
    toInvite: function() {
        this.getInviteList(!0);
    },
    bgLoadError: function() {
        this.setData({
            baseUrl: e.baseUrl() + "/addons/yf_chengyujiekong/resource/image/index/"
        });
    },
    getInviteList: function(a) {
        var t = this;
        return a && e.globalData.setting.playAudio("btnClick"), new Promise(function(e, i) {
            o.inviteFriendList().then(function(o) {
                if (0 === o.data.code) {
                    a && (0 === o.data.data.totalValue ? t.inviteFriend() : t.toggleInvite());
                    for (var n = o.data.data.inviteRecords, s = o.data.data.totalValue, r = !1, d = 0; d < 5; d++) {
                        var l = n[d];
                        l.invitedId ? l.used ? l.status = 1 : (l.status = 2, r = !0) : l.status = 3;
                    }
                    t.setData({
                        totalValue: s,
                        inviteList: n,
                        isShowInviteRedpoint: r
                    }), e();
                } else i(o);
            }).catch(function(a) {
                i(a);
            });
        });
    },
    getShareAddEnergyStrategy: function() {
        return new Promise(function(a, t) {
            o.shareAddEnergyStrategy().then(function(i) {
                0 === i.data.code ? (e.setGlobalData({
                    shareGetEnergy: i.data.data
                }), a()) : t(i);
            }).catch(function(a) {
                t(a);
            });
        });
    },
    toActivity: function() {
        e.globalData.setting.playAudio("btnClick"), wx.navigateTo({
            url: "/package/pages/activity/activity"
        });
    },
    shopGetUserInfo: function(a) {
        a.detail ? (n.clear(), e.setGlobalData({
            needAuth: !1,
            userInfo: a.detail.userInfo
        })) : this.showToast("请点击允许，授权信息购买能量");
    },


    
    // 头像
    closeFun: function() {//关闭弹层
      this.setData({
          toastCtrol: 0
      });
    },
    aonChooseAvatar(x) {
      console.log(x)
      var r = this
      //上传头像
      wx.showToast({
        title: "正在上传...",
        icon: "loading",
        mask: !0,
        duration: 1e4
      }),o.uimage(x.detail.avatarUrl).then(function(a) {
          
          console.log('upok')
          console.log(a.data)
          f = {}, r.setData((f["uface"] = a.data, f))

          //var uinfo = wx.getStorageSync("weapp_session_F2C224D4-2BCE-4C64-AF9F-A6D872000D1A");
          wx.setStorageSync("uface",a.data)
          wx.hideToast();
      })
    },

    //设置昵称
    ainputblur: function(d) {
      console.log(d)
      f = {}, this.setData((f["uname"]= d.detail.value, f));
      wx.setStorageSync("nickname",d.detail.value)
    },
    asetnike(e) {
      if (null == wx.getStorageSync("uface") || ''== wx.getStorageSync("uface")) {
        wx.showToast({
          title: '请设置头像',
          icon:"none",
          mask:"true"//是否设置点击蒙版，防止点击穿透
        })
        return
      }

      if (null == wx.getStorageSync("nickname")  || ''== wx.getStorageSync("nickname")) {
        wx.showToast({
          title: '请设昵称',
          icon:"none",
          mask:"true"//是否设置点击蒙版，防止点击穿透
        })
        return
      }
      var uinfo = wx.getStorageSync("weapp_session_F2C224D4-2BCE-4C64-AF9F-A6D872000D1A");
      uinfo.nickname = wx.getStorageSync("nickname")
      console.log("set weapp_session",uinfo)
      wx.setStorageSync("weapp_session_F2C224D4-2BCE-4C64-AF9F-A6D872000D1A",uinfo)
      this.setData({
          toastCtrol: 0
      });
      this.bindgetuserinfo()
    },


    bindgetuserinfo: function(a) {
      var vstr = 'new';
      wx.getSystemInfo({
        success: function(res) {
          if(res.SDKVersion < '2.27.1'){
            vstr = 'old'
          }
        }
      })
      if(vstr == 'new'){
        var uinfo = wx.getStorageSync("weapp_session_F2C224D4-2BCE-4C64-AF9F-A6D872000D1A");
        console.log(uinfo)
        if(uinfo.nickname == ''){
          this.setData({
              toastCtrol: 13
          });
          return;
        }
      }  
        wx.getUserProfile({
            desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
            success: (res) => {
              if(vstr == 'new'){
                res.userInfo.nickName = wx.getStorageSync("nickname");
                res.userInfo.avatarUrl = wx.getStorageSync("uface");
              }  
                console.log("shezhi hao",res)
                this.data.viewRankGudie && this.closeGuide3(), "getUserProfile:ok" == res.errMsg ? (e.actionTrace({
                        event: "auth_user_info",
                        subEvent: "rank_all_click",
                        op_result: 1,
                        userInfo: res.userInfo
                    }), n.clear(), e.setGlobalData({
                        needAuth: !1,
                        userInfo: res.userInfo
                    }), this.toggleRank()) : (e.actionTrace({
                        event: "auth_user_info",
                        subEvent: "rank_all_click",
                        op_result: 0
                    }), this.showToast("请点击允许，授权头像昵称查看排行榜"));
             
            }
          })
        // 
    },
    bindgetuserinfo2: function(a) {
        e.actionTrace({
            event: "auth_user_info",
            subEvent: "rank_all_click",
            op_result: 1,
            userInfo: a.detail.userInfo
        });
    },
    onShareAppMessage: function(a) {
        if ("menu" === a.from) return this.isShare = !0, {
          title: '这一题你会吗，快来帮帮我！',
          path: "/pages/index/index",
          imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg"
        };

        if (1129 == e.globalData.scene) return this.isShare = !0, {
            title: this.data.seoData.title[e.getRandomIndex(this.data.seoData.title.length)],
            path: "/pages/index/index?source=wxsearch",
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg"
        };
        this.data.isShare = !0, e.globalData.lastPageName = "";
        var t = {
            title: e.globalData.shareResult.top_right_share.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath()
        };
        if ("button" === a.from && "invite" === a.target.dataset.type) return this.data.isInviteShare = !0, 
        e.sourceReport("invite_button_click"), o.clickInvitedBtn(), t = {
            title: e.globalData.shareResult.index_invite_share.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath() + "&inviterId=" + e.globalData.player.userId + "&event=invite_suc"
        }, e.shareTrace({
            sharePath: t.path,
            event: "receive_energy",
            subEvent: "invite_button_click",
            shareCard: e.globalData.shareResult.index_invite_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), console.log(t), t;
        if ("button" === a.from && "word" === a.target.dataset.type) return e.sourceReport("end_idioms_click"), 
        t = {
            title: e.globalData.shareResult.chengyu_share.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath() + "&word=" + this.data.wordExplain.word + "&event=end_idioms_conver"
        }, e.shareTrace({
            sharePath: t.path,
            event: "idiom_detail",
            subEvent: "idiom_detail_click",
            shareCard: e.globalData.shareResult.chengyu_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), console.log(t), t;
        if ("button" === a.from && "not-energy" === a.target.dataset.type) return e.sourceReport("uenergy_share_click"), 
        t = {
            title: e.globalData.shareResult.not_energy.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath() + "&event=uenergy_share_conver&otherId=" + e.globalData.player.userId + "&shareTsp=" + Date.now() + "&bonusType=energy"
        }, this.data.energyTraceData = {
            sharePath: t.path,
            event: "un_energy",
            subEvent: "un_energy_click",
            shareCard: e.globalData.shareResult.not_energy.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }, console.log(t), t;
        if ("button" === a.from && "daily" === a.target.dataset.type) return e.sourceReport("signg_share_suc"), 
        t = {
            title: e.globalData.shareResult.daily_login_share.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath() + "&event=signg_share_conver"
        }, e.globalData.loginTraceData = {
            sharePath: t.path,
            event: "login_reward",
            subEvent: "login_reward_click",
            shareCard: e.globalData.shareResult.daily_login_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }, console.log(t), t;
        if ("button" === a.from && "newUser" === a.target.dataset.type) return this.data.isNewUserShare = !0, 
        o.clickInvitedBtn(), t = {
            title: e.globalData.shareResult.invite_new_user.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath() + "&isNewUser=" + e.globalData.player.userId
        }, e.shareTrace({
            sharePath: t.path,
            event: "invite_new",
            subEvent: "invite_new_click",
            shareCard: e.globalData.shareResult.invite_new_user.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), console.log(t), t;
        console.log('--t----end----------')
        if ("button" === a.from && "showOff" === a.target.dataset.type) return t = {
            title: e.globalData.shareResult.show_off.title,
            imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
            path: e.sharePath()
        }, e.shareTrace({
            sharePath: t.path,
            event: "flaunt_share",
            subEvent: "flaunt_share_click",
            shareCard: e.globalData.shareResult.show_off.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), console.log(t), t;
        if ("button" === a.from && "rank" === a.target.dataset.type) {
            if (0 == this.data.activeRank) return t = {
                title: e.globalData.shareResult.world_rank_share.title.replace("%s", this.data.rankData.rank),
                imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
                path: e.sharePath()
            }, e.shareTrace({
                sharePath: t.path,
                event: "rank_all",
                subEvent: "rank_all_click",
                shareCard: e.globalData.shareResult.world_rank_share.id,
                shareTitle: t.title,
                result: 1,
                gameTime: -1
            }), console.log(t), t;
            if (1 == this.data.activeRank) return t = {
                title: e.globalData.shareResult.location_rank_share.title.replace("%s", this.data.rankData.rank),
                imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
                path: e.sharePath()
            }, e.shareTrace({
                sharePath: t.path,
                event: "rank_area",
                subEvent: "rank_area_click",
                shareCard: e.globalData.shareResult.location_rank_share.id,
                shareTitle: t.title,
                result: 1,
                gameTime: -1
            }), console.log(t), t;
            if (2 == this.data.activeRank) return t = {
                title: e.globalData.shareResult.pass_rank_share.title.replace("%s", this.data.rankData.self.passLevel),
                imageUrl: "https://jwfimg.phph5.cn/20220925211356805384883.jpg",
                path: e.sharePath()
            }, e.shareTrace({
                sharePath: t.path,
                event: "rank_playday",
                subEvent: "rank_playday_click",
                shareCard: e.globalData.shareResult.pass_rank_share.id,
                shareTitle: t.title,
                result: 1,
                gameTime: -1
            }), console.log(t), t;
            console.log('--t----fffffffffffffffff----------')
        }
        return console.log("obj", t), e.shareTrace({
            sharePath: t.path,
            event: "share_menu",
            subEvent: "share_menu_click",
            shareCard: e.globalData.shareResult.top_right_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), console.log(t), t;
    },
    buySuccess: function(a) {
        var t = a.detail;
        this.selectComponent("#navbar") && this.selectComponent("#navbar").getData("noInit");
        var e = t.propType;
        if (2 != e) if (4 != e) {
            var i = !0, o = 5;
            3 == e && (o = 6, i = !1), this.setData({
                isBuyTip: i,
                isShowReward: !0,
                rewardType: o,
                commonGetEnegyPopupValue: t.propValue
            }), this.showMixinBanner();
        } else this.setData({
            isShowReward: !0,
            rewardType: 10
        });
    },
    toggleShop: function() {
        this.setData({
            isShowShop: !this.data.isShowShop
        }), this.data.isShowShop && e.globalData.setting.playAudio("btnClick"), this.data.fromToShop && this.setData({
            fromToShop: !1
        });
    },
    shopShowHandle: function() {
        var a = this;
        wx.getSystemInfo({
            success: function(t) {
                e.globalData.platform = t.platform, "ios" != t.platform && (a.setData({
                    isShowShopEnter: !0
                }), e.setGlobalData({
                    isShowShopEnter: !0
                }));
            }
        });
    },
    toTryGame: function(a) {
        this.data.tryGame = a.detail, this.data.isTryingGame = !0, this.data.tryStart = new Date().getTime();
    },
    tryGameHandle: function() {
        var a = this;
        new Date().getTime() - this.data.tryStart >= 12e3 ? o.gameTryApi(this.data.tryGame.id, 1).then(function(t) {
            0 === t.data.code && (a.selectComponent("#gameTryList").init(), a.showToast("试玩成功，请领取奖励"), 
            e.actionTrace({
                event: "receive_energy",
                subEvent: "try_game_suc"
            }));
        }) : (this.showToast("试玩游戏满1分钟，才可领取能量奖励"), e.actionTrace({
            event: "receive_energy",
            subEvent: "try_game_fail"
        }));
    },
    tryGetSuccess: function(a) {
        e.globalData.setting.playAudio("getEnergy"), this.setData({
            isEnergyTip: !0,
            isShowReward: !0,
            rewardType: 5,
            commonGetEnegyPopupValue: a.detail.bonusValue
        }), this.showMixinBanner(), this.selectComponent("#navbar") && this.selectComponent("#navbar").getData("noInit");
    },
    tryFinish: function() {
        e.log("tryFinish"), this.makeEnergy();
    },
    animationend1: function(a) {
        1 == this.data.animalStep && (this.data.flyMsgIndex < this.data.userList.length - 2 ? this.data.flyMsgIndex += 2 : this.data.flyMsgIndex = 1, 
        this.setData({
            text1: this.data.userList[this.data.flyMsgIndex - 1]
        }));
        var t = 1 == this.data.animalStep ? 2 : 1;
        this.setData({
            animalStep: t
        }), this.animationend2();
    },
    animationend2: function(a) {
        1 == this.data.animalStep && this.setData({
            text2: this.data.userList[this.data.flyMsgIndex]
        });
    },
    flyMsgHandle: function() {
        this.data.userList.length > 1 ? this.setData({
            text1: this.data.userList[this.data.flyMsgIndex - 1],
            text2: this.data.userList[this.data.flyMsgIndex],
            isDetailFinish: !0
        }) : 1 == this.data.userList.length && this.setData({
            text1: this.data.userList[0],
            text2: this.data.userList[0]
        });
    },
    showNewInviteToast: function(a) {
        this.showToast(a.detail);
    },
    toMoreGame: function(a) {
        var t = this;
        console.log("toMoreGame"), e.globalData.setting.playAudio("btnClick");
        var i = a.currentTarget.dataset.item, o = a.currentTarget.dataset.index;
        e.actionTrace({
            event: "image_game_click",
            subEvent: i.gameAppid
        }), wx.navigateToMiniProgram({
            appId: i.gameAppid,
            path: i.gamePath,
            success: function() {
                e.globalData.toOtherGame = !0, e.actionTrace({
                    event: "image_game_out",
                    subEvent: i.gameAppid
                }), t.triggerEvent("toTryGame", i);
                var a = t.data.moveIndex;
                o == a && (a += 1), t.setData({
                    moveIndex: a
                });
            }
        });
    },
    bannerLoad: function() {
        e.actionTrace({
            event: "ad_banner_show",
            subEvent: this.data.shareVideoRule.adv.figureUpgradeBanner
        });
    },
    bannerError: function(a) {
        e.actionTrace({
            event: "ad_banner_fail",
            subEvent: this.data.shareVideoRule.adv.figureUpgradeBanner
        }), console.log("banner err", a), this.setData({
            isShowBanner: !1
        });
    },
    exitGame: function() {
        this.data.isShowDetention && e.actionTrace({
            event: "guide_game_detain",
            subEvent: "guide_detain_quit"
        }), e.actionTrace({
            event: "quit_game",
            subEvent: "quit_game_click"
        }), wx.setStorage({
            key: "isShowExit",
            data: new Date().getDate()
        }), this.setData({
            isShowExit: !1
        }), this.toggleMoreGame();
    },
    getDouble: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
        }), e.globalData.shareVideoRule.adv.doubleEnergyAdv) {
            var i = null;
            (i = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.doubleEnergyAdv
            })).load(), i.offError(), i.onError(function(i) {
                console.log("err", i), o.shareVideoDynamicControl(), t.showToast("今日视频已达上限"), t.setData({
                    isShowReward: !1
                });
                var n = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var s in e.globalData.shareVideoRule) "canWatchVideo" != s && (n[[ "shareVideoRule." + s ]] = 1);
                e.setGlobalData(n);
            }), i.offClose(), i.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
                }), t.doubleSuccess()) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(t.getDouble), 
                e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
                }), t.showToast("请观看完整视频"));
            }), i.show().catch(function(a) {
                i.load().then(function() {
                    i.show();
                });
            }), this.data.videoAd = i;
        } else this.doubleSuccess();
    },
    doubleSuccess: function() {
        var a = this;
        o.doubleGetEnergy(this.data.commonGetEnegyPopupValue).then(function(t) {
            0 === t.data.code && (e.globalData.setting.playAudio("getEnergy"), a.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 9,
                commonGetEnegyPopupValue: a.data.commonGetEnegyPopupValue
            }), a.selectComponent("#navbar") && a.selectComponent("#navbar").getData("noInit"));
        });
    },
    toggleWatchVideo: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowWatchVideo: !this.data.isShowWatchVideo
        });
    },
    clickTreasure: function() {
        this.data.image1 && (this.data.image1 = !1, e.actionTrace({
            event: "image_1",
            subEvent: "image1_box_click"
        })), this.data.image2 && (this.data.image2 = !1, e.actionTrace({
            event: "image_2",
            subEvent: "image2_box_click"
        })), this.toggleMoreGame();
    },
    toggleShareSuccess: function() {
        this.setData({
            isShowShareSuccess: !this.data.isShowShareSuccess
        });
    },
    toggleShareGuide: function() {
        this.setData({
            isShowShareGuide: !this.data.isShowShareGuide
        });
    },
    inviteNewUser: function() {},
    inviteFriend: function() {
        this.setData({
            isShowShareGuide: !0,
            shareGuideType: "invite",
            pageGuideType: 2
        });
    },
    toggleWatchVideoGuide: function() {
        e.setGlobalData({
            isShowWatchVideoGuide: !e.globalData.isShowWatchVideoGuide
        });
    },
    toggleFriendLineFromShare: function() {
        this.setData({
            friendLineType: "1"
        }), this.toggleFriendLine();
    },
    refreshReward: function() {
        console.log("refreshReward"), this.selectComponent("#navbar") && this.selectComponent("#navbar").getData("noInit");
    },

 // 分享到朋友圈
 onShareTimeline: function () {
  return {
    title: '边娱乐边学习，适合宝妈和孩子一起玩的成语接龙游戏，更是上班族的摸鱼神器。一边玩一边学！还能积累许多文化知识!',
    query: 'tommie_duanshiping/pages/index/index',
    imageUrl: '/image/test/1.png'
  }
},

    changeTestTab: function(a) {
        var t = "number" == typeof a ? a : a.currentTarget.dataset.index;
        console.log("index", t), this.data.activityTestTab != t && (this.setData({
            activityTestTab: t
        }), 0 == t || (1 == t ? this.toggleWordBook() : wx.navigateTo({
            url: "/package/pages/weekReport/weekReport"
        })));
    }
});