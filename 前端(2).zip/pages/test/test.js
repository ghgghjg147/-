var t = getApp(), e = require("../../utils/https"), i = require("../../utils/wx");

Page({
    data: {
        siteInfo: require("../../siteinfo.js"),
        level: 1
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        t.globalData.lastPageName = "";
    },
    changeLevel: function(t) {
        var e = t.detail.value.trim();
        this.data.level = e;
    },
    getRecordAuth: function() {
        var t = this;
        i.authorize("scope.record").then(function(e) {
            t.setData({
                needRecordAuth: !1
            });
        }).catch(function(e) {
            console.log("用户取消授权"), t.setData({
                showRecordAuth: !0
            });
        });
    },
    closeRecordAuth: function() {
        this.setData({
            showRecordAuth: !1
        });
    },
    openSettingHandler: function(t) {
        t.detail.authSetting["scope.record"] && this.setData({
            showRecordAuth: !1,
            needRecordAuth: !1
        });
    },
    bindRecordTouchStart: function(t) {
        var e = this;
        if (this.data.needRecordAuth) this.getRecordAuth(); else if (!this.data.ifRecognizing || !this.data.isRecording) {
            if (i.report("recordbtn_click"), this.usingRecorder) return this.setData({
                isRecording: !1
            }), void wx.showToast({
                title: "你的操作太快",
                icon: "none",
                duration: 1500
            });
            this.usingRecorder = !0, this.data.isCancel = !1, this.data.isRecording = !1, i.recorderStart().then(function(t) {
                if (console.log("isCancel", e.data.isCancel), e.data.isCancel) return e.usingRecorder = !1, 
                i.recorderStop(), void (e.data.isCancel = !1);
                e.recordStartT = new Date().getTime(), e.recordTouchY = null, e.data.isRecording = !0, 
                e.setData({
                    isRecording: !0,
                    isCancel: !1,
                    showRecordMsg: !0,
                    showTooShort: !1,
                    ifRecognizing: !1
                });
            }).catch(function(t) {
                e.usingRecorder = !1, i.recorderStop(), console.log("stop2", t);
            });
        }
    },
    recordMsgEnd: function(t) {
        this.data.isRecording || this.setData({
            showRecordMsg: !1
        });
    },
    bindRecordTouchMove: function(t) {
        if (!this.data.ifRecognizing) if (null == this.recordTouchY) this.recordTouchY = t.touches[0].clientY; else {
            var e = t.touches[0].clientY;
            e - this.recordTouchY < -3 ? this.data.isCancel || this.setData({
                isCancel: !0
            }) : e - this.recordTouchY > 3 && this.data.isCancel && this.setData({
                isCancel: !1
            }), this.recordTouchY = e;
        }
    },
    bindRecordTouchEnd: function(t) {
        var e = this;
        this.data.ifRecognizing || (this.data.isRecording ? i.recorderStop().then(function(t) {
            console.log("222", t), e.usingRecorder = !1, e.data.isCancel ? e.setData({
                isRecording: !1
            }) : (e.recordEndT = new Date().getTime(), e.recordEndT - e.recordStartT < 600 ? (e.setData({
                showTooShort: !0,
                isRecording: !1,
                keepShow: !0
            }), setTimeout(function() {
                e.setData({
                    keepShow: !1
                });
            }, 1500)) : (e.setData({
                ifRecognizing: !0
            }), e.recognize(t.tempFilePath), e.setData({
                isRecording: !1
            }))), e.data.isCancel = !1;
        }).catch(function(t) {
            console.log("111", t), e.usingRecorder = !1, e.setData({
                isRecording: !1
            });
        }) : (this.data.isCancel = !0, this.setData({
            isRecording: !1
        })));
    },
    recognize: function(t) {
        e.recognize(this.data.level, t).then(function(t) {
            console.log("识别完成", t);
        });
    },
    recordSuccessHandle: function() {
        var t = this;
        this.data.ansIndex || 0 == this.data.ansIndex ? this.data.ansIndex += 1 : this.data.ansIndex = 0;
        var e = this.data.ansIndex, i = this.data.answerList[e];
        if (-1 == this.data.hadSuccessList.indexOf(i)) {
            this.data.hadSuccessList.push(i);
            for (var a = this.data.anserWordList[i], s = 0; s < a.length; s++) !function(e) {
                var i = a[e], s = t.data.gameBoxList[i.y][i.x];
                if (s.ans && s.canSelect && !s.isSuccess) {
                    s.text = s.ans;
                    var o = t.data.selectList.filter(function(t) {
                        return t.text === s.ans;
                    });
                    console.log("selectItemList", o);
                    var n = void 0, c = !0, r = !1, d = void 0;
                    try {
                        for (var h, l = o[Symbol.iterator](); !(c = (h = l.next()).done); c = !0) {
                            var u = h.value;
                            if (!u.isSelected) {
                                n = u;
                                break;
                            }
                            u.isSuccess || (n = u);
                        }
                    } catch (t) {
                        r = !0, d = t;
                    } finally {
                        try {
                            !c && l.return && l.return();
                        } finally {
                            if (r) throw d;
                        }
                    }
                    var f = t.data.selectList.indexOf(n);
                    if (console.log("selectItem", t.data.selectList, n, n.isSelected, f), n.isSelected) {
                        var g = !0, R = !1, v = void 0;
                        try {
                            for (var S, x = t.data.gameBoxList[Symbol.iterator](); !(g = (S = x.next()).done); g = !0) {
                                var w = S.value, m = !0, D = !1, L = void 0;
                                try {
                                    for (var T, I = w[Symbol.iterator](); !(m = (T = I.next()).done); m = !0) {
                                        var p = T.value;
                                        if (p.wordIndex === f && !p.isSuccess && p.canSelect) {
                                            p.text = "", p.isFail = !1, p.wordIndex = -1;
                                            break;
                                        }
                                    }
                                } catch (t) {
                                    D = !0, L = t;
                                } finally {
                                    try {
                                        !m && I.return && I.return();
                                    } finally {
                                        if (D) throw L;
                                    }
                                }
                            }
                        } catch (t) {
                            R = !0, v = t;
                        } finally {
                            try {
                                !g && x.return && x.return();
                            } finally {
                                if (R) throw v;
                            }
                        }
                    }
                    n && (n.isSelected = !0), s.wordIndex > -1 && !s.isSuccess && s.canSelect && !t.data.selectList[s.wordIndex].isSuccess && (console.log("boxItem", s), 
                    t.data.selectList[s.wordIndex].isSelected = !1, s.wordIndex = -1), s.wordIndex = f;
                }
                s.isSuccess = !0, s.wordIndex && (t.data.selectList[s.wordIndex].isSuccess = !0), 
                s.animate = e;
            }(s);
            this.data.successNum += 1, this.searchActive(), this.getBoxClass(), this.setData({
                selectList: this.data.selectList,
                gameBoxList: this.data.gameBoxList
            }), this.data.successNum === this.data.answerList.length && this.finishGame();
        }
    }
});