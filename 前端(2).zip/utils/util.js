var t = function(t) {
    return (t = t.toString())[1] ? t : "0" + t;
};

module.exports = {
    formatTime: function(n) {
        var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/", e = (n = new Date(n)).getFullYear(), o = n.getMonth() + 1, a = n.getDate(), u = n.getHours(), i = n.getMinutes(), d = n.getSeconds();
        return [ e, o, a ].map(t).join(r) + " " + [ u, i, d ].map(t).join(":");
    },
    randomWord: function(t, n, r) {
        var e = "", o = n, a = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" ];
        t && (o = Math.round(Math.random() * (r - n)) + n);
        for (var u = 0; u < o; u++) e += a[Math.round(Math.random() * (a.length - 1))];
        return e;
    }
};