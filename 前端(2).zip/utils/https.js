function e(e, t, n) {
    var i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], l = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
    return -1 != t.indexOf("?") ? t += "&ver=" + u.service.version : t += "?ver=" + u.service.version, 
    new Promise(function(u, a) {
        r.request({
            url: t,
            method: e,
            data: n,
            header: l,
            success: function(e) {
                u(e);
            },
            fail: function(e) {
                a(e);
            },
            login: i
        });
    });
}

var r = require("../vendor/qcloud-weapp-client-sdk/index.js"), t = require("../vendor/qcloud-weapp-client-sdk/lib/session"), u = require("../config"), n = (u.service.hostUrl, 
require("../utils/md5.js")), i = "", l = "", a = u;

wx.getSystemInfo({
    success: function(e) {
        console.log("getSystemInfo", e), i = e.platform, l = e.version;
    }
}), module.exports = {
    hotWord: function() {
        var r = {
            ver: u.service.version
        };
        return e("GET", u.util.request_url({
            url: "entry/wxapp/hotWord"
        }), r, !0);
    },
    gameLevel: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/gameLevel"
        }), {}, !1);
    },
    activityDetail: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/detail"
        }), {}, !1);
    },
    getShareResult: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getShareResult"
        }), {}, !1);
    },
    uploadFormId: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/uploadFormId"
        }), {
            formId: r,
            userId: t
        }, !1);
    },
    previewLevel: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/previewLevel"
        }), {}, !1);
    },
    figureConfig: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/figureConfig"
        }), {}, !0);
    },
    getEnergy: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getEnergy"
        }), {}, !0);
    },
    player: function() {
        var r = {
            ver: u.service.version
        };
        return e("GET", u.util.request_url({
            url: "entry/wxapp/player"
        }), r, !0);
    },
    pass: function(r, t) {
        var i = String(Date.now()), l = n.hexMD5(r + i + "mandiankan");
        return e("GET", u.util.request_url({
            url: "entry/wxapp/pass"
        }), {
            level: r,
            gameTime: t,
            timestamp: i,
            sign: l
        }, !0);
    },
    inviteFriendList: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/inviteFriendListV2"
        }), {}, !0);
    },
    getEnergyByInvite: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getEnergyByInvite"
        }), {
            inviterId: r
        }, !0);
    },
    getAllEnergyByInvite: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getAllEnergyByInvite"
        }), {}, !0);
    },
    inviteFriend: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/inviteFriend"
        }), {
            inviterId: r
        }, !0);
    },
    inviteNewUser: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/inviteNewUser"
        }), {
            inviterId: r
        }, !0);
    },
    getAllNewUserInviteEnergy: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getAllNewUserInviteEnergy"
        }), {}, !0);
    },
    ranking: function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        return e("GET", u.util.request_url({
            url: "entry/wxapp/ranking"
        }), {
            type: r,
            date: t
        }, !0);
    },
    explanation: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/explanation"
        }), {
            word: r
        }, !1);
    },
    upgrade: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/upgrade"
        }), {
            type: r
        }, !1);
    },
    shareAddEnergyStrategy: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/shareAddEnergyStrategy"
        }), {}, !1);
    },
    shareAddEnergy: function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        return e("GET", u.util.request_url({
            url: "entry/wxapp/shareAddEnergy"
        }), {
            getType: r
        }, !1);
    },
    makeEnergy: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/makeEnergy"
        }), {
            wxVer: l,
            platform: i
        }, !1);
    },
    tipNumber: function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "select";
        return e("GET", u.util.request_url({
            url: "entry/wxapp/tipNumber"
        }), {
            operation: r
        }, !1);
    },
    shareVideoRule: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/shareVideoRule"
        }), {
            scene: r
        }, !1);
    },
    getVocab: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getVocab"
        }), {}, !1);
    },
    addVocab: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/addVocab"
        }), {
            idiomId: r
        }, !1);
    },
    dropVocab: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/dropVocab"
        }), {
            idiomId: r
        }, !1);
    },
    doCollectGame: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/CollectGame"
        }), {
            collectType: r
        }, !1);
    },
    addFloatWindow: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/addFloatWindow"
        }), {
            floatType: r
        }, !1);
    },
    getDailyLoginAward: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/DailyLoginAward"
        }), {}, !1);
    },
    makeEnergyWatchVideo: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/makeEnergyWatchVideo"
        }), {}, !1);
    },
    shareVideoDynamicControl: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/shareVideoDynamicControl"
        }), {}, !1);
    },
    addShareVideoTimes: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/addShareVideoTimes"
        }), {
            position: r
        }, !1);
    },
    uimage: function(r) {
      return new Promise(function(u, n) {
          wx.uploadFile({
              url: a.util.request_url({
                  url: "entry/wxapp/uimage"
              }),
              filePath: r,
              name: "upfile",
              header: {
                  "X-WX-Id": t.get().id,
                  "X-WX-Skey": t.get().skey
              },
              formData: {},
              success: function(e) {
                  console.log("upload s", e), u(e);
              },
              fail: function(e) {
                  
              },
              complete: function() {
                
              }
          })
      });
    },

    recognize: function(e, r) {
        return new Promise(function(u, n) {
            var i = {
                level: e
            }, l = !1;
            wx.uploadFile({
                url: a.util.request_url({
                    url: "entry/wxapp/recognize"
                }),
                filePath: r,
                name: "file",
                header: {
                    "X-WX-Id": t.get().id,
                    "X-WX-Skey": t.get().skey
                },
                formData: i,
                success: function(e) {
                    console.log("upload s", e, t.get().id, t.get().skey), u(e);
                },
                fail: function(e) {
                    console.log("upload f", res), n(e);
                },
                complete: function() {
                    l = !0;
                }
            }), setTimeout(function() {
                l || n();
            }, 3e3);
        });
    },
    guideList: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/guideList"
        }), {}, !1);
    },
    addGuide: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/addGuide"
        }), {
            guidePosition: r
        }, !1);
    },
    getScholarData: function(r, t) {
        var u = {};
        return r && (u.weekDate = r), t && (u.userId = t), e("GET", a.util.request_url({
            url: "entry/wxapp/getScholarData"
        }), u, !1);
    },
    getEnergyByGiveLike: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getEnergyByGiveLike"
        }), {
            giveLikeWeek: r,
            otherId: t
        }, !1);
    },
    giveLikeForScholar: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/GiveLikeForScholar"
        }), {
            giveLikeWeek: r,
            otherId: t
        }, !1);
    },
    LightUpTheMedal: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/LightUpTheMedal"
        }), {
            medalName: r
        }, !1);
    },
    scholarMedalList: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/scholarMedalList"
        }), {}, !1);
    },
    participate: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/participate"
        }), {
            position: r
        }, !1);
    },
    activityReward: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/reward"
        }), {
            activityId: r
        }, !1);
    },
    propStore: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/propStore"
        }), {}, !1);
    },
    prepay: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/prepay"
        }), {
            propId: r,
            platform: i
        }, !1);
    },
    getPrepayStatus: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getPrepayStatus"
        }), {
            prepayNo: r,
            n: t
        }, !1);
    },
    getWebPrepay: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getWebPrepay"
        }), {
            n: r
        }, !1);
    },
    sourceReport: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/sourceReport"
        }), !1);
    },
    trace: function(r) {
        return e("POST", u.util.request_url({
            url: "entry/wxapp/trace"
        }), r, !0);
    },
    finishPageImg: function(r) {
        return e("POST", u.util.request_url({
            url: "entry/wxapp/finishPageImg"
        }), {
            boxList: r
        }, !0);
    },
    tableScreenStrategy: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/tableScreenStrategy2"
        }), {}, !1);
    },
    subEnergyNotify: function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
        return e("GET", u.util.request_url({
            url: "entry/wxapp/subEnergyNotify"
        }), {
            subSwitch: r
        }, !1);
    },
    getSubEnergyNotify: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/getSubEnergyNotify"
        }), {}, !1);
    },
    moreGame: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/moreGame"
        }), {}, !1);
    },
    gameTryApi: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/gameTryApi"
        }), {
            gameId: r,
            getStatus: t
        }, !1);
    },
    sharePyq: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/sharePyq"
        }), {
            sharePyqType: r
        }, !1);
    },
    invShareRandomTxt: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/invShareRandomTxt"
        }), {}, !1);
    },
    abandonDailyLoginAward: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/abandonDailyLoginAward"
        }), {}, !1);
    },
    randomBanner: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/randomBanner"
        }), {}, !1);
    },
    popWindowTimes: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/popWindowTimes"
        }), {}, !1);
    },
    yearCardUserSign: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/yearCardUserSign"
        }), {}, !1);
    },
    clickInvitedBtn: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/clickInvitedBtn"
        }), {}, !1);
    },
    aldConfig: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/aldConfig"
        }), {}, !0);
    },
    popDiscountEvent: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/popDiscountEvent"
        }), {}, !1);
    },
    doubleGetEnergy: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/doubleGetEnergy"
        }), {
            value: r
        }, !1);
    },
    clickAddTips: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/clickAddTips"
        }), {
            otherId: r,
            shareTsp: t
        }, !1);
    },
    gamePageShareRealPop: function() {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/gamePageShareRealPop"
        }), {}, !1);
    },
    finishPageInfo: function(r) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/finishPageInfo"
        }), {
            operation: r
        }, !1);
    },
    gamePageShareClick: function(r, t, u) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/gamePageShareClick"
        }), {
            otherId: r,
            shareTsp: t,
            bonusType: u
        }, !1);
    },
    getSeoData: function(r, t) {
        var u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1129;
        return e("GET", a.util.request_url({
            url: "entry/wxapp/seodata"
        }), {
            path: r,
            option: t,
            scene: u
        }, !1);
    },
    suppleMpReward: function(r, t) {
        return e("GET", u.util.request_url({
            url: "entry/wxapp/suppleMpReward"
        }), {
            scene: r,
            sessionFrom: t,
            appId: "wxd4c69125afec545e"
        }, !0);
    }
};