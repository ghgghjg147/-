function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

var n, o, t = Object.assign || function(e) {
    for (var n = 1; n < arguments.length; n++) {
        var o = arguments[n];
        for (var t in o) Object.prototype.hasOwnProperty.call(o, t) && (e[t] = o[t]);
    }
    return e;
}, r = function() {
    function e(e, n) {
        for (var o = 0; o < n.length; o++) {
            var t = n[o];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(n, o, t) {
        return o && e(n.prototype, o), t && e(n, t), n;
    };
}(), i = (require("../config.js"), function() {
    function i() {
        e(this, i), this.audioContext = null, this.stopCallBack = null, this.record = wx.getRecorderManager();
    }
    return r(i, [ {
        key: "authorize",
        value: function(e) {
            return new Promise(function(n, o) {
                wx.authorize({
                    scope: e,
                    success: function() {
                        n(!0);
                    },
                    fail: function(e) {
                        o(e);
                    }
                });
            });
        }
    }, {
        key: "openSetting",
        value: function() {
            return new Promise(function(e, n) {
                wx.openSetting({
                    success: function() {
                        e();
                    },
                    fail: function() {
                        n();
                    }
                });
            });
        }
    }, {
        key: "getSetting",
        value: function(e) {
            return new Promise(function(n, o) {
                wx.getSetting({
                    success: function(t) {
                        console.log(t), t.errMsg.match(/ok/g) ? e ? t.authSetting[e] ? n() : o() : n(t.authSetting) : o();
                    },
                    fail: function(e) {
                        console.log(e), o(e);
                    }
                });
            });
        }
    }, {
        key: "saveFile",
        value: function(e) {
            return new Promise(function(n, o) {
                wx.saveFile({
                    tempFilePath: e,
                    success: function(e) {
                        e.errMsg.match(/ok/) && n(e.savedFilePath);
                    },
                    fail: function(e) {
                        console.log(e), o(e);
                    }
                });
            });
        }
    }, {
        key: "startRecord",
        value: function() {
            return new Promise(function(e, n) {
                wx.startRecord({
                    success: function(o) {
                        o.errMsg.match(/ok/) ? e(o.tempFilePath) : n();
                    },
                    fail: function() {
                        n();
                    }
                });
            });
        }
    }, {
        key: "uploadFile",
        value: function(e) {
            return new Promise(function(n, o) {
                wx.uploadFile(t({}, e, {
                    success: function(e) {
                        n(e);
                    },
                    fail: function() {
                        o();
                    }
                }));
            });
        }
    }, {
        key: "downloadFile",
        value: function(e) {
            return new Promise(function(n, r) {
                o = wx.downloadFile(t({}, e, {
                    success: function(e) {
                        200 === e.statusCode ? n(e) : r();
                    },
                    fail: function(e) {
                        r(e);
                    }
                }));
            });
        }
    }, {
        key: "playVoice",
        value: function(e) {
            var n = this, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            return this.audioContext, this.audioContext = wx.createInnerAudioContext(), "function" == typeof wx.setInnerAudioOption && wx.setInnerAudioOption({
                obeyMuteSwitch: !1,
                mixWithOther: !0
            }), o && (this.stopCallBack = o), this.audioContext, new Promise(function(t, r) {
                try {
                    n.audioContext.src = e, n.audioContext.play();
                } catch (e) {
                    console.log(e), r();
                }
                n.audioContext.onPlay(function(e) {}), n.audioContext.onStop(function(e) {
                    console.log("e停止播放", e), o && o();
                }), n.audioContext.onEnded(function(e) {
                    t();
                }), n.audioContext.onError(function(e) {
                    console.log(e), r();
                });
            });
        }
    }, {
        key: "recorderOnStart",
        value: function(e) {
            e.onStart(function() {
                console.log("recorder start");
            });
        }
    }, {
        key: "recorderStart",
        value: function() {
            var e = this, n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            return arguments.length > 1 && void 0 !== arguments[1] && arguments[1], console.log("**recordStart"), 
            new Promise(function(o, t) {
                var r = {
                    sampleRate: 16e3,
                    numberOfChannels: 1,
                    format: "mp3"
                };
                n && (r.encodeBitRate = 128e3), e.record.start({
                    sampleRate: 16e3,
                    numberOfChannels: 1,
                    format: "mp3"
                }), e.record.onInterruptionBegin(function() {
                    console.log("录音中断了");
                }), e.record.onPause(function() {
                    console.log("录音暂停了");
                }), e.record.onStart(function(e) {
                    o({
                        code: 1001,
                        msg: "start Recorde"
                    });
                }), e.record.onError(function(e) {
                    t({
                        code: 500,
                        msg: e
                    });
                });
            });
        }
    }, {
        key: "recorderStop",
        value: function() {
            var e = this;
            return console.log("**recordStop"), new Promise(function(n, o) {
                var t = void 0, r = void 0;
                e.record.onStop(function(e) {
                    r = e.tempFilePath, t = e.duration, n({
                        tempFilePath: r,
                        duration: t
                    });
                }), e.record.stop();
            });
        }
    }, {
        key: "onPlayVoice",
        value: function(e) {
            "function" == typeof e && (n = e);
        }
    }, {
        key: "stopVoice",
        value: function() {
            null != this.audioContext && this.audioContext.stop();
        }
    }, {
        key: "measureBox",
        value: function(e, n) {
            return new Promise(function(o, t) {
                var r = wx.createSelectorQuery().in(n);
                r.select(e).fields({
                    dataset: !0,
                    size: !0,
                    scrollOffset: !0,
                    properties: [ "scrollX", "scrollY" ],
                    computedStyle: [ "margin", "backgroundColor" ],
                    context: !0
                }, function(e) {
                    o(e);
                }), r.exec();
            });
        }
    }, {
        key: "report",
        value: function(e) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            console.log("report", e, n), wx.reportAnalytics(e, n);
        }
    } ]), i;
}());

module.exports = new i();