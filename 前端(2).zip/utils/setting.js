var t = wx.createInnerAudioContext(), i = {}, e = "";

t.loop = !0;

var o = require("../siteinfo.js").siteroot.split("/"), n = o[0] + "//" + o[2] + "/addons/yf_chengyujiekong/resource", s = [], a = 0, r = {
    btnClick: n + "/mp3/btnClick.mp3",
    changeBox: n + "/mp3/changeBox.mp3",
    correct: n + "/mp3/correct.mp3",
    finish: n + "/mp3/finish.mp3",
    incorrect: n + "/mp3/incorrect.mp3",
    selectWord: n + "/mp3/selectWord.mp3",
    gameTip: n + "/mp3/gameTip.mp3",
    getEnergy: n + "/mp3/getEnergy.mp3",
    levelUp: n + "/mp3/levelUp.mp3",
    getBox: n + "/mp3/getBox.mp3"
}, l = {
    isPlayBgm: !0,
    isPlayAudio: !0,
    isShake: !0
}, g = {
    audioInit: function() {
        for (var t = 0; t < 10; t++) {
            var i = wx.createInnerAudioContext();
            s.push(i);
        }
        wx.setInnerAudioOption({
            obeyMuteSwitch: !1
        });
    },
    playBgm: function(o) {
        e = o ? i[o] : i.normal, l.isPlayBgm && (t.src = e, t.play());
    },
    stopBgm: function() {
        t.stop();
    },
    playAudio: function(t) {
        var i = r[t];
        if (console.log("type", t, l.isPlayAudio, i), l.isPlayAudio && i) {
            var e = s[a];
            e.src = i, e.play(), a < 9 ? a += 1 : a = 0;
        }
    },
    stopAudio: function() {
        var t = !0, i = !1, e = void 0;
        try {
            for (var o, n = s[Symbol.iterator](); !(t = (o = n.next()).done); t = !0) o.value.stop();
        } catch (t) {
            i = !0, e = t;
        } finally {
            try {
                !t && n.return && n.return();
            } finally {
                if (i) throw e;
            }
        }
    },
    shortShake: function() {
        l.isShake && wx.vibrateShort();
    },
    longShake: function() {
        l.isShake && wx.vibrateLong();
    },
    switchBgm: function() {
        return l.isPlayBgm = !l.isPlayBgm, l.isPlayBgm ? this.playBgm() : this.stopBgm(), 
        console.log("settingOption.isPlayBgm", l.isPlayBgm), this.saveSetting(), l;
    },
    switchAudio: function() {
        return l.isPlayAudio = !l.isPlayAudio, console.log("settingOption.isPlayAudio", l.isPlayAudio), 
        l.isPlayAudio || this.stopAudio(), this.saveSetting(), l;
    },
    switchShake: function() {
        return l.isShake = !l.isShake, console.log("settingOption.isShake", l.isShake), 
        this.saveSetting(), l;
    },
    getSetting: function() {
        return l;
    },
    saveSetting: function() {
        wx.setStorage({
            key: "settingOption",
            data: l
        });
    },
    initSetting: function() {
        var t = wx.getStorageSync("settingOption");
        t && (l = t);
    }
};

g.initSetting(), g.audioInit(), module.exports = g;