var i = {
    uniacid: "26",
    acid: "26",
    multiid: "0",
    version: "1.0",
  siteroot: "https://chengyu.asia3.asia/app/index.php",
    design_method: "3"
};

module.exports = i;