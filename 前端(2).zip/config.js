var e = require("siteinfo.js").siteroot.split("/")[2], t = require("we7/resource/js/util.js"), r = {
    util: t,
    service: {
        host: e,
        hostUrl: "https://" + e + "/scholar/api",
        unionLoginUrl: t.request_url({
            url: "entry/wxapp/unionLogin"
        }),
        loginUrl: t.request_url({
            url: "entry/wxapp/login"
        }),
        requestUrl: "https://" + e + "/scholar/api/user",
        tunnelUrl: "https://" + e + "/scholar/api/tunnel",
        uploadUrl: "https://" + e + "/scholar/api/upload",
        avatarUrl: "http://" + e + "/scholar/static/images/avatar/0.png",
        originalId: "gh_9f8c0e157404",
        reportSourceUrl: "https://" + e + "/api/mina_source/report",
        version: "1.3.6"
    },
    /**
 * 本破解程 序由猫 咪 源码提供
 * maomi 源码商城maomiyuanma.com 免费下载QQ:1931864511
 *  承接PHP 二次开发 指定模块破解
 */

    pixelRate: .5,
    platform: "ios",
    capsuleHeight: 44,
    statusBarHeight: 20,
    titleHeight: 136,
    systemHeight: 0,
    isAllScreen: !1,
    isHighHead: !1,
    model: "iPhone 5",
    sampleRate: 44100,
    encodeBitRate: 64e3
};

module.exports = r;