function a(a, t, e) {
    return t in a ? Object.defineProperty(a, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[t] = e, a;
}

// require("./utils/ald-stat.js");

var t = require("./utils/ald-stat-conf.js"), e = require("./vendor/qcloud-weapp-client-sdk/index"), i = require("./vendor/qcloud-weapp-client-sdk/lib/session"), o = require("./config"), s = require("./utils/md5.js"), l = require("./utils/https"), r = 0, n = require("./utils/setting.js");

require("./utils/wx");

var h = require("we7/resource/js/util.js"), g = require("siteinfo.js");

App({
    bannerType: 1,
    gameLevel: {},
    pageList: {},
    player: {},
    energyData: {},
    globalData: {
        isShowGetReward: !1,
        isShowWatchVideoGuide: !1,
        isShowTreasure: !1,
        lostTimer: [],
        mode: 0,
        ack: 0,
        traceLevel: 1,
        oid: -1,
        scene: 0,
        rid: -1,
        source: "",
        traceList: [],
        extraData: "",
        needAuth: !0,
        userInfo: null,
        bannerAD: "",
        videoAD: "",
        setting: "",
        energyTotal: "",
        traceEnergyTotal: "",
        shareGetEnergy: {},
        toShare: 0,
        shareVideoRule: {},
        guideList: {},
        wanyuanActivityTip: !1,
        showWanyuanActivity: !1,
        remainLevelGetZikuai: 0,
        gameStartTime: 0,
        moreGameList: [],
        moreGameIndex: 0
    },
    baseUrl: function() {
        var a = g.siteroot.split("/");
        return a[0] + "//" + a[2];
    },
    util: h,
    userInfo: {
        sessionid: null
    },
    siteInfo: require("siteinfo.js"),
    watchList: [ "needAuth", "userInfo", "bannerAD", "videoAD", "setting", "energyTotal", "shareGetEnergy", "toShare", "shareVideoRule", "wanyuanActivityTip", "showWanyuanActivity", "remainLevelGetZikuai", "moreGameList", "isShowTreasure", "isShowWatchVideoGuide", "isShowGetReward", "getRewardList" ],
    watchCallBack: {},
    watchingKeys: [],
    setWatch: function(a, t, e) {
        var i = this;
        this.log("source1", e), this.pageList[e] = a;
        var o = {};
        for (var s in this.globalData) {
            var l = this.globalData[s];
            void 0 != l && (o[s] = l);
        }
        this.pageList[e].setData(o);
        var r = !0, n = !1, h = void 0;
        try {
            for (var g, c = this.watchList[Symbol.iterator](); !(r = (g = c.next()).done); r = !0) !function() {
                var a = g.value;
                i.$watch(a, e, function(t, o) {
                    i.log("key, val, old", a, t, o);
                    var s = {};
                    s[a] = t, i.pageList[e].setData(s), i.log("source2", e, i.pageList[e].data);
                });
            }();
        } catch (a) {
            n = !0, h = a;
        } finally {
            try {
                !r && c.return && c.return();
            } finally {
                if (n) throw h;
            }
        }
        t && t();
    },
    setGlobalData: function(a) {
        var t = this;
        Object.keys(a).map(function(e) {
            if (t.log("mutation1", a), e.indexOf(".") > -1) {
                for (var i = t.globalData, o = e.split("."), s = o[o.length - 1], l = 0; l < o.length - 1; l++) i = i[o[l]];
                i[s] = a[e];
            } else t.globalData[e] = a[e];
            t.log("mutation2", t.globalData, t.globalData.traceEnergyTotal);
        });
    },
    $watch: function(t, e, i) {
        if (this.watchCallBack = Object.assign({}, this.watchCallBack, a({}, t, this.watchCallBack[t] || {})), 
        this.watchCallBack[t][e] = i, !this.watchingKeys.find(function(a) {
            return a === t;
        })) {
            var o = this;
            this.watchingKeys.push(t);
            var s = this.globalData[t];
            Object.defineProperty(this.globalData, t, {
                configurable: !0,
                enumerable: !0,
                set: function(a) {
                    var e = o.globalData[t];
                    s = a;
                    for (var i in o.watchCallBack[t]) o.watchCallBack[t][i](a, e);
                },
                get: function() {
                    return s;
                }
            });
        }
    },
    inviteFriend: function(a) {
        l.inviteFriend(a).then(function(a) {});
    },
    inviteNewFriend: function(a) {
        l.inviteNewUser(a).then(function(a) {});
    },
    shareVideoRule: function(a) {
        var t = this;
        l.shareVideoRule(this.globalData.scene).then(function(e) {
            0 === e.data.code && (t.setGlobalData({
                shareVideoRule: e.data.data
            }), a && a(t.globalData.shareVideoRule));
        });
    },
    setNavBarConfig: function() {
        if (!(++r >= 100)) try {
            var a = wx.getSystemInfoSync();
            if (this.globalData.SDKVersion = a.SDKVersion, !a) return this.log("getConfig Fail"), 
            void this.setNavBarConfig();
            if (a.screenHeight <= 0 || a.screenWidth <= 0 || a.windowHeight <= 0 || a.windowWidth <= 0) return this.log("getConfig Fail"), 
            void this.setNavBarConfig();
            this.log("system res", a), o.windowWidth = a.windowWidth, o.model = a.model, o.pixelRate = a.windowWidth / 750, 
            o.platform = a.platform, o.statusBarHeight = a.statusBarHeight, "android" == a.platform.toLowerCase() && (o.capsuleHeight += 4), 
            o.titleHeight = (o.capsuleHeight + o.statusBarHeight) / o.pixelRate, a.statusBarHeight >= 44 && (o.isHighHead = !0), 
            a.windowHeight > 750 && (o.isAllScreen = !0), o.systemHeight = a.windowHeight, this.globalData.navHeight = (o.statusBarHeight + o.capsuleHeight) / o.pixelRate;
        } catch (a) {
            this.log(a);
        }
    },
    getRandomArrayElements: function(a, t) {
        for (var e = []; e.length < t; ) {
            var i = a[this.getRandomInt(0, a.length)];
            i && -1 == e.indexOf(i) && e.push(i);
        }
        return e;
    },
    getRandomInt: function(a, t) {
        return a = Math.ceil(a), t = Math.floor(t), Math.floor(Math.random() * (t - a + 1)) + a;
    },
    optionsHandle: function(a, t) {
        var e = this;
        if (this.globalData.options = a, this.log("optionsHandle", a), a && a.query) {
            a.query.inviterId && this.inviteFriend(a.query.inviterId), a.query.isNewUser && this.inviteNewFriend(a.query.isNewUser), 
            this.globalData.extraData = JSON.stringify(a.query), this.globalData.event = a.query.event ? a.query.event : "", 
            this.globalData.subEvent = a.query.subEvent ? a.query.subEvent : "", this.globalData.subId = a.query.shareNo ? a.query.shareNo : this.globalData.subId ? this.globalData.subId : "", 
            this.globalData.timestamp = a.query.timestamp ? a.query.timestamp : "", this.globalData.ald_media_id = a.query.ald_media_id ? Number(a.query.ald_media_id) : "";
            var i = a.query.source ? a.query.source : "", o = a.scene, s = a.query.rid ? a.query.rid : -1, l = a.query.oid ? a.query.oid : -1, r = a.query.traceLevel ? a.query.traceLevel : 1;
            this.globalData.player && this.globalData.player && -1 != s && this.globalData.player.userId != s && (r = Number(r) + 1), 
            this.globalData.player && this.globalData.player.userId == l && (r = 1), i == this.globalData.source && this.globalData.rid == s && this.globalData.oid == l && this.globalData.scene == o && r == this.globalData.traceLevel || (0 === this.globalData.traceList.length ? this.globalData.ack = 0 : this.trace()), 
            this.globalData.source = i || (this.globalData.source ? this.globalData.source : ""), 
            this.globalData.scene = o || (this.globalData.scene ? this.globalData.scene : ""), 
            this.globalData.rid = -1 != s ? s : this.globalData.rid ? this.globalData.rid : -1, 
            this.globalData.oid = -1 != l ? l : this.globalData.oid ? this.globalData.oid : -1, 
            this.globalData.traceLevel = 1 != r ? r : this.globalData.traceLevel ? this.globalData.traceLevel : 1, 
            1044 != this.globalData.scene || this.globalData.shareTicket == a.shareTicket && this.globalData.shareTicket || (this.globalData.shareTicket = a.shareTicket, 
            wx.getShareInfo({
                shareTicket: a.shareTicket,
                success: function(a) {
                    e.globalData.groupData = a;
                }
            }));
        }
    },
    getSystem: function() {
        var a = this;
        wx.getSystemInfo({
            success: function(t) {
                "devtools" == t.platform ? a.globalData.system = "android" : "ios" == t.platform ? a.globalData.system = "ios" : "android" == t.platform && (a.globalData.system = "android");
            }
        });
    },
    sourceReport: function(a) {},
    onLaunch: function(a) {
        var s = this;
        if (1129 == a.scene) {
            this.globalData.scene = 1129;
            var l = {
                id: "00000000000000000000000000000000",
                skey: "11111111111111111111111111111111"
            };
            i.set(l);
        }
        wx.removeStorageSync("aldstat_op"), console.log("aldConf", t), this.checkUpdateVersion();
        var r = wx.getStorageSync("player");
        r && (this.globalData.player = r), console.log("app.onLaunch", a);
        var h = o.service.loginUrl, g = o.service.unionLoginUrl;
        h = h + "&source=" + (this.globalData.source || "") + "&scene=" + this.globalData.scene + "&rid=" + this.globalData.rid, 
        g = g + "&source=" + (this.globalData.source || "") + "&scene=" + this.globalData.scene + "&rid=" + this.globalData.rid, 
        e.setLoginUrl(h), e.setUnionLogin(g), this.globalData.appTimeStart = new Date().getTime(), 
        this.optionsHandle(a, !0), this.log("options4", a), this.getSystem(), this.globalData.setting = n, 
        this.setNavBarConfig(), wx.getSetting({
            success: function(a) {
                s.log(a), a.authSetting["scope.userInfo"] ? (s.setGlobalData({
                    needAuth: !1
                }), s.globalData.userInfo || wx.getUserInfo({
                    success: function(a) {
                        s.setGlobalData({
                            userInfo: a.userInfo
                        });
                    }
                })) : s.setGlobalData({
                    needAuth: !0
                });
            }
        }), this.loginTrace("app_launch", a.query), this.aldConfig(), this.gamePageShareRealPop();
    },
    appOnshow: function() {
        this.globalData.isFirstOnShow || (this.globalData.isFirstOnShow = !0, this.actionTrace({
            event: "app_show",
            subEvent: ""
        }));
    },
    onShow: function(a) {
        var t = this;
        console.log("app.onShow", a);
        var i = o.service.loginUrl, s = o.service.unionLoginUrl;
        i = i + "?source=" + (this.globalData.source || "") + "&scene=" + this.globalData.scene + "&rid=" + this.globalData.rid, 
        s = s + "?source=" + (this.globalData.source || "") + "&scene=" + this.globalData.scene + "&rid=" + this.globalData.rid, 
        e.setLoginUrl(i), e.setUnionLogin(s), this.optionsHandle(a), this.log("options1", a), 
        a.scene && (this.globalData.scene = a.scene), wx.getSetting({
            success: function(a) {
                a.authSetting["scope.userInfo"] ? t.setGlobalData({
                    needAuth: !1
                }) : t.setGlobalData({
                    needAuth: !0
                });
            }
        });
    },
    pxTransformer: function(a) {
        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? a / o.pixelRate : Math.floor(a * o.pixelRate);
    },
    log: function() {},
    sharePath: function(a) {
        var t = new Date().getTime();
        return this.globalData.shareNo = t + "" + this.globalData.player.userId, (a || "/pages/index/index") + "?rid=" + this.globalData.player.userId + (this.globalData.source ? "&source=" + this.globalData.source : "") + "&traceLevel=" + (this.globalData.traceLevel ? Number(this.globalData.traceLevel) : 1) + "&oid=" + (-1 == this.globalData.oid ? this.globalData.player.userId : this.globalData.oid) + "&shareNo=" + this.globalData.shareNo + "&timestamp=" + t;
    },
    trace: function(a) {
        var t = this;
        if (!a || this.globalData.player || "app_launch" == a.event) {
            var e = [];
            if (a && (e = this.globalData.traceList.push(a)), 0 === e.length) return;
            console.log("this.globalData.energyTotal", this.globalData.energyTotal);
            var i = !0, o = !1, r = void 0;
            try {
                for (var n, h = this.globalData.traceList[Symbol.iterator](); !(i = (n = h.next()).done); i = !0) {
                    var g = n.value;
                    ("login" === g.action && "app_launch" !== g.event || "trace" === g.action || "share" === g.action) && (0 == this.globalData.energyTotal ? g.leftEnergy = this.globalData.energyTotal : g.leftEnergy = this.globalData.energyTotal ? this.globalData.energyTotal : -1);
                }
            } catch (a) {
                o = !0, r = a;
            } finally {
                try {
                    !i && h.return && h.return();
                } finally {
                    if (o) throw r;
                }
            }
            var c = {
                traces: this.globalData.traceList,
                timestamp: new Date().getTime(),
                scene: this.globalData.scene,
                source: this.globalData.source || "",
                rid: this.globalData.rid || "",
                userId: this.globalData.player ? this.globalData.player.userId : "",
                oid: this.globalData.oid || "",
                ack: this.globalData.ack,
                level: this.globalData.traceLevel
            };
            c.sign = s.hexMD5(c.scene + c.source + c.timestamp + "mandiankan"), l.trace(c).then(function(e) {
                var i = !0, o = !1, s = void 0;
                try {
                    for (var l, r = c.traces[Symbol.iterator](); !(i = (l = r.next()).done); i = !0) l.value.shareTicket && (t.globalData.groupData = "");
                } catch (a) {
                    o = !0, s = a;
                } finally {
                    try {
                        !i && r.return && r.return();
                    } finally {
                        if (o) throw s;
                    }
                }
                0 === e.data.code && (0 === t.globalData.ack && t.firstTraceHandle(e.data.data), 
                a || (t.globalData.ack = 0));
            }), this.globalData.traceList = [];
        } else this.globalData.traceList.push(a);
    },
    shareShowTrace: function(a) {
        var t = new Date().getTime();
        a.shareNo = t + "" + this.globalData.player.userId, a.appTime = t - this.globalData.appTimeStart, 
        a.gameTime = a.gameTime || -1, a.shareCardId = a.shareCard, a.action = "share", 
        a.path = this.globalData.options.path, this.trace(a);
    },
    shareTrace: function(a) {
        var t = new Date().getTime();
        a.shareNo = this.globalData.shareNo, a.appTime = t - this.globalData.appTimeStart, 
        a.gameTime = a.gameTime || -1, a.shareCardId = a.shareCard, a.action = "share", 
        a.path = this.globalData.options.path, this.trace(a);
    },
    actionTrace: function(a) {
        var t = new Date().getTime();
        a.appTime = t - this.globalData.appTimeStart, a.gameTime = a.gameTime || -1, a.op_result || 0 === a.op_result ? a.op_result = 0 === a.op_result ? 0 : 1 : a.op_result = -1, 
        a.action = "trace", a.path = this.globalData.options.path, this.trace(a);
    },
    loginTrace: function(a, t) {
        var e = wx.getSystemInfoSync(), i = new Date().getTime(), s = {
            action: "login",
            extraData: JSON.stringify(t) || "",
            appTime: i - this.globalData.appTimeStart,
            shareTicket: this.globalData.groupData || "",
            event: a,
            subEvent: this.globalData.shareNo || "",
            subId: this.globalData.subId,
            appVer: o.service.version,
            wxVer: e.version,
            sdkVer: e.SDKVersion,
            system: e.system,
            platform: e.platform,
            brand: e.brand,
            model: e.model,
            path: this.globalData.options.path
        };
        console.log("extraData", t, s.extraData), "app_launch" === a && (s.leftEnergy = -1), 
        this.trace(s);
    },
    firstTraceHandle: function(a) {
        console.log("ackHandle"), this.globalData.traceLevel = a.level, this.globalData.rid = a.rid, 
        this.globalData.oid = a.oid, this.globalData.source = a.source, this.globalData.ack = 1;
    },
    goback: function() {
        getCurrentPages().length > 1 ? wx.navigateBack({
            delta: 1
        }) : wx.redirectTo({
            url: "/pages/index/index"
        });
    },
    aldConfig: function() {
        var a = this;
        l.aldConfig().then(function(t) {
            0 === t.data.code && (a.actionTrace({
                event: "ald_first",
                subEvent: "ald_open_game"
            }), a.globalData.aldConfig = t.data.data, (wx.getStorageSync("isAld") || a.globalData.ald_media_id && -1 != a.globalData.aldConfig.gameLoadDone.indexOf(a.globalData.ald_media_id)) && i && i.get() && i.get().openId && (wx.aldstat.sendOpenid(i.get().openId), 
            wx.setStorage({
                key: "isAld",
                data: !0
            })));
        });
    },
    checkUpdateVersion: function() {
        if (wx.canIUse("getUpdateManager")) {
            var a = wx.getUpdateManager();
            a.onCheckForUpdate(function(t) {
                t.hasUpdate && (a.onUpdateReady(function() {
                    a.applyUpdate();
                }), a.onUpdateFailed(function() {}));
            });
        }
    },
    getRandomIndex: function(a) {
        return Math.max(0, Math.ceil(Math.random() * a) - 1);
    },
    setLostUserTimer: function(a) {
        var t = this, e = 1e3 * Number(this.globalData.player.loseUserStrategy[a]);
        this.globalData.lostTimer[a] && clearInterval(this.globalData.lostTimer[a]), console.log("setLostUserTimer", e), 
        this.globalData.lostTimer[a] = setTimeout(function() {
            t.setGlobalData({
                isShowTreasure: !0
            });
            var e = "", i = "";
            switch (a) {
              case "figureLevelGuide":
                e = "image_2", i = "image2_box_show";
                break;

              case "firstFinish":
                e = "game_1_finish", i = "game1_box_show";
                break;

              case "firstLevel":
                e = "game_1", i = "game1_box_show";
                break;

              case "homePageUpgrade":
                e = "image_1", i = "image1_box_show";
                break;

              case "secondFinish":
                e = "game_2_finish", i = "game2_box_show";
                break;

              case "secondLevel":
                e = "game_2", i = "game2_box_show";
            }
            t.actionTrace({
                event: e,
                subEvent: i
            }), console.log("setLostUserTimer", t.globalData.isShowTreasure);
        }, e);
    },
    clearLostUserTimer: function(a) {
        this.globalData.lostTimer[a] && clearInterval(this.globalData.lostTimer[a]), this.setGlobalData({
            isShowTreasure: !1
        });
    },
    toggleWatchVideoGuide: function(a) {
        wx.getStorageSync("isWatchGuideFinish"), this.globalData.watchVideoGuideCb = a, 
        a ? this.setGlobalData({
            isShowWatchVideoGuide: !0
        }) : (this.setGlobalData({
            isShowWatchVideoGuide: !1
        }), wx.setStorage({
            key: "isWatchGuideFinish",
            data: !0
        }));
    },
    gamePageShareRealPop: function() {
        var a = this;
        clearInterval(this.globalData.energyInterval), this.globalData.energyInterval = setInterval(function() {
            console.log("gamePageShareRealPop"), l.gamePageShareRealPop().then(function(t) {
                if (0 == t.data.code) {
                    var e = [];
                    t.data.data.isEnergy && e.push({
                        rewardType: 1
                    }), t.data.data.isTips && e.push({
                        rewardType: 2
                    }), a.setGlobalData({
                        getRewardList: e,
                        isShowGetReward: !0
                    });
                }
            });
        }, 3e4);
    }
});