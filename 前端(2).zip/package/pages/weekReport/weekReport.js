function a(a, e, t) {
    return e in a ? Object.defineProperty(a, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[e] = t, a;
}

var e = getApp(), t = require("../../../utils/https");

Page({
    data: {
        siteInfo: require("../../../siteinfo.js"),
        isShowBanner: !0,
        pageData: {},
        bgCopyTime: 10,
        nowWeek: "20000101",
        shareId: "",
        dianGuoZan: !1,
        interstitialAd1: null,
        isShowReward: !1,
        rewardType: 0,
        commonGetEnegyPopupValue: 0,
        isEnergyTip: !0,
        isStarted: !1,
        leavePageTime: 0,
        lastShareEnergyFail1: !1,
        lastShareEnergyFail2: !1,
        shareBackTipContent: "",
        interstitialAdList: []
    },
    onLoad: function(a) {
        e.setGlobalData({
            isShowWatchVideoGuide: !1
        }), e.globalData.options.path = "pages/weekReport/weekReport", e.setWatch(this, "", "weekReport"), 
        e.loginTrace("page_load", a), wx.updateShareMenu({
            withShareTicket: !0
        }), a.week && (this.data.nowWeek = a.week), a.shareId && (this.data.shareId = a.shareId);
    },
    onUnload: function() {
        e.actionTrace({
            event: "page_unload",
            subEvent: ""
        }), this.data.videoAd && this.data.videoAd.destroy();
    },
    onHide: function() {
        this.data.isShare || e.actionTrace({
            event: "page_hide",
            subEvent: ""
        });
    },
    onShow: function() {
        var a = this;
        this.onShowHandle(), this.data.isShare ? this.data.isShare = !1 : e.actionTrace({
            event: "page_show",
            subEvent: ""
        });
        var t = Number(wx.getStorageSync("lastOpenInterstitialAdTime"));
        if ("weekReport" === e.globalData.lastPageName && (!t || Date.now() - t > 36e5) ? (wx.createInterstitialAd && (this.data.interstitialAd1 = wx.createInterstitialAd({
            adUnitId: e.globalData.shareVideoRule.adv.backGameBanner
        }), this.data.interstitialAd1.onLoad(function() {
            a.data.interstitialAd1.show().then(function() {
                wx.setStorageSync("lastOpenInterstitialAdTime", String(Date.now()));
            });
        })), e.globalData.lastPageName = "weekReport") : e.globalData.lastPageName = "weekReport", 
        this.data.shareBackTipContent && (this.wxToast(this.data.shareBackTipContent), this.data.shareBackTipContent = ""), 
        e.globalData.toShare) {
            var i = e.globalData.toShare;
            if (e.setGlobalData({
                toShare: 0
            }), Date.now() - i < e.globalData.shareGetEnergy.timeInterVal) return this.showToast("操作失败 换个群试试");
            if (this.data.lastShareEnergyFail1 || Math.random() < e.globalData.shareGetEnergy.successRate) this.shareGetEnergySuccess(), 
            this.data.lastShareEnergyFail1 = !1; else {
                var n = Math.floor(Math.random() * e.globalData.shareGetEnergy.textList.length);
                this.showToast(e.globalData.shareGetEnergy.textList[n]), this.data.lastShareEnergyFail1 = !0;
            }
        }
        if (this.data.leavePageTime) {
            var o = this.data.leavePageTime;
            if (this.data.leavePageTime = 0, Date.now() - o < e.globalData.shareGetEnergy.timeInterVal) return this.wxToast("分享失败，请分享到群聊");
            if (this.data.lastShareEnergyFail2 || Math.random() < e.globalData.shareGetEnergy.successRate) this.getMedalSuccess(), 
            this.data.lastShareEnergyFail2 = !1; else {
                var s = Math.floor(Math.random() * e.globalData.shareGetEnergy.textList.length);
                this.wxToast(e.globalData.shareGetEnergy.textList[s]), this.data.lastShareEnergyFail2 = !0;
            }
        }
    },
    init: function() {
        var a = this;
        this.getShareAddEnergyStrategy(), e.shareVideoRule(function() {
            a.getPageData();
        });
    },
    getPageData: function() {
        var a = this;
        t.getScholarData(this.data.nowWeek, this.data.shareId).then(function(e) {
            if (0 === e.data.code) {
                for (var t = 0; t < e.data.data.giveLikeList.length; t++) if (e.data.data.giveLikeList[t].otherId === e.data.data.userInfo.selfId) {
                    a.data.dianGuoZan = !0;
                    break;
                }
                a.setData({
                    pageData: e.data.data,
                    dianGuoZan: a.data.dianGuoZan
                });
            }
            a.calcuBgCopyTime();
        }).catch(function(e) {
            a.calcuBgCopyTime();
        });
    },
    wxToast: function(a) {
        wx.showToast({
            title: a,
            icon: "none",
            duration: 2e3
        });
    },
    clickFakeMedal: function() {
        this.wxToast("示例数据仅做展示，下周再来看看吧");
    },
    getShareAddEnergyStrategy: function() {
        return new Promise(function(a, i) {
            t.shareAddEnergyStrategy().then(function(t) {
                0 === t.data.code ? (e.setGlobalData({
                    shareGetEnergy: t.data.data
                }), a()) : i(t);
            }).catch(function(a) {
                i(a);
            });
        });
    },
    calcuBgCopyTime: function() {
        var a = this;
        wx.createSelectorQuery().selectAll("#allPage, #copyBg1, .copyBg2, #copyBg3").boundingClientRect(function(e) {
            a.setData({
                bgCopyTime: Math.ceil((e[0].height - e[1].height - e[12].height) / e[2].height)
            });
        }).exec();
    },
    getMedal: function() {
        var i = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.lightScholarAdv
        }), e.globalData.setting.playAudio("btnClick"), e.globalData.shareVideoRule.adv.lightScholarAdv) {
            var n = null;
            (n = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.lightScholarAdv
            })).offError(), n.onError(function(n) {
                var o;
                console.log("err", n), t.shareVideoDynamicControl(), e.setGlobalData((o = {}, a(o, "shareVideoRule.gameRemind", 1), 
                a(o, "shareVideoRule.energyShortage", 1), a(o, "shareVideoRule.loginAward", 1), 
                a(o, "shareVideoRule.lightScholar", 1), a(o, "shareVideoRule.canWatchVideo", !1), 
                o)), i.getMedalSuccess();
            }), n.offClose(), n.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.lightScholarAdv
                }), i.getMedalSuccess()) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(i.getMedal), 
                e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.lightScholarAdv
                }), wx.showToast({
                    title: "请观看完整视频",
                    icon: "none",
                    duration: 2e3
                }));
            }), n.show().catch(function(a) {
                n.load().then(function() {
                    n.show();
                });
            }), this.data.videoAd = n;
        } else this.getMedalSuccess();
    },
    getMedalSuccess: function() {
        var i = this;
        t.LightUpTheMedal(this.data.pageData.medalName).then(function(t) {
            if (0 === t.data.code) {
                var n;
                i.setData((n = {}, a(n, "pageData.isGet", 1), a(n, "pageData.medalUrl", t.data.data.medalUrl), 
                a(n, "isShowReward", !0), a(n, "rewardType", 8), n)), i.showMixinBanner(), e.globalData.setting.playAudio("getEnergy");
            }
        });
    },
    receiveZanEnergy: function(i) {
        var n = this;
        t.getEnergyByGiveLike(this.data.nowWeek, i.currentTarget.dataset.otherid).then(function(t) {
            if (0 === t.data.code) {
                var o;
                n.setData((o = {}, a(o, "pageData.giveLikeList[" + i.currentTarget.dataset.index + "].used", !0), 
                a(o, "isShowReward", !0), a(o, "rewardType", 5), a(o, "isEnergyTip", !0), a(o, "commonGetEnegyPopupValue", t.data.data.energyValue), 
                o)), n.showMixinBanner(), e.globalData.setting.playAudio("getEnergy");
            }
        });
    },
    giveLikeForScholar: function() {
        var e = this;
        t.giveLikeForScholar(this.data.nowWeek, this.data.pageData.userInfo.userId).then(function(t) {
            if (0 === t.data.code) {
                var i;
                e.data.pageData.giveLikeList.unshift(t.data.data), e.setData((i = {}, a(i, "pageData.giveLikeList", e.data.pageData.giveLikeList), 
                a(i, "dianGuoZan", !0), i));
            }
        });
    },
    closeReward: function() {
        this.setData({
            isBuyTip: !1
        }), 10 != this.data.rewardType ? (e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowReward: !1
        })) : this.setData({
            isEnergyTip: !1,
            isShowReward: !0,
            rewardType: 6,
            commonGetEnegyPopupValue: 10
        });
    },
    toGame: function() {
        var a = this;
        this.data.isStarted || (this.data.isStarted = !0, e.globalData.setting.playAudio("btnClick"), 
        e.globalData.player.nextUnlock ? wx.redirectTo({
            url: "/pages/game/game?level=" + e.globalData.player.nextLevel,
            success: function() {
                a.data.isStarted = !1;
            }
        }) : this.selectComponent("#navbar").useEnergy());
    },
    toGameRedirect: function() {
        var a = this;
        wx.redirectTo({
            url: "/pages/game/game?level=" + e.globalData.player.nextLevel,
            success: function() {
                a.data.isStarted = !1;
            }
        });
    },
    resetStart: function() {
        this.data.isStarted = !1;
    },
    toInvite: function() {
        this.getInviteList(!0);
    },
    getInviteList: function(a) {
        var i = this;
        return a && e.globalData.setting.playAudio("btnClick"), new Promise(function(e, n) {
            t.inviteFriendList().then(function(t) {
                if (0 === t.data.code) {
                    a && i.toggleInvite();
                    for (var o = t.data.data.inviteRecords, s = t.data.data.totalValue, r = !1, l = 0; l < 5; l++) {
                        var d = o[l];
                        d.invitedId ? d.used ? d.status = 1 : (d.status = 2, r = !0) : d.status = 3;
                    }
                    i.setData({
                        totalValue: s,
                        inviteList: o,
                        isShowInviteRedpoint: r
                    }), e();
                } else n(t);
            }).catch(function(a) {
                n(a);
            });
        });
    },
    toSetData: function(a) {
        this.setData(a.detail);
    },
    toggleInvite: function() {
        this.data.isShowInvite && e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowInvite: !this.data.isShowInvite
        });
    },
    shareGetEnergySuccess: function() {
        var a = this;
        t.shareAddEnergy("share").then(function(t) {
            0 === t.data.code && (a.selectComponent("#navbar").shareSuccess(), e.shareVideoRule(), 
            a.selectComponent("#navbar") && a.selectComponent("#navbar").getData("noInit"), 
            a.selectComponent("#navbar").closeNoEnergyPopup());
        });
    },
    goback: function() {
        e.goback();
    },
    shareLightMedal: function() {
        e.globalData.setting.playAudio("btnClick"), this.data.leavePageTime = Date.now();
    },
    shareBackTip: function() {
        this.data.shareBackTipContent = "快通知好友帮忙来点赞吧！";
    },
    onShareAppMessage: function(a) {
        this.data.isShare = !0, e.globalData.lastPageName = "", e.sourceReport("study_share_click");
        var i = {
            title: e.globalData.shareResult.top_right_share.title,
            imageUrl: e.globalData.shareResult.top_right_share.imageUrl,
            path: "/pages/index/index?rid=" + e.globalData.player.userId + (e.globalData.source ? "&source=" + e.globalData.source : "") + "&event=study_share_conver"
        };
        if (!this.data.pageData.fake && "button" === a.from) {
            if ("invite" === a.target.dataset.type) return this.data.isInviteShare = !0, e.sourceReport("invite_button_click"), 
            t.clickInvitedBtn(), i = {
                title: e.globalData.shareResult.index_invite_share.title,
                imageUrl: e.globalData.shareResult.index_invite_share.imageUrl,
                path: e.sharePath() + "&inviterId=" + e.globalData.player.userId + "&event=invite_suc"
            }, e.shareTrace({
                sharePath: i.path,
                event: "receive_energy",
                subEvent: "invite_button_click",
                shareCard: e.globalData.shareResult.index_invite_share.id,
                shareTitle: i.title,
                result: 1,
                gameTime: -1
            }), i;
            if ("newUser" === a.target.dataset.type) return this.data.isNewUserShare = !0, t.clickInvitedBtn(), 
            i = {
                title: e.globalData.shareResult.invite_new_user.title,
                imageUrl: e.globalData.shareResult.invite_new_user.imageUrl,
                path: e.sharePath() + "&isNewUser=" + e.globalData.player.userId
            }, e.shareTrace({
                sharePath: i.path,
                event: "invite_new",
                subEvent: "invite_new_click",
                shareCard: e.globalData.shareResult.invite_new_user.id,
                shareTitle: i.title,
                result: 1,
                gameTime: -1
            }), i;
            if ("not-energy" === a.target.dataset.type) return e.sourceReport("uenergy_share_click"), 
            i = {
                title: e.globalData.shareResult.not_energy.title,
                imageUrl: e.globalData.shareResult.not_energy.imageUrl,
                path: e.sharePath() + "&event=uenergy_share_conver&otherId=" + e.globalData.player.userId + "&shareTsp=" + Date.now() + "&bonusType=energy"
            }, this.data.energyTraceData = {
                sharePath: i.path,
                event: "un_energy",
                subEvent: "un_energy_click",
                shareCard: e.globalData.shareResult.not_energy.id,
                shareTitle: i.title,
                result: 1,
                gameTime: -1
            }, i;
            i = {
                title: e.globalData.shareResult.scholar_share.title,
                imageUrl: e.globalData.shareResult.scholar_share.imageUrl,
                path: "/pages/index/index?goWeekReport=true&shareId=" + this.data.pageData.userInfo.userId + "&week=" + this.data.nowWeek + "&rid=" + e.globalData.player.userId + (e.globalData.source ? "&source=" + e.globalData.source : "") + "&event=study_share_conver"
            };
        }
        return i;
    },
    buySuccess: function(a) {
        var e = a.detail;
        this.selectComponent("#navbar").getData("noInit");
        var t = e.propType;
        if (2 != t) if (4 != t) {
            var i = !0, n = 5;
            3 == t && (n = 6, i = !1), this.setData({
                isBuyTip: i,
                isShowReward: !0,
                rewardType: n,
                commonGetEnegyPopupValue: e.propValue
            }), this.showMixinBanner();
        } else this.setData({
            isShowReward: !0,
            rewardType: 10
        });
    },
    toggleShop: function() {
        this.setData({
            isShowShop: !this.data.isShowShop
        });
    },
    shopGetUserInfo: function(a) {
        a.detail ? (Session.clear(), e.setGlobalData({
            needAuth: !1,
            userInfo: a.detail.userInfo
        })) : this.showToast("请点击允许，授权信息购买能量");
    },
    toggleInviteNew: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowInviteNew: !this.data.isShowInviteNew
        });
    },
    showNewInviteToast: function(a) {
        this.showToast(a.detail);
    },
    toggleSignUp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowSignUp: !this.data.isShowSignUp,
            daysSignStyle: !!this.data.newUserHadDaysSign
        });
    },
    toSign: function() {
        this.data.whatDidIDo = "goDaysSign";
    },
    getPlayer: function() {
        var a = this;
        t.player().then(function(t) {
            a.data.firstSign = t.data.data.firstSign, "goDaysSign" === a.data.whatDidIDo && t.data.data.firstSign && a.signSuccess();
            var i = t.data.data.signDays + 1;
            t.data.data.sign && (i = t.data.data.signDays);
            var n = Math.floor((i - 8) / 6) + 1;
            n < 0 && (n = 0), a.setData({
                daysSignInfo: {
                    nowSignDays: i,
                    week: n
                }
            }), t.data.data.gzhEnergy && (e.setGlobalData({
                goGzhSign: !1,
                energyTotal: e.globalData.energyTotal + t.data.data.gzhEnergy
            }), a.setData({
                isShowGzhSign: !1,
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: t.data.data.gzhEnergy
            }), a.showMixinBanner(), a.selectComponent("#navbar").getData("noInit"), e.globalData.setting.playAudio("getEnergy"));
        });
    },
    toggleGzhSignUp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGzhSign: !this.data.isShowGzhSign
        });
    },
    toGzh: function() {
        this.data.goGzhSign = !0, e.setGlobalData({
            goGzhSign: !0
        });
    },
    onShowHandle: function() {
        var a = this;
        if (this.getPlayer(), this.data.goGzhSign) {
            var i = "";
            this.data.goGzhSign && (Session.clear(), i = "gzhSign"), t.suppleMpReward(e.globalData.scene, i).then(function(t) {
                0 === t.data.code && (a.selectComponent("#navbar").getData("noInit"), e.actionTrace({
                    event: "enlist_wxoa",
                    subEvent: "enlist_wxoa_suc"
                }), e.setGlobalData({
                    goGzhSign: !1,
                    energyTotal: e.globalData.energyTotal + t.data.data.gzhEnergy
                }), a.setData({
                    isShowGzhSign: !1,
                    isEnergyTip: !0,
                    isShowReward: !0,
                    rewardType: 5,
                    commonGetEnegyPopupValue: t.data.data.gzhEnergy
                }), a.showMixinBanner(), e.globalData.setting.playAudio("getEnergy"));
            });
        }
        this.data.isTryingGame && (this.data.isTryingGame = !1, this.tryGameHandle()), this.data.isNewUserShare && (this.data.isNewUserShare = !1, 
        this.selectComponent("#inviteNewUser") && this.selectComponent("#inviteNewUser").show()), 
        this.data.friendLine, "goDaysSign" === this.data.whatDidIDo && (this.setData({
            isShowSignUp: !1
        }), this.getPlayer());
    },
    toFriendLine: function() {
        this.data.friendLine = !0;
    },
    toggleFriendLine: function() {
        this.setData({
            isShowFriendLine: !this.data.isShowFriendLine
        });
    },
    toTryGame: function(a) {
        this.data.tryGame = a.detail, this.data.isTryingGame = !0, this.data.tryStart = new Date().getTime();
    },
    toggleGameTry: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGameTry: !this.data.isShowGameTry
        });
    },
    tryGetSuccess: function(a) {
        e.globalData.setting.playAudio("getEnergy"), this.setData({
            isEnergyTip: !0,
            isShowReward: !0,
            rewardType: 5,
            commonGetEnegyPopupValue: a.detail.bonusValue
        }), this.showMixinBanner(), this.selectComponent("#navbar").getData("noInit");
    },
    tryFinish: function() {},
    toSignWatchVideo: function() {
        var i = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
        }), e.globalData.shareVideoRule.adv.dailySignAdv) {
            var n = null;
            (n = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.dailySignAdv
            })).load(), n.offError(), n.onError(function(i) {
                console.log("err", i), t.shareVideoDynamicControl();
                var n = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var o in e.globalData.shareVideoRule) "canWatchVideo" != o && (n[[ "shareVideoRule." + o ]] = 1);
                e.setGlobalData(n);
            }), n.offClose(), n.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
                }), i.signSuccess(!0)) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(i.toSignWatchVideo), 
                e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
                }), i.showToast("请观看完整视频"));
            }), n.show().catch(function(a) {
                n.load().then(function() {
                    n.show();
                });
            }), this.data.videoAd = n;
        } else this.signSuccess(!0);
    },
    signSuccess: function(a) {
        this.data.whatDidIDo = "", this.setData({
            isEnergyTip: !0,
            isShowReward: !0,
            commonGetEnegyPopupValue: a ? 2 : this.data.firstSign,
            rewardType: 5
        }), this.showMixinBanner();
        var t = this.data.player;
        t.sign = !0, e.setGlobalData({
            player: t
        }), this.setData({
            player: t
        }), e.globalData.setting.playAudio("getEnergy"), wx.getStorageSync("newUserHadDaysSign") || (wx.setStorageSync("newUserHadDaysSign", "yes"), 
        this.setData({
            newUserHadDaysSign: !0
        }));
    },
    bannerLoad: function() {
        e.actionTrace({
            event: "ad_banner_show",
            subEvent: 8 != this.data.rewardType ? this.datashareVideoRule.adv.figureUpgradeBanner : this.datashareVideoRule.adv.scholarBanner
        });
    },
    bannerError: function(a) {
        e.actionTrace({
            event: "ad_banner_fail",
            subEvent: 8 != this.data.rewardType ? this.datashareVideoRule.adv.figureUpgradeBanner : this.datashareVideoRule.adv.scholarBanner
        }), console.log("banner err", a), this.setData({
            isShowBanner: !1
        });
    },
    showMixinBanner: function() {
        this.data.player.passLevel > 13 && (console.log("showMixinBanner1"), this.interstitialAdLoad(e.globalData.shareVideoRule.adv.mixinBanner).show().catch(function(a) {
            console.log("showMixinBanner2", a);
        }));
    },
    interstitialAdLoad: function(a) {
        var t = void 0;
        return wx.createInterstitialAd && !this.data.interstitialAdList[a] ? ((t = wx.createInterstitialAd({
            adUnitId: a
        })).offLoad(), t.onLoad(function() {
            e.log("onLoad event emit"), e.actionTrace({
                event: "ad_popup_show",
                subEvent: a
            });
        }), t.offError(), t.onError(function(t) {
            e.log("onError event emit", t), e.actionTrace({
                event: "ad_popup_fail",
                subEvent: a
            });
        }), t.onClose(function(a) {
            e.log("onClose event emit", a);
        }), this.data.interstitialAdList[a] = t) : t = this.data.interstitialAdList[a], 
        t;
    },
    getDouble: function() {
        var i = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
        }), e.globalData.shareVideoRule.adv.doubleEnergyAdv) {
            var n = null;
            (n = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.doubleEnergyAdv
            })).load(), n.offError(), n.onError(function(n) {
                console.log("err", n), t.shareVideoDynamicControl(), i.showToast("今日视频已达上限"), i.setData({
                    isShowReward: !1
                });
                var o = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var s in e.globalData.shareVideoRule) "canWatchVideo" != s && (o[[ "shareVideoRule." + s ]] = 1);
                e.setGlobalData(o);
            }), n.offClose(), n.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
                }), i.doubleSuccess()) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(i.getDouble), 
                e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
                }), i.showToast("请观看完整视频"));
            }), n.show().catch(function(a) {
                n.load().then(function() {
                    n.show();
                });
            }), this.data.videoAd = n;
        } else this.doubleSuccess();
    },
    doubleSuccess: function() {
        var a = this;
        t.doubleGetEnergy(this.data.commonGetEnegyPopupValue).then(function(t) {
            0 === t.data.code && (e.globalData.setting.playAudio("getEnergy"), a.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 9,
                commonGetEnegyPopupValue: a.data.commonGetEnegyPopupValue
            }), a.selectComponent("#navbar").getData("noInit"));
        });
    },
    toggleWatchVideoGuide: function() {
        e.setGlobalData({
            isShowWatchVideoGuide: !e.globalData.isShowWatchVideoGuide
        });
    },
    refreshReward: function() {
        console.log("refreshReward"), this.selectComponent("#navbar") && this.selectComponent("#navbar").getData("noInit");
    }
});