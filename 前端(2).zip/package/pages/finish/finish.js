function a(a, e, t) {
    return e in a ? Object.defineProperty(a, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[e] = t, a;
}

var e = getApp(), t = require("../../../config"), i = require("../../../utils/https"), o = (require("../../../utils/ald-stat-conf.js"), 
require("../../../vendor/qcloud-weapp-client-sdk/lib/session")), n = "", s = null;

Page({
    data: {
        siteInfo: require("../../../siteinfo.js"),
        friendLineType: "",
        isShowFinishShare: !1,
        isShowShareSuccess: !1,
        isShowShowOff: !1,
        isAnimalEnd: !1,
        interstitialAdList: [],
        selectBox: "",
        isOpenBoxShare: !1,
        shareTimeStamp: 0,
        isEnergyTip: !1,
        isBannerReady: !1,
        isShowReward: !1,
        commonGetEnegyPopupValue: 0,
        rewardType: 0,
        isShowBanner: !0,
        toastTime: 2e3,
        pageReady: !1,
        isIphonX: !1,
        roundNum: 0,
        livesRect: {},
        moveAnimation: "",
        canClick: !0,
        isShowInvite: !1,
        inviteList: [],
        toastList: [],
        upgrade: !1,
        tip: "",
        showIdiomPopup: !1,
        wordExplain: {},
        lastShareEnergyFail: !1,
        showNewPlayerModal5: !1,
        showNewPlayerModal6: !1,
        showNewPlayerModal7: !1,
        showZikuaiCase: !1,
        wanyuanZkImg: "",
        zikuaiInfo: {},
        interstitialAd1: null,
        showMoreGamePopup: !1,
        moreGameList: [],
        idiomList: [],
        showRound1Guide: !1,
        wanyuanActivityEnergy: 0
    },
    onLoad: function(a) {
        var n = this;
        e.setGlobalData({
            isShowTreasure: !1,
            isShowWatchVideoGuide: !1
        }), this.setData({
            isTest: e.globalData.isTest,
            lastSuccessWord: a.lastSuccessWord
        }), this.data.boxList = wx.getStorageSync("shareImgBox"), 1129 == e.globalData.scene && i.getSeoData("finish", JSON.stringify(a)).then(function(a) {
            0 == a.data.code && n.setData({
                seoData: a.data.data
            });
        }), 1129 == e.globalData.scene || 0 != e.globalData.mode ? 1129 != e.globalData.scene || 0 != e.globalData.mode ? (e.setWatch(this, "", "finish"), 
        e.globalData.options.path = "pages/finish/finish", e.loginTrace("page_load", a), 
        console.log("finish.onLoad"), wx.updateShareMenu({
            withShareTicket: !0
        }), e.globalData.gameLevel && e.globalData.gameLevel.idiom && this.setData({
            idiomList: e.globalData.gameLevel.idiom
        }), a.roundNum && this.setData({
            roundNum: a.roundNum
        }), "iPhone X" == t.model && this.setData({
            isIphonX: !0
        }), 1 == a.roundNum && (this.setData({
            showRound1Guide: !0
        }), e.actionTrace({
            event: "ald_first",
            subEvent: "ald_first_finish"
        }), (!e.globalData.ald_media_id || e.globalData.ald_media_id && -1 != e.globalData.aldConfig.oneFinish.indexOf(e.globalData.ald_media_id)) && o && o.get() && o.get().openId && (wx.aldstat.sendOpenid(o.get().openId), 
        wx.setStorage({
            key: "isAld",
            data: !0
        }))), 2 == a.roundNum && (wx.setStorageSync("newPlayHelp", "yes"), e.globalData.ald_media_id && -1 != e.globalData.aldConfig.twoFinish.indexOf(e.globalData.ald_media_id) && o && o.get() && o.get().openId && (wx.aldstat.sendOpenid(o.get().openId), 
        wx.setStorage({
            key: "isAld",
            data: !0
        }))), 3 == a.roundNum && setTimeout(function() {
            n.setData({
                showNewPlayerModal5: !0
            });
        }, 1200), 1 == a.roundNum && e.setLostUserTimer("firstFinish"), 2 == a.roundNum && e.setLostUserTimer("secondFinish"), 
        20 == a.roundNum && (this.setData({
            iconType: 2
        }), this.toggleShowOff()), a.roundNum % 20 ? wx.removeStorageSync("guideViewRank") : wx.setStorageSync("guideViewRank", "yes"), 
        this.onLoadMixinBanner(a), this.onLoadFinishShareImg(a)) : this.setData({
            seoMode: !0
        }) : wx.redirectTo({
            url: "/pages/index/index"
        });
    },
    bindgetuserinfo2: function(a) {
        e.actionTrace({
            event: "auth_user_info",
            subEvent: "rank_all_click",
            op_result: 1,
            userInfo: a.detail.userInfo
        });
    },
    toggleFinishShare: function() {
        console.log("toggleFinishShare"), this.setData({
            isShowFinishShare: !this.data.isShowFinishShare
        }), this.data.isShowFinishShare && i.finishPageInfo("add");
    },
    onLoadFinishShareImg: function(a) {
        var e = this;
        i.finishPageInfo("select").then(function(a) {
            0 == a.data.code && (e.setData({
                finishPageInfo: a.data.data
            }), e.data.finishPageInfo.showPop && e.getFinishShareImg());
        });
    },
    onLoadMixinBanner: function(a) {
        if (this.data.roundNum < 13 || e.globalData.gameStartTime && Date.now() - e.globalData.gameStartTime > 1e4) {
            if (!(s = this.interstitialAdLoad(e.globalData.shareVideoRule.adv.tableScreenBanner))) return;
            s.offLoad(), s.onLoad(function() {
                e.actionTrace({
                    event: "ad_popup_show",
                    subEvent: e.globalData.shareVideoRule.adv.tableScreenBanner
                });
            }), s.offError(), s.onError(function(a) {
                e.actionTrace({
                    event: "ad_popup_fail",
                    subEvent: e.globalData.shareVideoRule.adv.tableScreenBanner
                });
            });
            var t = -1, i = -1;
            for (var o in e.globalData.tableScreenStrategy) this.data.roundNum >= Number(o) && t < Number(o) && (t = Number(o), 
            i = e.globalData.tableScreenStrategy[o]);
            if (-1 == (i = 0)) return;
            if (0 == i) return void s.show().catch(function(a) {});
            (this.data.roundNum - t) % (i + 1) == 0 && (console.log("interstitialAd.show3"), 
            s.show().catch(function(a) {}));
        }
    },
    showMixinBanner: function() {
        if (this.data.player.passLevel > 13) {
            console.log("showMixinBanner1");
            var a = this.interstitialAdLoad(e.globalData.shareVideoRule.adv.mixinBanner);
            if (!a) return;
            a.offLoad(), a.onLoad(function() {
                e.actionTrace({
                    event: "ad_popup_show",
                    subEvent: e.globalData.shareVideoRule.adv.mixinBanner
                });
            }), a.offError(), a.onError(function(a) {
                e.actionTrace({
                    event: "ad_popup_fail",
                    subEvent: e.globalData.shareVideoRule.adv.mixinBanner
                });
            }), a.show().catch(function(a) {
                console.log("showMixinBanner2", a);
            });
        }
    },
    interstitialAdLoad: function(a) {
        var t = void 0;
        return wx.createInterstitialAd && !this.data.interstitialAdList[a] ? ((t = wx.createInterstitialAd({
            adUnitId: a
        })).offLoad(), t.onLoad(function() {
            e.actionTrace({
                event: "ad_popup_show",
                subEvent: a
            }), e.log("onLoad event emit");
        }), t.offError(), t.onError(function(t) {
            e.actionTrace({
                event: "ad_popup_fail",
                subEvent: a
            });
        }), t.onClose(function(a) {
            e.log("onClose event emit", a);
        }), this.data.interstitialAdList[a] = t) : t = this.data.interstitialAdList[a], 
        t;
    },
    onUnload: function() {
        this.data.videoAd && this.data.videoAd.destroy(), console.log("finish.onUnload"), 
        e.actionTrace({
            event: "page_unload",
            subEvent: ""
        });
    },
    onShow: function() {
        var a = this;
        if (this.selectComponent("#showOffPopup") && this.selectComponent("#showOffPopup").show(), 
        e.globalData.toOtherGame) {
            e.globalData.toOtherGame = !1;
            var t = this.interstitialAdLoad(e.globalData.shareVideoRule.adv.tableScreenBanner);
            console.log("interstitialAd.show4"), t.show().catch(function(a) {});
        }
        if (this.onShowHandle(), console.log("finish.onShow"), this.data.isShare ? this.data.isShare = !1 : e.actionTrace({
            event: "page_show",
            subEvent: ""
        }), setTimeout(function() {
            a.selectComponent("#navbar") && a.selectComponent("#navbar").show(), a.setData({
                isBannerReady: !0
            });
        }, 500), this.data.isInviteShare && (this.data.isInviteShare = !1, this.showToast("请提醒好友打开游戏，即可获取能量奖励")), 
        this.data.isOpenBoxShare) {
            this.data.isOpenBoxShare = !1, new Date().getTime();
            var i = this.data.shareTimeStamp;
            if (e.setGlobalData({
                toShare: 0
            }), Date.now() - i < e.globalData.shareGetEnergy.timeInterVal) return this.data.openBoxTraceData.result = 0, 
            e.shareTrace(this.data.openBoxTraceData), this.showToast("请将活动分享到群，开启宝箱");
            this.data.lastShareEnergyFail || Math.random() < e.globalData.shareGetEnergy.successRate ? (this.getZikuai(), 
            this.data.lastShareEnergyFail = !1) : (this.data.openBoxTraceData.result = 0, this.showToast("请将活动分享到群，开启宝箱"), 
            this.data.lastShareEnergyFail = !0), e.shareTrace(this.data.openBoxTraceData);
        }
        var o = Number(wx.getStorageSync("lastOpenInterstitialAdTime"));
        if ("finish" === e.globalData.lastPageName && (!o || Date.now() - o > 36e5) ? (wx.createInterstitialAd && (this.data.interstitialAd1 = wx.createInterstitialAd({
            adUnitId: e.globalData.shareVideoRule.adv.backGameBanner
        }), this.data.interstitialAd1.onLoad(function() {
            a.data.interstitialAd1.show().then(function() {
                wx.setStorageSync("lastOpenInterstitialAdTime", String(Date.now()));
            });
        })), e.globalData.lastPageName = "finish") : e.globalData.lastPageName = "finish", 
        e.globalData.showWanyuanActivity && e.globalData.remainLevelGetZikuai && e.setGlobalData({
            wanyuanActivityTip: !e.globalData.wanyuanActivityTip
        }), e.globalData.toShare) {
            var n = e.globalData.toShare;
            if (e.setGlobalData({
                toShare: 0
            }), Date.now() - n < e.globalData.shareGetEnergy.timeInterVal) return this.data.energyTraceData.result = 0, 
            e.shareTrace(this.data.energyTraceData), this.showToast("操作失败 换个群试试");
            if (this.data.lastShareEnergyFail || Math.random() < e.globalData.shareGetEnergy.successRate) this.shareGetEnergySuccess(), 
            this.data.lastShareEnergyFail = !1; else {
                var s = Math.floor(Math.random() * e.globalData.shareGetEnergy.textList.length);
                this.showToast(e.globalData.shareGetEnergy.textList[s]), this.data.lastShareEnergyFail = !0, 
                this.data.energyTraceData.result = 0;
            }
            e.shareTrace(this.data.energyTraceData);
        }
    },
    onHide: function() {
        console.log("finish.onHide"), this.data.isShare || e.actionTrace({
            event: "page_hide",
            subEvent: ""
        }), this.selectComponent("#navbar").hide();
    },
    init: function() {
        this.getPassData(), this.getInviteList(), e.shareVideoRule();
    },
    toggleMoreGame: function() {
        var a = this;
        this.data.showMoreGamePopup ? this.setData({
            showMoreGamePopup: !1
        }) : (e.globalData.setting.playAudio("btnClick"), i.moreGame().then(function(e) {
            0 === e.data.code && a.setData({
                moreGameList: e.data.data,
                showMoreGamePopup: !0
            });
        }));
    },
    submitForm: function(a) {
        i.uploadFormId(a.detail.formId, this.data.player.userId);
    },
    previewLevel: function() {
        e.globalData.gameLevel = "", i.previewLevel().then(function(a) {
            0 === a.data.code ? e.globalData.gameLevel = a.data.data : e.globalData.gameLevel = "";
        }).catch(function(a) {
            e.globalData.gameLevel = "";
        });
    },
    toggleReward: function(a) {
        var e = {};
        a && "string" == typeof a && (e.rewardType = a), e.isEnergyTip = !1, e.isShowReward = !this.data.isShowReward, 
        this.setData(e), this.data.isShowReward && this.showMixinBanner();
    },
    viewActivityDetail: function() {
        0 == this.data.selectBox ? (e.actionTrace({
            event: "activity_guide",
            subEvent: "finish1_open_activity"
        }), wx.redirectTo({
            url: "/package/pages/activity/activity?showContinueGameGuide=true"
        })) : wx.redirectTo({
            url: "/package/pages/activity/activity"
        });
    },
    closeZikuaiCase: function() {
        e.globalData.setting.playAudio("btnClick"), 0 === this.data.selectBox && e.actionTrace({
            event: "activity_guide",
            subEvent: "finish1_close_box"
        }), this.setData({
            showZikuaiCase: !1
        });
    },
    activityDetail: function() {
        var a = this;
        i.activityDetail().then(function(t) {
            if (0 === t.data.code) {
                for (var i = t.data.data.passLevel, o = t.data.data.detail.word, n = 0; n < o.length; n++) {
                    if (i < o[n].level) {
                        e.setGlobalData({
                            remainLevelGetZikuai: o[n].level - i
                        });
                        break;
                    }
                    if (o[n + 1] && i >= o[n].level && i < o[n + 1].level) {
                        e.setGlobalData({
                            remainLevelGetZikuai: o[n + 1].level - i
                        });
                        break;
                    }
                    i >= o[n].level && e.setGlobalData({
                        remainLevelGetZikuai: 0
                    });
                }
                if (t.data.data.detail.finishTime < new Date().getTime()) return a.setData({
                    isActivityEnd: !0
                }), void (e.globalData.isActivityEnd = !0);
                for (var s = 0; s < o.length; s++) if (o[s].level == i) {
                    a.setData({
                        showZikuaiCase: !0,
                        selectBox: s
                    });
                    break;
                }
            }
        });
    },
    openZikuaiCase: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.activityAdv
        }), 0 === this.data.selectBox && e.actionTrace({
            event: "activity_guide",
            subEvent: "finish1_open_box"
        }), e.globalData.setting.playAudio("btnClick"), 1 != this.data.shareVideoRule.jsOpenBox) if (e.globalData.shareVideoRule.adv.activityAdv) {
            var o = null;
            (o = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.activityAdv
            })).offError(), o.onError(function(o) {
                console.log("err", o), i.shareVideoDynamicControl();
                var n = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var s in e.globalData.shareVideoRule) "canWatchVideo" != s && (n[[ "shareVideoRule." + s ]] = 1);
                e.setGlobalData(n), t.getZikuai();
            }), o.offClose(), o.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.activityAdv
                }), t.getZikuai()) : (e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.activityAdv
                }), wx.showToast({
                    title: "请观看完整视频",
                    icon: "none",
                    duration: 2e3
                }));
            }), o.show().catch(function(a) {
                o.load().then(function() {
                    o.show();
                });
            }), this.data.videoAd = o;
        } else this.getZikuai();
    },
    getZikuai: function() {
        var a = this;
        i.participate(this.data.selectBox).then(function(t) {
            0 === t.data.code ? (t.data.data.allWord.find(function(a) {
                a.word === t.data.data.getWord && (t.data.data.wanyuanZkImg = a.filePath);
            }), e.globalData.setting.playAudio("getEnergy"), a.setData({
                zikuaiInfo: t.data.data,
                isShowReward: !0,
                rewardType: 7,
                showZikuaiCase: !1
            }), a.showMixinBanner()) : a.showToast(t.data.msg);
        });
    },
    closeReward: function() {
        this.setData({
            isBuyTip: !1
        }), 10 != this.data.rewardType ? (0 === this.data.selectBox && e.actionTrace({
            event: "activity_guide",
            subEvent: "finish1_close_word"
        }), e.globalData.setting.playAudio("btnClick"), this.setData({
            isEnergyTip: !1,
            isShowReward: !1
        })) : this.setData({
            isEnergyTip: !1,
            isShowReward: !0,
            rewardType: 6,
            commonGetEnegyPopupValue: 10
        });
    },
    bannerInit: function() {
        this.setData({
            shareVideoRule: e.globalData.shareVideoRule
        });
    },
    bannerLoad: function() {
        e.actionTrace({
            event: "ad_banner_show",
            subEvent: this.data.shareVideoRule.adv.figureUpgradeBanner
        });
    },
    bannerError: function() {
        e.actionTrace({
            event: "ad_banner_fail",
            subEvent: this.data.shareVideoRule.adv.figureUpgradeBanner
        }), this.setData({
            isShowBanner: !1
        });
    },
    onReady: function() {
        var a = this;
        this.setData({
            pageReady: !0
        }), wx.createSelectorQuery().select(".block1>>>#navBarLives").boundingClientRect(function(e) {
            a.data.livesRect = {
                left: e.left / t.pixelRate + 14,
                top: e.top / t.pixelRate + 6
            }, wx.createSelectorQuery().select("#the-id").boundingClientRect(function(e) {
                var i = (e.left - 85) / t.pixelRate + 254 - a.data.livesRect.left, o = (e.top - 25) / t.pixelRate + 25 - a.data.livesRect.top;
                a.data.moveAnimation = "transform: translate(" + i + "rpx, " + o + "rpx) scale(1.3);";
            }).exec(), setTimeout(function() {
                wx.createSelectorQuery().select("#the-id").boundingClientRect(function(e) {
                    if (e) {
                        var i = e.left / t.pixelRate + 300 - a.data.livesRect.left, o = e.top / t.pixelRate + 25 - a.data.livesRect.top;
                        a.data.moveAnimation = "transform: translate(" + i + "rpx, " + o + "rpx) scale(1.3);";
                    }
                }).exec();
            }, 1700);
        }).exec(), e.globalData.setting.playAudio("finish");
    },
    closeGuide2: function() {
        this.setData({
            showNewPlayerModal6: !1
        });
    },
    addWord: function(t) {
        var o = this, n = t.currentTarget.dataset.word;
        i.addVocab(n.id).then(function(t) {
            0 === t.data.code ? (o.data.wordExplain.collect = !0, o.setData({
                wordExplain: o.data.wordExplain,
                showNewPlayerModal6: !1
            }), o.showToast("添加成功", 1e3), e.globalData.guideList.addIdiom || (e.globalData.guideList.addIdiom = !0, 
            e.setGlobalData(a({}, "guideList.addIdiom", !0)), i.addGuide("addIdiom"), wx.setStorageSync("guideOpenWordBook", "yes"))) : o.showToast(t.data.msg);
        });
    },
    deleteWord: function(a) {
        var e = this, t = a.currentTarget.dataset.word;
        i.dropVocab(t.id).then(function(a) {
            0 === a.data.code && (e.data.wordExplain.collect = !1, e.setData({
                wordExplain: e.data.wordExplain
            }), e.showToast("删除成功", 1e3));
        });
    },
    toSetData: function(a) {
        this.setData(a.detail);
    },
    shareGetEnergySuccess: function() {
        var a = this;
        i.shareAddEnergy("share").then(function(t) {
            0 === t.data.code && (a.selectComponent("#navbar").shareSuccess(), e.shareVideoRule(), 
            a.selectComponent("#navbar") && a.selectComponent("#navbar").getData("noInit"), 
            a.selectComponent("#navbar").closeNoEnergyPopup());
        });
    },
    getAllEnergyByInvite: function() {
        var a = this;
        e.globalData.setting.playAudio("btnClick"), this.data.totalValue && i.getAllEnergyByInvite().then(function(t) {
            0 === t.data.code ? (a.selectComponent("#navbar").getData(), a.getInviteList(), 
            a.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: a.data.totalValue
            }), a.showMixinBanner(), e.globalData.setting.playAudio("getEnergy")) : a.showToast(t.data.msg);
        });
    },
    getEnergyByInvite: function(a) {
        var t = this, o = a.currentTarget.dataset.item;
        e.globalData.setting.playAudio("btnClick"), i.getEnergyByInvite(o.invitedId).then(function(a) {
            0 === a.data.code ? (t.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: o.energyValue
            }), t.showMixinBanner(), e.globalData.setting.playAudio("getEnergy"), t.selectComponent("#navbar").getData(), 
            t.getInviteList()) : t.showToast(a.data.msg);
        });
    },
    getPassData: function() {
        var a = this, t = Date.now() - e.globalData.gameStartTime || "";
        i.pass(Number(this.data.roundNum), t).then(function(t) {
            0 === t.data.code && (a.setData({
                daTiFinishEnable: t.data.data.daTiFinishEnable,
                upgrade: t.data.data.upgrade,
                tip: t.data.data.tip || ""
            }), t.data.data.presentEnergy && e.setGlobalData({
                energyTotal: e.globalData.energyTotal + t.data.data.presentEnergy
            }), a.previewLevel(), a.activityDetail());
        });
    },
    getInviteList: function(a) {
        var t = this;
        return a && e.globalData.setting.playAudio("btnClick"), new Promise(function(e, o) {
            i.inviteFriendList().then(function(i) {
                if (0 === i.data.code) {
                    a && t.toggleInvite();
                    for (var n = i.data.data.inviteRecords, s = i.data.data.totalValue, r = !1, l = 0; l < 5; l++) {
                        var d = n[l];
                        d.invitedId ? d.used ? d.status = 1 : (d.status = 2, r = !0) : d.status = 3;
                    }
                    t.setData({
                        totalValue: s,
                        inviteList: n,
                        isShowInviteRedpoint: r
                    }), e();
                } else o(i);
            }).catch(function(a) {
                o(a);
            });
        });
    },
    toggleInvite: function() {
        this.setData({
            isShowInvite: !this.data.isShowInvite
        });
    },
    toInvite: function() {
        this.getInviteList(!0);
    },
    toIndex: function() {
        e.globalData.setting.playAudio("btnClick"), e.goback();
    },
    rootCatch: function() {
        1 == this.data.roundNum && e.clearLostUserTimer("firstFinish"), 2 == this.data.roundNum && e.clearLostUserTimer("secondFinish"), 
        this.data.showNewPlayerModal5 && this.closeGuide1(), this.data.showNewPlayerModal6 && this.closeGuide2();
    },
    toGame: function() {
        e.globalData.setting.playAudio("btnClick"), this.data.isShowReward && this.setData({
            isShowReward: !1
        }), this.selectComponent("#navbar").useEnergy();
    },
    toGameRedirect: function() {
        var a = this;
        this.setData({
            livesRect: this.data.livesRect,
            moveAnimation: this.data.moveAnimation
        }), setTimeout(function() {
            a.setData({
                livesRect: {},
                moveAnimation: ""
            }), wx.redirectTo({
                url: "/pages/game/game"
            });
        }, 1200);
    },
    closeGuide1: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            showNewPlayerModal5: !1
        });
    },
    openIdiomPopup: function(a) {
        var t = this;
        e.globalData.setting.playAudio("btnClick"), this.data.showNewPlayerModal5 && this.setData({
            showNewPlayerModal5: !1
        }), i.explanation(a.currentTarget.dataset.word).then(function(a) {
            0 === a.data.code && (e.globalData.guideList.addIdiom ? t.setData({
                showIdiomPopup: !0,
                wordExplain: a.data.data
            }) : t.setData({
                showIdiomPopup: !0,
                wordExplain: a.data.data,
                showNewPlayerModal6: !0
            }));
        });
    },
    catchtouchmove: function() {
        return !1;
    },
    closeIdiomPopup: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            showIdiomPopup: !1
        });
    },
    showToast: function(a) {
        var e = this, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3, i = [];
        i = "string" == typeof a || "number" == typeof a ? [ a ] : a, this.data.toastList.push(i), 
        this.setData({
            toastTime: t,
            toastList: this.data.toastList
        }), n && clearTimeout(n), n = setTimeout(function() {
            n = "", e.setData({
                toastList: []
            });
        }, t);
    },
    onShareAppMessage: function(a) {
        if (1129 == e.globalData.scene) return this.data.isShare = !0, {
            title: this.data.seoData.title[e.getRandomIndex(this.data.seoData.title.length)],
            path: "/pages/index/index?source=wxsearch",
            imageUrl: this.data.seoData.imgUrl
        };
        this.data.isShare = !0, e.globalData.lastPageName = "";
        var t = {
            title: e.globalData.shareResult.top_right_share.title,
            imageUrl: e.globalData.shareResult.top_right_share.imageUrl,
            path: e.sharePath()
        };
        return "button" === a.from && "finish-img" === a.target.dataset.type ? (this.data.isShareFinishImg = !0, 
        t = {
            title: this.data.finishPageInfo.shareTitle.replace("%s", "[" + this.data.lastSuccessWord + "]"),
            imageUrl: this.data.finishShareImg,
            path: e.sharePath()
        }, e.shareTrace({
            sharePath: t.path,
            event: "finish_share",
            subEvent: "finish_share_click1",
            shareCard: this.data.finishPageInfo.shareId,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t) : "button" === a.from && "finish-img2" === a.target.dataset.type ? (this.data.isShareFinishImg = !0, 
        t = {
            title: this.data.finishPageInfo.shareTitle.replace("%s", "[" + this.data.lastSuccessWord + "]"),
            imageUrl: this.data.finishShareImg,
            path: e.sharePath()
        }, e.shareTrace({
            sharePath: t.path,
            event: "finish_share",
            subEvent: "finish_share_click2",
            shareCard: e.globalData.shareResult.index_invite_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t) : "button" === a.from && "invite" === a.target.dataset.type ? (this.data.isInviteShare = !0, 
        e.sourceReport("invite_button_click"), i.clickInvitedBtn(), t = {
            title: e.globalData.shareResult.index_invite_share.title,
            imageUrl: e.globalData.shareResult.index_invite_share.imageUrl,
            path: e.sharePath() + "&inviterId=" + e.globalData.player.userId + "&event=invite_suc"
        }, e.shareTrace({
            sharePath: t.path,
            event: "receive_energy",
            subEvent: "invite_button_click",
            shareCard: e.globalData.shareResult.index_invite_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t) : "button" === a.from && "newUser" === a.target.dataset.type ? (this.data.isNewUserShare = !0, 
        i.clickInvitedBtn(), t = {
            title: e.globalData.shareResult.invite_new_user.title,
            imageUrl: e.globalData.shareResult.invite_new_user.imageUrl,
            path: e.sharePath() + "&isNewUser=" + e.globalData.player.userId
        }, e.shareTrace({
            sharePath: t.path,
            event: "invite_new",
            subEvent: "invite_new_click",
            shareCard: e.globalData.shareResult.invite_new_user.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t) : "button" === a.from && "showOff" === a.target.dataset.type ? (t = {
            title: e.globalData.shareResult.show_off.title,
            imageUrl: e.globalData.shareResult.show_off.imageUrl,
            path: e.sharePath()
        }, e.shareTrace({
            sharePath: t.path,
            event: "flaunt_share",
            subEvent: "flaunt_share_click",
            shareCard: e.globalData.shareResult.show_off.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t) : "button" === a.from && "openBox" === a.target.dataset.type ? (this.data.isOpenBoxShare = !0, 
        this.data.shareTimeStamp = new Date().getTime(), e.sourceReport("sopen_box_suc"), 
        t = {
            title: e.globalData.shareResult.activity_share.title,
            imageUrl: e.globalData.shareResult.activity_share.imageUrl,
            path: e.sharePath() + "&event=sopen_box_conver"
        }, this.data.openBoxTraceData = {
            sharePath: t.path,
            event: "open_reward",
            subEvent: "open_reward_click",
            shareCard: e.globalData.shareResult.activity_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }, t) : "button" === a.from && "word" === a.target.dataset.type ? (e.sourceReport("end_idioms_click"), 
        t = {
            title: e.globalData.shareResult.chengyu_share.title,
            imageUrl: this.data.wordExplain.shareCard,
            path: e.sharePath() + "&word=" + this.data.wordExplain.word + "&event=end_idioms_conver"
        }, e.shareTrace({
            sharePath: t.path,
            event: "idiom_detail",
            subEvent: "idiom_detail_click",
            shareCard: e.globalData.shareResult.chengyu_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t) : "button" === a.from && "not-energy" === a.target.dataset.type ? (e.sourceReport("uenergy_share_click"), 
        t = {
            title: e.globalData.shareResult.not_energy.title,
            imageUrl: e.globalData.shareResult.not_energy.imageUrl,
            path: e.sharePath() + "&event=uenergy_share_conver&otherId=" + e.globalData.player.userId + "&shareTsp=" + Date.now() + "&bonusType=energy"
        }, this.data.energyTraceData = {
            sharePath: t.path,
            event: "un_energy",
            subEvent: "un_energy_click",
            shareCard: e.globalData.shareResult.not_energy.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }, t) : (e.shareTrace({
            sharePath: t.path,
            event: "share_menu",
            subEvent: "share_menu_click",
            shareCard: e.globalData.shareResult.top_right_share.id,
            shareTitle: t.title,
            result: 1,
            gameTime: -1
        }), t);
    },
    buySuccess: function(a) {
        var e = a.detail;
        this.selectComponent("#navbar").getData("noInit");
        var t = e.propType;
        if (2 != t) if (4 != t) {
            var i = !0, o = 5;
            3 == t && (o = 6, i = !1), this.setData({
                isBuyTip: i,
                isShowReward: !0,
                rewardType: o,
                commonGetEnegyPopupValue: e.propValue
            }), this.showMixinBanner();
        } else this.setData({
            isShowReward: !0,
            rewardType: 10
        });
    },
    toggleShop: function() {
        this.setData({
            isShowShop: !this.data.isShowShop
        }), this.data.isShowShop && e.globalData.setting.playAudio("btnClick");
    },
    shopGetUserInfo: function(a) {
        a.detail ? (o.clear(), e.setGlobalData({
            needAuth: !1,
            userInfo: a.detail.userInfo
        })) : this.showToast("请点击允许，授权信息购买能量");
    },
    toggleInviteNew: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowInviteNew: !this.data.isShowInviteNew
        });
    },
    showNewInviteToast: function(a) {
        this.showToast(a.detail);
    },
    toggleSignUp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowSignUp: !this.data.isShowSignUp,
            daysSignStyle: !!this.data.newUserHadDaysSign
        });
    },
    toSign: function() {
        this.data.whatDidIDo = "goDaysSign";
    },
    getPlayer: function() {
        var a = this;
        i.player().then(function(t) {
            a.data.firstSign = t.data.data.firstSign, "goDaysSign" === a.data.whatDidIDo && t.data.data.firstSign && a.signSuccess();
            var i = t.data.data.signDays + 1;
            t.data.data.sign && (i = t.data.data.signDays);
            var o = Math.floor((i - 8) / 6) + 1;
            o < 0 && (o = 0), a.setData({
                daysSignInfo: {
                    nowSignDays: i,
                    week: o
                }
            }), t.data.data.gzhEnergy && (e.setGlobalData({
                goGzhSign: !1,
                energyTotal: e.globalData.energyTotal + t.data.data.gzhEnergy
            }), a.setData({
                isShowGzhSign: !1,
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: t.data.data.gzhEnergy
            }), a.showMixinBanner(), a.selectComponent("#navbar").getData("noInit"), e.globalData.setting.playAudio("getEnergy"));
        });
    },
    toggleGzhSignUp: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGzhSign: !this.data.isShowGzhSign
        });
    },
    toGzh: function() {
        this.data.goGzhSign = !0, e.setGlobalData({
            goGzhSign: !0
        });
    },
    onShowHandle: function() {
        var a = this;
        this.getPlayer(), console.log("this.data.goGzhSign1", this.data.goGzhSign), this.data.goGzhSign && (console.log("this.data.goGzhSign2", this.data.goGzhSign), 
        o.clear(), i.suppleMpReward(e.globalData.scene, "gzhSign").then(function(t) {
            0 === t.data.code && (e.actionTrace({
                event: "enlist_wxoa",
                subEvent: "enlist_wxoa_suc"
            }), a.data.goGzhSign = !1, e.setGlobalData({
                goGzhSign: !1,
                energyTotal: e.globalData.energyTotal + t.data.data.gzhEnergy
            }), a.setData({
                isShowGzhSign: !1,
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: t.data.data.gzhEnergy
            }), a.showMixinBanner(), a.selectComponent("#navbar").getData("noInit"), e.globalData.setting.playAudio("getEnergy"));
        })), this.data.isShareFinishImg && (this.data.isShareFinishImg = !1, this.data.finishPageInfo.showResult && (this.toggleShareSuccess(), 
        this.toggleFinishShare())), this.data.isTryingGame && (this.data.isTryingGame = !1, 
        this.tryGameHandle()), this.data.isNewUserShare && (this.data.isNewUserShare = !1, 
        this.selectComponent("#inviteNewUser") && this.selectComponent("#inviteNewUser").show()), 
        this.data.friendLine, "goDaysSign" === this.data.whatDidIDo && (this.setData({
            isShowSignUp: !1
        }), this.getPlayer());
    },
    toFriendLine: function() {
        this.data.friendLine = !0;
    },
    toggleFriendLine: function() {
        this.setData({
            isShowFriendLine: !this.data.isShowFriendLine
        }), this.data.isShowFriendLine || this.setData({
            friendLineType: ""
        });
    },
    toTryGame: function(a) {
        this.data.tryGame = a.detail, this.data.isTryingGame = !0, this.data.tryStart = new Date().getTime();
    },
    toggleGameTry: function() {
        e.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGameTry: !this.data.isShowGameTry
        });
    },
    tryGetSuccess: function(a) {
        e.globalData.setting.playAudio("getEnergy"), this.setData({
            isEnergyTip: !0,
            isShowReward: !0,
            rewardType: 5,
            commonGetEnegyPopupValue: a.detail.bonusValue
        }), this.showMixinBanner(), this.selectComponent("#navbar").getData("noInit");
    },
    tryFinish: function() {},
    toSignWatchVideo: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
        }), e.globalData.shareVideoRule.adv.dailySignAdv) {
            var o = null;
            (o = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.dailySignAdv
            })).load(), o.offError(), o.onError(function(t) {
                console.log("err", t), i.shareVideoDynamicControl();
                var o = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var n in e.globalData.shareVideoRule) "canWatchVideo" != n && (o[[ "shareVideoRule." + n ]] = 1);
                e.setGlobalData(o);
            }), o.offClose(), o.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
                }), t.signSuccess(!0)) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(t.toSignWatchVideo), 
                e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.dailySignAdv
                }), t.showToast("请观看完整视频"));
            }), o.show().catch(function(a) {
                o.load().then(function() {
                    o.show();
                });
            }), this.data.videoAd = o;
        } else this.signSuccess(!0);
    },
    signSuccess: function(a) {
        this.data.whatDidIDo = "", this.setData({
            isEnergyTip: !0,
            isShowReward: !0,
            commonGetEnegyPopupValue: a ? 2 : this.data.firstSign,
            rewardType: 5
        }), this.showMixinBanner(), e.setGlobalData({
            energyTotal: e.globalData.energyTotal + this.data.firstSign
        });
        var t = this.data.player;
        t.sign = !0, e.setGlobalData({
            player: t
        }), this.setData({
            player: t
        }), e.globalData.setting.playAudio("getEnergy"), wx.getStorageSync("newUserHadDaysSign") || (wx.setStorageSync("newUserHadDaysSign", "yes"), 
        this.setData({
            newUserHadDaysSign: !0
        }));
    },
    seoStart: function() {
        wx.redirectTo({
            url: "/pages/index/index?toGame=1"
        });
    },
    getDouble: function() {
        var t = this;
        if (e.actionTrace({
            event: "ad_video_click",
            subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
        }), e.globalData.shareVideoRule.adv.doubleEnergyAdv) {
            var o = null;
            (o = wx.createRewardedVideoAd({
                adUnitId: e.globalData.shareVideoRule.adv.doubleEnergyAdv
            })).load(), o.offError(), o.onError(function(o) {
                console.log("err", o), i.shareVideoDynamicControl(), t.showToast("今日视频已达上限"), t.setData({
                    isShowReward: !1
                });
                var n = a({}, "shareVideoRule.canWatchVideo", !1);
                for (var s in e.globalData.shareVideoRule) "canWatchVideo" != s && (n[[ "shareVideoRule." + s ]] = 1);
                e.setGlobalData(n);
            }), o.offClose(), o.onClose(function(a) {
                a.isEnded ? (e.toggleWatchVideoGuide(), e.actionTrace({
                    event: "ad_video_close",
                    subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
                }), t.doubleSuccess()) : (wx.getStorageSync("isWatchGuideFinish") || e.toggleWatchVideoGuide(t.getDouble), 
                e.actionTrace({
                    event: "ad_video_finish",
                    subEvent: e.globalData.shareVideoRule.adv.doubleEnergyAdv
                }), t.showToast("请观看完整视频"));
            }), o.show().catch(function(a) {
                o.load().then(function() {
                    o.show();
                });
            }), this.data.videoAd = o;
        } else this.doubleSuccess();
    },
    doubleSuccess: function() {
        var a = this;
        i.doubleGetEnergy(this.data.commonGetEnegyPopupValue).then(function(t) {
            0 === t.data.code && (e.globalData.setting.playAudio("getEnergy"), a.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 9,
                commonGetEnegyPopupValue: a.data.commonGetEnegyPopupValue
            }), a.selectComponent("#navbar").getData("noInit"));
        });
    },
    animationEnd: function() {
        this.setData({
            isAnimalEnd: !0
        });
    },
    clickTreasure: function() {
        1 == this.data.roundNum && e.actionTrace({
            event: "game_1_finish",
            subEvent: "game1_box_click"
        }), 2 == this.data.roundNum && e.actionTrace({
            event: "game_2_finish",
            subEvent: "game2_box_click"
        }), this.toggleMoreGame();
    },
    toggleShowOff: function() {
        this.setData({
            isShowShowOff: !this.data.isShowShowOff
        });
    },
    toggleShareSuccess: function() {
        this.setData({
            isShowShareSuccess: !this.data.isShowShareSuccess
        });
    },
    toggleWatchVideoGuide: function() {
        e.setGlobalData({
            isShowWatchVideoGuide: !e.globalData.isShowWatchVideoGuide
        });
    },
    refreshReward: function() {
        console.log("refreshReward"), this.selectComponent("#navbar") && this.selectComponent("#navbar").getData("noInit");
    },
    toggleFriendLineFromShare: function() {
        this.setData({
            friendLineType: "1"
        }), this.toggleFriendLine();
    },
    getFinishShareImg: function() {
        var a = this;
        this.data.boxList && i.finishPageImg(JSON.parse(this.data.boxList)).then(function(t) {
            if (0 === t.data.code) {
                a.setData({
                    finishShareImg: t.data.data.imgUrl
                });
                var i = -1, o = -1;
                for (var n in e.globalData.player.finishPageStrategy) a.data.roundNum >= Number(n) && i < Number(n) && (i = Number(n), 
                o = e.globalData.player.finishPageStrategy[n]);
                if (-1 == o) return;
                if (0 == o) return void a.toggleFinishShare();
                (a.data.roundNum - i) % (o + 1) == 0 && a.toggleFinishShare();
            }
        });
    }
});