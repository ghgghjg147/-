function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var a = getApp(), e = (require("../../../config"), require("../../../utils/https")), i = require("../../../vendor/qcloud-weapp-client-sdk/lib/session"), s = void 0;

Page({
    data: {
        siteInfo: require("../../../siteinfo.js"),
        isCloseGuide1: !1,
        isGame: 0,
        selectBox: "",
        isOpenBoxShare: !1,
        shareTimeStamp: 0,
        isEnergyTip: !1,
        isBannerReady: !1,
        isEnd: !1,
        toWithdraw: !1,
        isShowGetMoney: !1,
        rewardData: "",
        isShowReward: !1,
        animalStep: 1,
        pageReady: !1,
        rewardType: 7,
        videoAd: "",
        lessLevel: 0,
        level: "",
        lotteryTime: "",
        isStarted: !1,
        isShowBanner: !0,
        toastList: [],
        isShowRule: !1,
        detail: {},
        word: [ {}, {}, {}, {} ],
        passLevel: 0,
        page: 1,
        zikuaiInfo: {},
        userList: [],
        flyMsgIndex: 1,
        cardDict: [ [ a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/-gfjj-xue.png", a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/gfjj-zkdzz-xue.png" ], [ a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/-gfjj-hai.png", a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/gfjj-zkdzz-hai.png" ], [ a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/-gfjj-wu.png", a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/gfjj-zkdzz-wu.png" ], [ a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/-gfjj-ya.png", a.baseUrl() + "/addons/yf_chengyujiekong/resource/image/activity/gfjj-zkdzz-ya.png" ] ],
        interstitialAd1: null,
        showNewGuide: !1,
        switchNewGuide: !1,
        showContinueGameGuide: !1,
        percent: 0
    },
    onLoad: function(t) {
        a.globalData.options.path = "pages/activity/activity", a.setWatch(this, "", "activity"), 
        a.loginTrace("page_load", t), this.setData({
            isGame: t.isGame || 0
        }), wx.updateShareMenu({
            withShareTicket: !0
        }), this.activityDetail(!0), "true" == t.showContinueGameGuide ? this.setData({
            showContinueGameGuide: !0
        }) : "newGuide" === t.from && this.setData({
            showNewGuide: !0
        });
    },
    onReady: function() {
        var t = this;
        this.setData({
            pageReady: !0
        }), setTimeout(function() {
            t.setData({
                isBannerReady: !0
            });
        }, 500);
    },
    onShow: function() {
        var e = this;
        if (this.data.isShare ? this.data.isShare = !1 : a.actionTrace({
            event: "page_show",
            subEvent: ""
        }), this.data.isInviteShare && (this.data.isInviteShare = !1, this.showToast("请提醒好友打开游戏，即可获取能量奖励")), 
        this.data.isOpenBoxShare) {
            this.data.isOpenBoxShare = !1, new Date().getTime();
            var i = this.data.shareTimeStamp;
            if (a.setGlobalData({
                toShare: 0
            }), Date.now() - i < a.globalData.shareGetEnergy.timeInterVal) return this.data.openBoxTraceData.result = 0, 
            a.shareTrace(this.data.openBoxTraceData), this.showToast("请将活动分享到群，开启宝箱");
            a.globalData.shareGetEnergy.isFirst ? a.globalData.shareGetEnergy.canSuccessShare > 1 ? (a.setGlobalData(t({}, "shareGetEnergy.canSuccessShare", a.globalData.shareGetEnergy.canSuccessShare - 1)), 
            this.data.openBoxTraceData.result = 0, this.showToast("请将活动分享到群，开启宝箱")) : this.getZikuai() : this.data.lastShareEnergyFail || Math.random() < a.globalData.shareGetEnergy.successRate ? (this.getZikuai(), 
            this.data.lastShareEnergyFail = !1) : (this.showToast("请将活动分享到群，开启宝箱"), this.data.lastShareEnergyFail = !0, 
            this.data.openBoxTraceData.result = 0, a.shareTrace(this.data.openBoxTraceData)), 
            a.shareTrace(this.data.openBoxTraceData);
        }
        this.selectComponent("#navbar").show();
        var s = Number(wx.getStorageSync("lastOpenInterstitialAdTime"));
        if ("activity" === a.globalData.lastPageName && (!s || Date.now() - s > 36e5) ? (wx.createInterstitialAd && (this.data.interstitialAd1 = wx.createInterstitialAd({
            adUnitId: a.globalData.shareVideoRule.adv.backGameBanner
        }), this.data.interstitialAd1.onLoad(function() {
            e.data.interstitialAd1.show().then(function() {
                wx.setStorageSync("lastOpenInterstitialAdTime", String(Date.now()));
            });
        })), a.globalData.lastPageName = "activity") : a.globalData.lastPageName = "activity", 
        a.globalData.toShare) {
            var n = a.globalData.toShare;
            if (a.setGlobalData({
                toShare: 0
            }), Date.now() - n < a.globalData.shareGetEnergy.timeInterVal) return this.data.energyTraceData.result = 0, 
            a.shareTrace(this.data.energyTraceData), this.showToast("分享失败，请分享到群聊");
            if (a.globalData.shareGetEnergy.isFirst) a.globalData.shareGetEnergy.canSuccessShare > 1 ? (a.setGlobalData(t({}, "shareGetEnergy.canSuccessShare", a.globalData.shareGetEnergy.canSuccessShare - 1)), 
            this.data.energyTraceData.result = 0, this.showToast("分享失败，请分享到群聊")) : this.shareGetEnergySuccess(); else if (this.data.lastShareEnergyFail || Math.random() < a.globalData.shareGetEnergy.successRate) this.shareGetEnergySuccess(), 
            this.data.lastShareEnergyFail = !1; else {
                var r = Math.floor(Math.random() * a.globalData.shareGetEnergy.textList.length);
                this.showToast(a.globalData.shareGetEnergy.textList[r]), this.data.lastShareEnergyFail = !0, 
                this.data.energyTraceData.result = 0;
            }
            a.shareTrace(this.data.energyTraceData);
        }
        this.data.toWithdraw && (this.data.toWithdraw = !1, this.activityDetail(!0));
    },
    closeNewGuide: function() {
        this.data.showNewGuide && this.data.passLevel < this.data.detail.word[0].level && (a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_guide_off"
        }), this.data.isCloseGuide1 = !0), a.globalData.setting.playAudio("btnClick"), this.setData({
            showNewGuide: !1
        });
    },
    onHide: function() {
        this.data.isShare || a.actionTrace({
            event: "page_hide",
            subEvent: ""
        }), this.selectComponent("#navbar").hide();
    },
    onUnload: function() {
        this.data.videoAd && this.data.videoAd.destroy(), a.actionTrace({
            event: "page_unload",
            subEvent: ""
        }), clearInterval(this.data.flyMsgInterval);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    bindSwitchNewGuide: function() {
        this.setData({
            switchNewGuide: !0
        });
    },
    onShareAppMessage: function(t) {
        this.data.isShare = !0, a.globalData.lastPageName = "";
        var e = {
            title: a.globalData.shareResult.top_right_share.title,
            imageUrl: a.globalData.shareResult.top_right_share.imageUrl,
            path: a.sharePath()
        };
        return "button" === t.from && "invite" === t.target.dataset.type ? (this.data.isInviteShare = !0, 
        a.sourceReport("invite_button_click"), e = {
            title: a.globalData.shareResult.index_invite_share.title,
            imageUrl: a.globalData.shareResult.index_invite_share.imageUrl,
            path: a.sharePath() + "&inviterId=" + a.globalData.player.userId + "&event=invite_suc"
        }, a.shareTrace({
            sharePath: e.path,
            event: "receive_energy",
            subEvent: "invite_button_click",
            shareCard: a.globalData.shareResult.index_invite_share.id,
            shareTitle: e.title,
            result: 1,
            gameTime: -1
        }), e) : "button" === t.from && "openBox" === t.target.dataset.type ? (this.data.isOpenBoxShare = !0, 
        this.data.shareTimeStamp = new Date().getTime(), a.sourceReport("sopen_box_suc"), 
        e = {
            title: a.globalData.shareResult.activity_share.title,
            imageUrl: a.globalData.shareResult.activity_share.imageUrl,
            path: a.sharePath() + "&event=sopen_box_conver"
        }, this.data.openBoxTraceData = {
            sharePath: e.path,
            event: "open_reward",
            subEvent: "open_reward_click",
            shareCard: a.globalData.shareResult.activity_share.id,
            shareTitle: e.title,
            result: 1,
            gameTime: -1
        }, e) : "button" === t.from && "share" === t.target.dataset.type ? (a.log("app.globalData.shareResult", a.globalData.shareResult), 
        1 == this.data.page ? (a.sourceReport("act_share_click"), e = {
            title: a.globalData.shareResult.activity_share.title,
            imageUrl: a.globalData.shareResult.activity_share.imageUrl,
            path: a.sharePath() + "&event=act_share_conver"
        }, a.shareTrace({
            sharePath: e.path,
            event: "collect_box",
            subEvent: "collect_box_click",
            shareCard: a.globalData.shareResult.activity_share.id,
            shareTitle: e.title,
            result: 1,
            gameTime: -1
        }), e) : (a.sourceReport("reward_share_click"), e = {
            title: a.globalData.shareResult.activity_share.title,
            imageUrl: a.globalData.shareResult.activity_share.imageUrl,
            path: a.sharePath() + "&event=reward_share_conver"
        }, a.shareTrace({
            sharePath: e.path,
            event: "open_box",
            subEvent: "open_box_click",
            shareCard: a.globalData.shareResult.activity_share.id,
            shareTitle: e.title,
            result: 1,
            gameTime: -1
        }), e)) : "button" === t.from && "not-energy" === t.target.dataset.type ? (a.sourceReport("uenergy_share_click"), 
        e = {
            title: a.globalData.shareResult.not_energy.title,
            imageUrl: a.globalData.shareResult.not_energy.imageUrl,
            path: a.sharePath() + "&event=uenergy_share_conver"
        }, this.data.energyTraceData = {
            sharePath: e.path,
            event: "un_energy",
            subEvent: "un_energy_click",
            shareCard: a.globalData.shareResult.not_energy.id,
            shareTitle: e.title,
            result: 1,
            gameTime: -1
        }, e) : (a.shareTrace({
            sharePath: e.path,
            event: "share_menu",
            subEvent: "share_menu_click",
            shareCard: a.globalData.shareResult.top_right_share.id,
            shareTitle: e.title,
            result: 1,
            gameTime: -1
        }), e);
    },
    bannerInit: function() {
        this.setData({
            shareVideoRule: a.globalData.shareVideoRule
        }), a.log("shareVideoRule", this.data.shareVideoRule, this.data.shareVideoRule.gameOverBanner);
    },
    bannerError: function(t) {
        a.log("banner err", t), this.setData({
            isShowBanner: !1
        });
    },
    goback: function() {
        this.data.showContinueGameGuide && a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_guide_home"
        }), this.data.isGame ? wx.redirectTo({
            url: "/pages/game/game?level=" + this.data.isGame
        }) : a.goback();
    },
    toggleRule: function() {
        a.globalData.setting.playAudio("btnClick"), this.setData({
            isShowRule: !this.data.isShowRule
        }), this.data.isShowRule && this.data.showContinueGameGuide && a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_guide_rule"
        });
    },
    showToast: function(t) {
        var e = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3, n = [];
        n = "string" == typeof t || "number" == typeof t ? [ t ] : t, this.data.toastList.push(n), 
        a.log("time2", i), this.setData({
            toastTime: i,
            toastList: this.data.toastList
        }), s && clearTimeout(s), s = setTimeout(function() {
            s = "", e.setData({
                toastList: []
            });
        }, i);
    },
    toGame: function(t) {
        var e = this;
        this.data.isStarted || (this.data.showNewGuide ? this.data.passLevel < this.data.detail.word[0].level && a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_play_game1"
        }) : this.data.isCloseGuide1 && a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_goff_game1"
        }), this.data.showContinueGameGuide && a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_play_game2"
        }), this.data.isStarted = !0, t || a.globalData.setting.playAudio("btnClick"), a.globalData.player.nextUnlock ? (wx.redirectTo({
            url: "/pages/game/game?level=" + a.globalData.player.nextLevel,
            success: function() {
                e.data.isStarted = !1;
            }
        }), this.setData({
            showNewGuide: !1
        })) : this.selectComponent("#navbar").useEnergy());
    },
    toGameRedirect: function() {
        var t = this;
        wx.redirectTo({
            url: "/pages/game/game?level=" + a.globalData.player.nextLevel,
            success: function() {
                t.data.isStarted = !1;
            }
        });
    },
    activityDetail: function(t) {
        var a = this;
        e.activityDetail().then(function(t) {
            if (0 === t.data.code) {
                for (var e = t.data.data.detail, i = new Date().getTime(), s = !1, n = a.data.page, r = t.data.data.hasVisited, o = t.data.data.detail.word, l = t.data.data.getWord || [], d = t.data.data.passLevel, h = t.data.data.passLevel, g = t.data.data.rules, u = t.data.data.users, c = 0; c < o.length; c++) !function(t) {
                    var a = o[c];
                    if (l.filter(function(t) {
                        return t.word === a.word;
                    })[0]) return a.status = 3, "continue";
                    a.level <= d ? a.status = 2 : a.status = 1;
                }();
                var y = 0, v = o.filter(function(t) {
                    return t.level > d;
                })[0];
                v ? y = v.level - d : r || o.length != l.length || (n = 2), i > e.finishTime && (s = !0), 
                a.setData({
                    passLevel: h,
                    isEnd: s,
                    rules: g,
                    page: n,
                    lessLevel: y,
                    userList: u,
                    word: o,
                    getWord: l,
                    level: d,
                    detail: e,
                    percent: t.data.data.percent,
                    lotteryTime: a.dateFilter(new Date(t.data.data.detail.lotteryTime), 1),
                    lotteryTime2: a.dateFilter(new Date(t.data.data.detail.lotteryTime), 2)
                }), r && a.getActivieyReward(), a.flyMsgHandle(), wx.setStorage({
                    key: "activityWord",
                    data: o
                });
            }
        });
    },
    dateFilter: function(t, a) {
        return 1 == a ? t.getMonth() + 1 + "月" + t.getDate() + "日" + this.fillZero(t.getHours()) + ":" + this.fillZero(t.getMinutes()) : 2 == a ? t.getMonth() + 1 + "月" + t.getDate() + "日" + this.fillZero(t.getHours()) + "点" : void 0;
    },
    fillZero: function(t) {
        return t < 9 ? "0" + t : t;
    },
    getZikuai: function() {
        var t = this;
        e.participate(this.data.selectBox).then(function(e) {
            0 === e.data.code ? (e.data.data.allWord.find(function(t) {
                t.word !== e.data.data.getWord || (e.data.data.wanyuanZkImg = t.filePath);
            }), a.globalData.setting.playAudio("getEnergy"), t.activityDetail(), t.setData({
                zikuaiInfo: e.data.data,
                rewardType: 7,
                isShowReward: !0
            })) : t.showToast(e.data.msg, 3e3);
        });
    },
    shareTrace: function() {
        this.data.showContinueGameGuide && a.actionTrace({
            event: "activity_guide",
            subEvent: "activity_guide_share"
        });
    },
    openZikuaiCase: function(t) {
        var e = this;
        if (t.currentTarget.dataset.switch) this.bindSwitchNewGuide(); else if (this.data.isEnd) this.showToast("活动已结束"); else {
            this.data.showContinueGameGuide && a.actionTrace({
                event: "activity_guide",
                subEvent: "activity_guide_box"
            });
            var i = t.currentTarget.dataset.item, s = t.currentTarget.dataset.index;
            if (this.data.selectBox = s, a.log("item.level", i.level, this.data.passLevel), 
            2 != i.status) return this.data.isShowToast || (this.data.isShowToast = !0, this.showToast("还差" + (i.level - this.data.passLevel) + "关开启宝箱，快去学成语通关吧！")), 
            void setTimeout(function() {
                e.data.isShowToast = !1;
            }, 2e3);
            a.globalData.setting.playAudio("btnClick"), this.setData({
                showNewGuide: !1
            }), 1 != this.data.shareVideoRule.activityOpenBox && (a.globalData.shareVideoRule.adv.activityAdv ? (this.adInit(), 
            this.data.videoAd.show().catch(function(t) {
                e.data.videoAd.load().then(function() {
                    e.data.videoAd.show();
                });
            })) : this.getZikuai());
        }
    },
    adInit: function() {
        var i = this, s = null;
        (s = wx.createRewardedVideoAd({
            adUnitId: a.globalData.shareVideoRule.adv.activityAdv
        })).offError(), s.onError(function(s) {
            console.log("err", s), e.shareVideoDynamicControl();
            var n = t({}, "shareVideoRule.canWatchVideo", !1);
            for (var r in a.globalData.shareVideoRule) "canWatchVideo" != r && (n[[ "shareVideoRule." + r ]] = 1);
            a.setGlobalData(n), i.getZikuai();
        }), s.offClose(), s.onClose(function(t) {
            t.isEnded ? (a.toggleWatchVideoGuide(), i.getZikuai()) : wx.showToast({
                title: "请观看完整视频",
                icon: "none",
                duration: 2e3
            });
        }), this.data.videoAd = s;
    },
    closeReward: function() {
        a.globalData.setting.playAudio("btnClick"), this.setData({
            isShowReward: !1,
            isEnergyTip: !1
        });
    },
    flyMsgHandle: function() {
        this.data.userList.length > 1 ? this.setData({
            text1: this.data.userList[this.data.flyMsgIndex - 1],
            text2: this.data.userList[this.data.flyMsgIndex],
            isDetailFinish: !0
        }) : 1 == this.data.userList.length && this.setData({
            text1: this.data.userList[0],
            text2: this.data.userList[0]
        });
    },
    changePage: function() {
        a.globalData.setting.playAudio("getBox"), this.setData({
            page: 2
        });
    },
    bindgetuserinfo: function(t) {
        "getUserInfo:ok" == t.detail.errMsg ? (a.actionTrace({
            event: "auth_user_info",
            subEvent: "activity_button_click",
            op_result: 1
        }), i.clear(), a.setGlobalData({
            needAuth: !1,
            userInfo: t.detail.userInfo
        }), this.openRedpack()) : (a.actionTrace({
            event: "auth_user_info",
            subEvent: "activity_button_click",
            op_result: 0
        }), this.showToast("请授权信息，用于申请提现"));
    },
    openRedpack: function() {
        this.data.needAuth || (a.globalData.setting.playAudio("btnClick"), this.getActivieyReward());
    },
    resetStart: function() {
        this.data.isStarted = !1;
    },
    toSetData: function(t) {
        this.setData(t.detail);
    },
    toInvite: function() {
        this.getInviteList(!0);
    },
    getInviteList: function(t) {
        var i = this;
        return t && a.globalData.setting.playAudio("btnClick"), new Promise(function(a, s) {
            e.inviteFriendList().then(function(e) {
                if (0 === e.data.code) {
                    t && i.toggleInvite();
                    for (var n = e.data.data.inviteRecords, r = e.data.data.totalValue, o = !1, l = 0; l < 5; l++) {
                        var d = n[l];
                        d.invitedId ? d.used ? d.status = 1 : (d.status = 2, o = !0) : d.status = 3;
                    }
                    i.setData({
                        totalValue: r,
                        inviteList: n,
                        isShowInviteRedpoint: o
                    }), a();
                } else s(e);
            }).catch(function(t) {
                s(t);
            });
        });
    },
    toggleInvite: function() {
        this.data.isShowInvite && a.globalData.setting.playAudio("btnClick"), this.setData({
            isShowInvite: !this.data.isShowInvite
        });
    },
    getAllEnergyByInvite: function() {
        var t = this;
        a.globalData.setting.playAudio("btnClick"), this.data.totalValue && e.getAllEnergyByInvite().then(function(e) {
            0 === e.data.code ? (t.selectComponent("#navbar").getData(), t.getInviteList(), 
            t.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: t.data.totalValue
            }), a.globalData.setting.playAudio("getEnergy")) : t.showToast(e.data.msg);
        });
    },
    getEnergyByInvite: function(t) {
        var i = this, s = t.currentTarget.dataset.item;
        a.globalData.setting.playAudio("btnClick"), e.getEnergyByInvite(s.invitedId).then(function(t) {
            0 === t.data.code ? (i.setData({
                isEnergyTip: !0,
                isShowReward: !0,
                rewardType: 5,
                commonGetEnegyPopupValue: s.energyValue
            }), a.globalData.setting.playAudio("getEnergy"), i.selectComponent("#navbar").getData(), 
            i.getInviteList()) : i.showToast(t.data.msg);
        });
    },
    toggleReward: function(t) {
        a.log("type", t, "string" == typeof t);
        var e = {};
        t && "string" == typeof t && (e.rewardType = t, 4 != t && a.globalData.setting.playAudio("levelUp")), 
        e.isEnergyTip = !1, e.isShowReward = !this.data.isShowReward, this.setData(e);
    },
    shareGetEnergySuccess: function() {
        var i = this;
        e.shareAddEnergy().then(function(e) {
            if (0 === e.data.code) {
                var s;
                i.selectComponent("#navbar").shareSuccess(), a.shareVideoRule(), i.setData({
                    isEnergyTip: !0,
                    isShowReward: !0,
                    rewardType: 5,
                    commonGetEnegyPopupValue: e.data.data.addValue
                }), a.globalData.setting.playAudio("getEnergy"), a.log("xxxxxxxxxxxxxxxxxxxxxxx", a.globalData.shareGetEnergy.isFirst), 
                a.log("xxxxxxxxxxxxxxxxxxxxxxx", a.globalData.shareGetEnergy.leftTimes), a.setGlobalData((s = {}, 
                t(s, "shareGetEnergy.isFirst", !1), t(s, "shareGetEnergy.leftTimes", e.data.data.leftTimes), 
                t(s, "energyTotal", a.globalData.energyTotal + e.data.data.addValue), s)), i.selectComponent("#navbar").closeNoEnergyPopup(), 
                a.log("xxxxxxxxxxxxxxxxxxxxxxx", a.globalData.shareGetEnergy.isFirst), a.log("xxxxxxxxxxxxxxxxxxxxxxx", a.globalData.shareGetEnergy.leftTimes);
            }
        });
    },
    animationend1: function(t) {
        1 == this.data.animalStep && (this.data.flyMsgIndex < this.data.userList.length - 2 ? this.data.flyMsgIndex += 2 : this.data.flyMsgIndex = 1, 
        this.setData({
            text1: this.data.userList[this.data.flyMsgIndex - 1]
        }));
        var a = 1 == this.data.animalStep ? 2 : 1;
        this.setData({
            animalStep: a
        }), this.animationend2();
    },
    animationend2: function(t) {
        1 == this.data.animalStep && this.setData({
            text2: this.data.userList[this.data.flyMsgIndex]
        });
    },
    flyMsgAnimate: function() {
        var t = this;
        if (this.data.pageReady && this.data.isDetailFinish && this.data.userList.length > 1) {
            var a = 0;
            this.data.flyMsgInterval = setInterval(function() {
                2 == a && (t.data.flyMsgIndex < t.data.userList.length - 2 ? t.data.flyMsgIndex += 2 : t.data.flyMsgIndex = 1, 
                t.setData({
                    text1: t.data.userList[t.data.flyMsgIndex - 1]
                })), 4 == a && (t.setData({
                    text2: t.data.userList[t.data.flyMsgIndex]
                }), a = 0), a += 1;
            }, 1e3);
        }
    },
    getActivieyReward: function() {
        var t = this;
        e.activityReward(this.data.detail.id).then(function(a) {
            0 === a.data.code ? t.setData({
                page: 3,
                rewardData: a.data.data
            }) : t.showToast(a.data.msg);
        });
    },
    toggleGetMoney: function() {
        a.globalData.setting.playAudio("btnClick"), this.setData({
            isShowGetMoney: !this.data.isShowGetMoney
        });
    },
    playClickSound: function(t) {
        a.globalData.setting.playAudio("btnClick"), "gzhWithdraw" == t.currentTarget.dataset.type && (this.data.toWithdraw = !0, 
        this.setData({
            isShowGetMoney: !1
        }));
    }
});