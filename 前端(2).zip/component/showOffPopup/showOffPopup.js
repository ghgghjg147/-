var e = getApp();

Component({
    properties: {
        iconType: {
            type: Number,
            value: 1
        }
    },
    data: {
        siteInfo: require("../../siteinfo.js"),
        isShowOff: !1,
        percent: 0,
        isShowSuccess: !1
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            e.shareShowTrace({
                sharePath: "",
                event: "flaunt_share",
                subEvent: "flaunt_share_show",
                shareCard: "",
                shareTitle: "",
                result: 1,
                gameTime: -1
            }), this.percentMove();
        },
        ready: function() {},
        detached: function() {}
    },
    methods: {
        toShare: function() {
            this.triggerEvent("share");
        },
        toShowOff: function() {
            this.data.isShowOff = !0;
        },
        show: function() {
            this.data.isShowOff && this.shareSuccess();
        },
        shareSuccess: function() {
            this.setData({
                isShowSuccess: !0
            });
        },
        percentMove: function() {
            var e = this;
            this.percentTimer = setInterval(function() {
                e.data.percent < 86 && e.setData({
                    percent: e.data.percent + 2
                });
            }, 10);
        },
        close: function() {
            this.triggerEvent("close");
        }
    }
});