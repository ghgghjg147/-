var e = getApp();

Component({
    properties: {
        player: {
            type: Object,
            value: {}
        }
    },
    data: {
        siteInfo: require("../../siteinfo.js")
    },
    methods: {
        toOtherGame: function() {
            var a = this.data.player.navigateApp;
            e.actionTrace({
                event: "only_game_click",
                subEvent: a.gameAppid
            }), wx.navigateToMiniProgram({
                appId: a.gameAppid,
                path: a.gamePath,
                success: function(t) {
                    e.actionTrace({
                        event: "only_game_out",
                        subEvent: a.gameAppid
                    }), e.globalData.toOtherGame = !0;
                },
                fail: function() {
                    console.log("跳转失败"), void 0 != a.gameQrcode && a.gameQrcode.length && wx.previewImage({
                        urls: [ a.gameQrcode ]
                    });
                }
            });
        }
    }
});