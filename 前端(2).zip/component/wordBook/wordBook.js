var t = require("../../utils/https");

Component({
    properties: {},
    lifetimes: {
        attached: function() {},
        ready: function() {
            var t = wx.getStorageSync("groupList");
            t && this.setData({
                groupList: t
            }), this.getWordList();
        },
        detached: function() {}
    },
    data: {
        siteInfo: require("../../siteinfo.js"),
        groupList: [],
        isLoaded: !1,
        max: "",
        current: ""
    },
    methods: {
        openIdiomPopup: function(t) {
            var e = t.currentTarget.dataset.word;
            this.triggerEvent("word", e);
        },
        close: function() {
            this.triggerEvent("close");
        },
        selectWord: function(t) {
            wxKit.report("over_page_click_idiom", {}), console.log(t);
            var e = t.currentTarget.dataset.id;
            this.triggerEvent("selectWord", {
                id: e
            });
        },
        getWordList: function() {
            var e = this;
            t.getVocab().then(function(t) {
                if (0 === t.data.code) {
                    var a = t.data.data.data, r = [];
                    for (var o in a) {
                        var i = {}, s = new RegExp('"', "g");
                        i.title = o.replace(s, "").toUpperCase(), "RECENT" === i.title && (i.title = "最新"), 
                        i.wordList = a[o], console.log("key", a[o]), r.push(i);
                    }
                    wx.setStorage({
                        key: "groupList",
                        data: r
                    }), e.setData({
                        max: t.data.data.max,
                        current: t.data.data.current,
                        groupList: r,
                        isLoaded: !0
                    });
                } else e.setData({
                    isLoaded: !0
                });
            }).catch(function(t) {
                console.log("getIdiomList err", t), e.setData({
                    isLoaded: !0
                });
            });
        }
    }
});