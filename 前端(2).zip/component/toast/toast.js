Component({
    properties: {
        toastList: {
            type: Array,
            value: []
        },
        time: {
            type: Number,
            value: 2e3
        }
    },
    lifetimes: {
        created: function() {
            console.log("time", this.data.time);
        }
    },
    data: {},
    methods: {}
});