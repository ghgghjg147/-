getApp(), Component({
    properties: {
        shareVideoRule: {
            type: Object,
            value: {}
        }
    },
    data: {
        siteInfo: require("../../siteinfo.js")
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        getEnergyWatchVideo: function() {
            this.triggerEvent("getEnergyWatchVideo"), this.triggerEvent("close");
        }
    }
});