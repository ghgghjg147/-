var e = getApp();

Component({
    properties: {},
    data: {
        siteInfo: require("../../siteinfo.js")
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        getEnergyWatchVideo: function() {
            e.globalData.watchVideoGuideCb && e.globalData.watchVideoGuideCb();
        }
    }
});