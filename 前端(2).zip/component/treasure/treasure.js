Component({
    properties: {},
    data: {
        siteInfo: require("../../siteinfo.js")
    },
    methods: {}
});