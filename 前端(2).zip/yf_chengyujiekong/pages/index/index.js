Page({
    data: {
        text: "demo"
    },
    onLoad: function(n) {
        console.log(this);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});